package com.dingxiaoyu.DOCNET;

public class NodeDistance
{
	public int id;
	public int distance;
	public NodeDistance parent;

	public NodeDistance()
	{

	}

	@Override
	public String toString()
	{
		return "NodeDistance [id=" + id + ", distance=" + distance
				+ ", parent=" + parent + "]";
	}

}
