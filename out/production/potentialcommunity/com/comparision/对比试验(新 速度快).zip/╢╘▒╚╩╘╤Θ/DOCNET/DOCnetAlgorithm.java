package com.dingxiaoyu.DOCNET;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeSet;

import DataReaderRealWorldNetwork.DataReaderRealWorldNetwork;

public class DOCnetAlgorithm
{
	public int size;
	// public int[][] adjacencyMatrix;
	public ArrayList<ArrayList<Integer>> adjacencyTable;
	public ArrayList<TreeSet<Integer>> communities;
	public TreeSet<NodeImportance> all_node_importance;

	public DOCnetAlgorithm(int n, ArrayList<ArrayList<Integer>> adjacencyTable)
	{
		this.size = n;
		// this.adjacencyMatrix = fr.adjacencyMatrix;
		this.adjacencyTable = adjacencyTable;
		this.all_node_importance = new TreeSet<NodeImportance>(
				new NodeImportance());
		this.communities = new ArrayList<TreeSet<Integer>>();
		// System.out.println("AdjacencyTable:");
		// for (Iterator<ArrayList<Integer>> iter =adjacencyTable.iterator();
		// iter
		// .hasNext();)
		// {
		// System.out.println(iter.next());
		// }
	}

	/* Get node importance (tested) */
	public double get_node_importance(int node)
	{
		double node_importance = 0;
		int neighbor_size = adjacencyTable.get(node).size() - 1;
		if (neighbor_size > 1)
		{
			TreeSet<Integer> neighbors = new TreeSet<Integer>();
			neighbors.addAll(adjacencyTable.get(node));
			neighbors.remove((Integer) node);
			// System.out.println(neighbors);
			int internal_link_number = get_community_internal_link_number(neighbors);
			node_importance = (double) (2 * internal_link_number)
					/ (double) (neighbor_size - 1);
			// System.out.println(internal_link_number);
		}
		return node_importance;
	}

	/* Get all node importance (tested) */
	public void get_all_node_importance()
	{
		for (int i = 0; i < size; i++)
		{
			double importance = get_node_importance(i);
			NodeImportance node_importance = new NodeImportance(i, importance);
			all_node_importance.add(node_importance);
		}
	}

	/* Get the number of community internal links (tested) */
	public TreeSet<Integer> get_community_border(TreeSet<Integer> community)
	{
		TreeSet<Integer> border = new TreeSet<Integer>();
		for (Iterator<Integer> iter_member = community.iterator(); iter_member
				.hasNext();)
		{
			Integer node = iter_member.next();
			for (Iterator<Integer> iter_neighbor = adjacencyTable.get(node)
					.iterator(); iter_neighbor.hasNext();)
			{
				Integer neighbor = iter_neighbor.next();
				if (!node.equals(neighbor) && !community.contains(neighbor))
				{
					border.add(neighbor);
				}
			}
		}
		// System.out.println(border);
		return border;
	}

	/* Refresh community border (tested) */
	public void refresh_community_border(TreeSet<Integer> community,
			TreeSet<Integer> border, int node_new)
	{
		/* Refresh community */
		community.add((Integer) node_new);
		/* Refreash neighbors */
		border.remove((Integer) node_new);
		for (Iterator<Integer> iter_neighbor = adjacencyTable.get(node_new)
				.iterator(); iter_neighbor.hasNext();)
		{
			Integer neighbor = iter_neighbor.next();
			if (node_new != neighbor)
			{
				if (!community.contains(neighbor) && !border.contains(neighbor))
				{
					border.add(neighbor);
				}
			}
		}
		// System.out.println(community);
		// System.out.println(border);
	}

	/* Get node community internal degree (tested) */
	public int get_node_community_internal_degree(TreeSet<Integer> community,
			int node)
	{
		int node_community_internal_degree = 0;
		for (Iterator<Integer> iter_member = community.iterator(); iter_member
				.hasNext();)
		{
			Integer member = iter_member.next();
			if (member != node && adjacencyTable.get(member).contains(node))
			{
				node_community_internal_degree++;
			}
			// if (member != node && adjacencyMatrix[member][node] != 0)
			// {
			// node_community_internal_degree++;
			// }
		}
		// System.out.println(node_community_internal_degree);
		return node_community_internal_degree;
	}

	/* Calculate weighted cofficient (tested) */
	public double calculate_weighted_cofficient(TreeSet<Integer> community,
			int node)
	{
		double weighted_cofficient = 0;
		int degree = adjacencyTable.get(node).size() - 1;
		int node_community_internal_degree = get_node_community_internal_degree(
				community, node);
		weighted_cofficient = (double) degree
				/ (double) node_community_internal_degree;
		// System.out.println(degree + "," + node_community_internal_degree +
		// ","
		// + weighted_cofficient);
		return weighted_cofficient;
	}

	/* To judge if a node is already get its distance */
	public boolean node_distance_exists(ArrayList<NodeDistance> nodes_distance,
			int id)
	{
		for (Iterator<NodeDistance> iter_node_distance = nodes_distance
				.iterator(); iter_node_distance.hasNext();)
		{
			NodeDistance node_distance = iter_node_distance.next();
			if (node_distance.id == id)
			{
				return true;
			}
		}
		return false;
	}

	/* Calculte average node community distance (tested) */
	public double calculte_average_node_community_distance(
			TreeSet<Integer> community, int node)
	{
		double average_node_community_distance = 0;
		int distance_sum = 0;
		/* Get all nodes' distance */
		ArrayList<NodeDistance> used_members = new ArrayList<NodeDistance>();
		ArrayList<NodeDistance> queue_members = new ArrayList<NodeDistance>();
		NodeDistance node_first = new NodeDistance();
		node_first.id = node;
		node_first.distance = 0;
		node_first.parent = null;
		queue_members.add(node_first);
		while (!queue_members.isEmpty())
		{
			NodeDistance first_queue_member = queue_members.remove(0);
			used_members.add(first_queue_member);
			// System.out.println(first_queue_member);
			for (Iterator<Integer> iter_neighbor = adjacencyTable.get(
					first_queue_member.id).iterator(); iter_neighbor.hasNext();)
			{
				Integer neighbor = iter_neighbor.next();
				if (neighbor != first_queue_member.id
						&& community.contains(neighbor)
						&& !node_distance_exists(used_members, neighbor)
						&& !node_distance_exists(queue_members, neighbor))
				{
					NodeDistance node_distance = new NodeDistance();
					node_distance.id = neighbor;
					node_distance.distance = first_queue_member.distance + 1;
					node_distance.parent = first_queue_member;
					queue_members.add(node_distance);
				}
			}
		}
		/* Calculate distance */
		for (Iterator<NodeDistance> iter_node_distance = used_members
				.iterator(); iter_node_distance.hasNext();)
		{
			NodeDistance node_distance = iter_node_distance.next();
			distance_sum += node_distance.distance;
			// System.out.println(node_distance);
		}
		average_node_community_distance = (double) distance_sum
				/ (double) community.size();
		// System.out.println(average_node_community_distance);
		return average_node_community_distance;
	}

	/* Calculate membership degree (tested) */
	public double calculate_membership_degree(TreeSet<Integer> community,
			int node)
	{
		double membership_degree = 0;
		double weighted_cofficient = calculate_weighted_cofficient(community,
				node);
		double average_node_community_distance = calculte_average_node_community_distance(
				community, node);
		membership_degree = 1 / (weighted_cofficient * average_node_community_distance);
		// System.out.println(weighted_cofficient + ","
		// + average_node_community_distance);
		// System.out.println("membership_degree: " + membership_degree);
		return membership_degree;
	}

	/*******************************************************************************************************/
	/* Get the number of community internal links */
	public int get_community_internal_link_number(TreeSet<Integer> community)
	{
		int community_internal_link_number = 0;
		for (Iterator<Integer> iter_member = community.iterator(); iter_member
				.hasNext();)
		{
			Integer member = iter_member.next();
			for (Iterator<Integer> iter_neighbor = adjacencyTable.get(member)
					.iterator(); iter_neighbor.hasNext();)
			{
				Integer neighbor = iter_neighbor.next();
				if (!neighbor.equals(member) && community.contains(neighbor))
				{
					community_internal_link_number++;
				}
			}
		}
		community_internal_link_number /= 2;
		// System.out.println(community_internal_link_number);
		return community_internal_link_number;
	}

	/*******************************************************************************************************/

	/* Get the number of community external links (tested) */
	public int get_community_external_link_number(TreeSet<Integer> community)
	{
		int community_external_link_number = 0;
		for (Iterator<Integer> iter_member = community.iterator(); iter_member
				.hasNext();)
		{
			Integer member = iter_member.next();
			for (Iterator<Integer> iter_neighbor = adjacencyTable.get(member)
					.iterator(); iter_neighbor.hasNext();)
			{
				Integer neighbor = iter_neighbor.next();
				if (!neighbor.equals(member) && !community.contains(neighbor))
				{
					community_external_link_number++;
				}
			}
		}
		// System.out.println(community_external_link_number);
		return community_external_link_number;
	}

	/* Calculate Index Connectivity (IC) (tested) */
	public double calculate_index_connectivity(TreeSet<Integer> community)
	{
		double index_connectivity = 0;
		int community_internal_link_number = get_community_internal_link_number(community);
		int community_external_link_number = get_community_external_link_number(community);
		index_connectivity = (community_internal_link_number - community_external_link_number)
				/ Math.sqrt((double) (community_internal_link_number + community_external_link_number));
		// System.out.println(community_internal_link_number + ","
		// + community_external_link_number);
		// System.out.println("index_connectivity: " + index_connectivity);
		return index_connectivity;
	}

	/* Extention community */
	public void extension(TreeSet<Integer> community)
	{
		TreeSet<Integer> border = get_community_border(community);
		// System.out.println(community);
		// System.out.println(border);
		while (!border.isEmpty())
		{
			/* Get the node with the highest membership degree */
			double max_membership_degree = 0;
			int node_max_membership_degree = -1;
			for (Iterator<Integer> iter_border_member = border.iterator(); iter_border_member
					.hasNext();)
			{
				Integer border_member = iter_border_member.next();
				double membership_degree = calculate_membership_degree(
						community, border_member);
				// System.out.println(border_member + "," + membership_degree);
				if (membership_degree > max_membership_degree)
				{
					max_membership_degree = membership_degree;
					node_max_membership_degree = border_member;
				}
			}
			/* Get new community */
			TreeSet<Integer> community_new = new TreeSet<Integer>();
			community_new.addAll(community);
			community_new.add(node_max_membership_degree);
			double index_connectivity = calculate_index_connectivity(community);
			double index_connectivity_new = calculate_index_connectivity(community_new);
			// System.out.println(index_connectivity + ","
			// + index_connectivity_new);
			if (index_connectivity_new > index_connectivity)
			{
				refresh_community_border(community, border,
						node_max_membership_degree);
				// System.out.println(community);
				// System.out.println(border);
				// System.out.println(max_membership_degree);
				// System.out.println(index_connectivity + ","
				// + index_connectivity_new);
				// System.out.println(community);
				// System.out.println(border);
				// System.out.println("*********************");
			} else
			{
				break;
			}
		}
	}

	/* To judge if two communities contain the same members (tested) */
	public boolean is_communities_equal(TreeSet<Integer> community,
			TreeSet<Integer> community_new)
	{
		if (community.size() == community_new.size())
		{
			for (Iterator<Integer> iter_member = community.iterator(); iter_member
					.hasNext();)
			{
				Integer member = iter_member.next();
				if (!community_new.contains(member))
				{
					return false;
				}
			}
			return true;
		} else
		{
			return false;
		}

	}

	/* To judge the new nature community is already existed (tested) */
	public boolean is_community_exists(TreeSet<Integer> community_new)
	{
		for (Iterator<TreeSet<Integer>> iter_community = communities.iterator(); iter_community
				.hasNext();)
		{
			TreeSet<Integer> community = iter_community.next();
			if (is_communities_equal(community, community_new))
			{
				return true;
			}
		}
		return false;
	}

	/* Judge if community_2 is a sub-community of community_1 */
	public boolean is_subcommunity(TreeSet<Integer> community_1,
			TreeSet<Integer> community_2)
	{
		/* Judge from size */
		if (community_2.size() >= community_1.size())
		{
			return false;
		}
		/* Judge from elements */
		for (Iterator<Integer> iter_member_community_2 = community_2.iterator(); iter_member_community_2
				.hasNext();)
		{
			Integer member_community_2 = iter_member_community_2.next();
			if (!community_1.contains(member_community_2))
			{
				return false;
			}
		}
		return true;
	}

	/* Remove sub-communities */
	public void remove_subcommunity()
	{
		ArrayList<TreeSet<Integer>> removed_communities = new ArrayList<TreeSet<Integer>>();
		for (int i = 0; i < communities.size(); i++)
		{
			TreeSet<Integer> community_1 = communities.get(i);
			for (int j = 0; j < communities.size(); j++)
			{
				TreeSet<Integer> community_2 = communities.get(j);
				if (i != j && is_subcommunity(community_1, community_2)
						&& !removed_communities.contains(community_2))
				{
					removed_communities.add(community_2);
					// System.out.println(community_2);
				}
			}
		}
		communities.removeAll(removed_communities);
	}

	/* Get all communities and remove repeat communities */
	public ArrayList<TreeSet<Integer>> run_docnet()
	{
		get_all_node_importance();
		TreeSet<Integer> used_nodes = new TreeSet<Integer>();
		while (used_nodes.size() < size)
		{
			for (Iterator<NodeImportance> iter_node_importance = all_node_importance
					.iterator(); iter_node_importance.hasNext();)
			{
				NodeImportance node_importance = iter_node_importance.next();
				int node = node_importance.id;
				if (!used_nodes.contains((Integer) node))
				{
					TreeSet<Integer> community = new TreeSet<Integer>();
					community.addAll(adjacencyTable.get(node));
					extension(community);
					if (!is_community_exists(community))
					{
						communities.add(community);
						used_nodes.addAll(community);
					}
				}
			}
		}
		return communities;
	}

	public static void main(String[] args) throws IOException
	{
		String file_path = "D:/real world networks/";
		String file_name = "karate";
		// karate;dolphin;football;krebsbook;dblp;amazon;youtube
		// karate_network;dolphin_network;football_network;krebsbook_network
		// dblp_network;amazon_network;youtube_network
		String community = "_community.txt";
		// karate_community;dolphin_community;football_community;krebsbook_community
		// dblp_community;amazon_community;youtube_community
		String table = "_table.txt";
		// karate_table;dolphin_table;football_table;krebsbook_table
		// dblp_table;amazon_table;youtube_table
		String file_path_community = file_path + file_name + community;
		String file_path_table = file_path + file_name + table;

		DataReaderRealWorldNetwork data_reader = new DataReaderRealWorldNetwork(
				file_path_community, file_path_table);
		data_reader.read_realworld_network();

		DOCnetAlgorithm docnet = new DOCnetAlgorithm(data_reader.n,
				data_reader.adjacencyTable);
		docnet.run_docnet();
	}

}
