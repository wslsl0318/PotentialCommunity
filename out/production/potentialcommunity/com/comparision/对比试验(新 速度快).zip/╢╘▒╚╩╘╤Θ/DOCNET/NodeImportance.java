package com.dingxiaoyu.DOCNET;

import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

public class NodeImportance implements Comparator<NodeImportance>
{
	public int id;
	public double importance;

	public NodeImportance()
	{

	}

	public NodeImportance(int id, double importance)
	{
		this.id = id;
		this.importance = importance;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		long temp;
		temp = Double.doubleToLongBits(importance);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NodeImportance other = (NodeImportance) obj;
		if (id != other.id)
			return false;
		if (Double.doubleToLongBits(importance) != Double
				.doubleToLongBits(other.importance))
			return false;
		return true;
	}

	@Override
	public String toString()
	{
		return "NodeImportane [id=" + id + ", importance=" + importance + "]";
	}

	@Override
	public int compare(NodeImportance o1, NodeImportance o2)
	{
		// TODO Auto-generated method stub
		NodeImportance node1 = o1;
		NodeImportance node2 = o2;
		if (node1.importance > node2.importance)
		{
			return -1;
		} else if (node1.importance == node2.importance)
		{
			if (node1.id < node2.id)
			{
				return -1;
			} else if (node1.id == node2.id)
			{
				return 0;
			} else if (node1.id > node2.id)
			{
				return 1;
			}
		} else if (node1.importance < node2.importance)
		{
			return 1;
		}
		return 0;
	}

	public static void main(String[] args)
	{
		NodeImportance nf1 = new NodeImportance(3, 3);
		NodeImportance nf2 = new NodeImportance(2, 4);
		TreeSet<NodeImportance> nfs = new TreeSet<NodeImportance>(
				new NodeImportance());
		nfs.add(nf1);
		nfs.add(nf2);
		for (Iterator<NodeImportance> iter_node = nfs.iterator(); iter_node
				.hasNext();)
		{
			NodeImportance nf = iter_node.next();
			System.out.println(nf.importance + "," + nf.id);
		}
	}
}
