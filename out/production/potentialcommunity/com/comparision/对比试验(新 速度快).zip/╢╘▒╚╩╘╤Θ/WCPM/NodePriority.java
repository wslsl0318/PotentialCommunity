package com.dingxiaoyu.WCPM;

import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

public class NodePriority implements Comparator<NodePriority>
{
	public int id;
	public double priority;

	public NodePriority()
	{

	}

	public NodePriority(int id, double priority)
	{
		this.id = id;
		this.priority = priority;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		long temp;
		temp = Double.doubleToLongBits(priority);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NodePriority other = (NodePriority) obj;
		if (id != other.id)
			return false;
		if (Double.doubleToLongBits(priority) != Double
				.doubleToLongBits(other.priority))
			return false;
		return true;
	}

	@Override
	public String toString()
	{
		return "NodePriority [id=" + id + ", priority=" + priority + "]";
	}

	@Override
	public int compare(NodePriority o1, NodePriority o2)
	{
		NodePriority node1 = o1;
		NodePriority node2 = o2;
		if (node1.priority > node2.priority)
		{
			return -1;
		} else if (node1.priority == node2.priority)
		{
			if (node1.id < node2.id)
			{
				return -1;
			} else if (node1.id == node2.id)
			{
				return 0;
			} else if (node1.id > node2.id)
			{
				return 1;
			}
		} else if (node1.priority < node2.priority)
		{
			return 1;
		}
		return 0;
	}

	public static void main(String[] args)
	{
		TreeSet<NodePriority> nodes = new TreeSet<NodePriority>(
				new NodePriority());
		NodePriority n1 = new NodePriority(1, 1);
		NodePriority n2 = new NodePriority(2, 3);
		NodePriority n3 = new NodePriority(3, 2);
		NodePriority n4 = new NodePriority(2, 4);
		nodes.add(n1);
		nodes.add(n2);
		nodes.add(n3);
		nodes.add(n4);
		for (Iterator<NodePriority> iter = nodes.iterator(); iter.hasNext();)
		{
			NodePriority node = iter.next();
			System.out.println(node);
		}
	}
}
