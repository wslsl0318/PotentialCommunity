package com.dingxiaoyu.WCPM;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeSet;

import DataReaderRealWorldNetwork.DataReaderRealWorldNetwork;

public class WCPMAlgorithm
{
	public int n;
	public int m;
	public ArrayList<ArrayList<Integer>> adjacencyTable;
	public TreeSet<NodePriority> all_nodes_priority;

	public WCPMAlgorithm(int n, ArrayList<ArrayList<Integer>> adjacencyTable)
	{
		this.n = n;
		this.adjacencyTable = adjacencyTable;
		// System.out.println("adjacency table");
		// for (Iterator<ArrayList<Integer>> iter =
		// this.adjacencyTable.iterator(); iter
		// .hasNext();)
		// {
		// ArrayList<Integer> line = iter.next();
		// System.out.println(line.size() - 1 + "," + line);
		// }
		this.all_nodes_priority = new TreeSet<NodePriority>(new NodePriority());
	}

	/* (Tested) Get the neighbors of a node */
	public TreeSet<Integer> get_node_neighbors(int node_id)
	{
		TreeSet<Integer> node_neighbors = new TreeSet<Integer>();
		node_neighbors.addAll(this.adjacencyTable.get(node_id));
		node_neighbors.remove(node_id);
		return node_neighbors;
	}

	/* (Tested) Get insection of two components */
	public TreeSet<Integer> get_insection(TreeSet<Integer> component_1,
			TreeSet<Integer> component_2)
	{
		TreeSet<Integer> insection = new TreeSet<Integer>();
		if (component_1.size() < component_2.size())
		{
			for (Iterator<Integer> iter = component_1.iterator(); iter
					.hasNext();)
			{
				Integer node = iter.next();
				if (component_2.contains(node))
				{
					insection.add(node);
				}
			}
		} else
		{
			for (Iterator<Integer> iter = component_2.iterator(); iter
					.hasNext();)
			{
				Integer node = iter.next();
				if (component_1.contains(node))
				{
					insection.add(node);
				}
			}
		}
		return insection;
	}

	/* (Tested) Get the number of links in a component */
	public int get_link_number_of_component(TreeSet<Integer> component)
	{
		int m = 0;
		if (component.isEmpty())
		{
			return 0;
		} else
		{
			while (!component.isEmpty())
			{
				int member = component.pollFirst();
				TreeSet<Integer> neighbors = get_node_neighbors(member);
				TreeSet<Integer> insection = get_insection(component, neighbors);
				m += insection.size();
			}
		}
		// System.out.println("link number: " + m);
		return m;
	}

	/* (Tested) Get priority of all nodes */
	public void get_all_nodes_priority()
	{
		for (int id = 0; id < this.n; id++)
		{
			TreeSet<Integer> component = get_node_neighbors(id);
			component.add(id);
			int component_size = component.size();
			int link_number = get_link_number_of_component(component);
			double priority = (double) (link_number)
					/ (double) (component_size);
			NodePriority node_priority = new NodePriority(id, priority);
			this.all_nodes_priority.add(node_priority);
		}
		// System.out.println("all_nodes_priority: ");
		// for (Iterator<NodePriority> iter = all_nodes_priority.iterator();
		// iter
		// .hasNext();)
		// {
		// NodePriority node = iter.next();
		// System.out.println(node);
		// }
	}

	/* (Tested) Get nodes similiarity */
	public double get_nodes_simililarity(int node1, int node2)
	{
		double simililarity = 0;
		TreeSet<Integer> neighbors_of_node1 = get_node_neighbors(node1);
		TreeSet<Integer> neighbors_of_node2 = get_node_neighbors(node2);
		TreeSet<Integer> insection = get_insection(neighbors_of_node1,
				neighbors_of_node2);
		int insection_size = insection.size();
		int neighbors_of_node1_size = neighbors_of_node1.size();
		int neighbors_of_node2_size = neighbors_of_node2.size();
		simililarity = (double) (insection_size)
				/ (double) (Math.sqrt(neighbors_of_node1_size
						* neighbors_of_node2_size));
		return simililarity;
	}

	/* (Tested) Get weak clique set */
	public ArrayList<TreeSet<Integer>> get_weak_clique_set()
	{
		ArrayList<TreeSet<Integer>> weak_clique_set = new ArrayList<TreeSet<Integer>>();
		while (!this.all_nodes_priority.isEmpty())
		{
			NodePriority seed = all_nodes_priority.pollFirst();
			int seed_id = seed.id;
			TreeSet<Integer> neighbors = get_node_neighbors(seed_id);
			TreeSet<Integer> weak_clique = new TreeSet<Integer>();
			while (!neighbors.isEmpty())
			{
				double max_similarity = -1;
				int candidate_neighbor = -1;
				for (Iterator<Integer> iter = neighbors.iterator(); iter
						.hasNext();)
				{
					Integer neighbor = iter.next();
					double similiarity = get_nodes_simililarity(seed_id,
							neighbor);
					if (similiarity > max_similarity)
					{
						max_similarity = similiarity;
						candidate_neighbor = neighbor;
					}
				}
				if (candidate_neighbor != -1)
				{
					/* get weak clique */
					TreeSet<Integer> neighbors_of_seed = get_node_neighbors(seed_id);
					TreeSet<Integer> neighbors_of_candidate_neighbor = get_node_neighbors(candidate_neighbor);
					TreeSet<Integer> clique = get_insection(neighbors_of_seed,
							neighbors_of_candidate_neighbor);
					clique.add(seed_id);
					clique.add(candidate_neighbor);
					// System.out.println("seed: " + seed_id + " neighbor:"
					// + candidate_neighbor + " " + weak_clique);
					neighbors.removeAll(clique);
					weak_clique.addAll(clique);
				} else
				{
					System.out.println("weak clique is empty");
				}
			}
			/* update unused seeds */
			ArrayList<NodePriority> nodes_to_be_removed = new ArrayList<NodePriority>();
			for (Iterator<NodePriority> iter = this.all_nodes_priority
					.iterator(); iter.hasNext();)
			{
				NodePriority node_priority = iter.next();
				if (weak_clique.contains(node_priority.id))
				{
					nodes_to_be_removed.add(node_priority);
				}
			}
			this.all_nodes_priority.removeAll(nodes_to_be_removed);
			/* update weak clique set */
			weak_clique_set.add(weak_clique);
		}
		// System.out.println("weak_clique_set: ");
		// for (Iterator<TreeSet<Integer>> iter = weak_clique_set.iterator();
		// iter
		// .hasNext();)
		// {
		// System.out.println(iter.next());
		// }
		return weak_clique_set;
	}

	/* (Tested) To judge if the insevtion of two node sets is not empty */
	public boolean is_insection_of_components_not_empty(
			TreeSet<Integer> node_set_1, TreeSet<Integer> node_set_2)
	{
		if (node_set_1.size() < node_set_2.size())
		{
			for (Iterator<Integer> iter = node_set_1.iterator(); iter.hasNext();)
			{
				Integer member = iter.next();
				if (node_set_2.contains(member))
				{
					return true;
				}
			}
			return false;
		} else
		{
			for (Iterator<Integer> iter = node_set_2.iterator(); iter.hasNext();)
			{
				Integer member = iter.next();
				if (node_set_1.contains(member))
				{
					return true;
				}
			}
			return false;
		}
	}

	/* (Tested) Get the neighbor communities of a community */
	public ArrayList<TreeSet<Integer>> get_neighbor_communities(
			ArrayList<TreeSet<Integer>> weak_clique_set,
			TreeSet<Integer> weak_clique)
	{
		// System.out.println("neighbor_cliques: ");
		ArrayList<TreeSet<Integer>> neighbor_cliques = new ArrayList<TreeSet<Integer>>();
		for (Iterator<TreeSet<Integer>> iter = weak_clique_set.iterator(); iter
				.hasNext();)
		{
			TreeSet<Integer> clique = iter.next();
			if ((!clique.equals(weak_clique))
					&& is_insection_of_components_not_empty(clique, weak_clique))
			{
				neighbor_cliques.add(clique);
				// System.out.println(clique);
			}
		}
		return neighbor_cliques;
	}

	/* (Tested) Get the number of links between two cliques */
	public int get_link_number_between_cliques(TreeSet<Integer> clique1,
			TreeSet<Integer> clique2)
	{
		int m = 0;
		TreeSet<WCPMLink> links = new TreeSet<WCPMLink>(new WCPMLink());
		for (Iterator<Integer> iter = clique1.iterator(); iter.hasNext();)
		{
			Integer member = iter.next();
			TreeSet<Integer> neighbors = get_node_neighbors(member);
			TreeSet<Integer> insection = get_insection(clique2, neighbors);
			for (Iterator<Integer> iter2 = insection.iterator(); iter2
					.hasNext();)
			{
				Integer neighbor = iter2.next();
				if (member < neighbor)
				{
					WCPMLink link = new WCPMLink(member, neighbor);
					if (!links.contains(link))
					{
						links.add(link);
						m++;
					}
				} else
				{
					WCPMLink link = new WCPMLink(neighbor, member);
					if (!links.contains(link))
					{
						links.add(link);
						m++;
					}
				}
			}
			// System.out.println(member + "," + insection);
		}
		// System.out.println(m + "," + clique1 + "," + clique2);
		return m;
	}

	/* (Tested) Get clique similiarity */
	public double get_cliques_similiarity(TreeSet<Integer> clique1,
			TreeSet<Integer> clique2)
	{
		double similiarity = 0;
		TreeSet<Integer> insection = get_insection(clique1, clique2);
		int n = insection.size();
		int m = get_link_number_between_cliques(clique1, clique2);
		int x = 0;
		int clique1_size = clique1.size();
		int clique2_size = clique2.size();
		if (clique1_size < clique2_size)
		{
			x = clique1_size;
		} else
		{
			x = clique2_size;
		}
		similiarity = (double) (m + n) / (double) (x);
		// System.out.println(n + "," + m + "," + x + "," + similiarity);
		return similiarity;
	}

	/* (Tested) Merger weak cliques */
	public ArrayList<TreeSet<Integer>> merger_weak_cliques(
			ArrayList<TreeSet<Integer>> weak_clique_set)
	{
		ArrayList<TreeSet<Integer>> communities = new ArrayList<TreeSet<Integer>>();
		while (!weak_clique_set.isEmpty())
		{
			TreeSet<Integer> weak_clique = weak_clique_set.remove(0);
			// System.out.println("weak_clique: " + weak_clique);
			TreeSet<Integer> communtiy = new TreeSet<Integer>();
			communtiy.addAll(weak_clique);
			ArrayList<TreeSet<Integer>> queue = new ArrayList<TreeSet<Integer>>();
			queue.add(weak_clique);
			while (!queue.isEmpty())
			{
				weak_clique = queue.remove(0);
				ArrayList<TreeSet<Integer>> neighbors_cliques = get_neighbor_communities(
						weak_clique_set, weak_clique);
				double max_similiarity = 0.6;
				for (Iterator<TreeSet<Integer>> iter = neighbors_cliques
						.iterator(); iter.hasNext();)
				{
					TreeSet<Integer> neighbor_clique = iter.next();
					double similiarity = get_cliques_similiarity(weak_clique,
							neighbor_clique);
					if (similiarity > max_similiarity)
					{
						queue.add(neighbor_clique);
						weak_clique_set.remove(neighbor_clique);
						communtiy.addAll(neighbor_clique);
						// System.out.println("neighbor_clique: "
						// + neighbor_clique);
					}
				}
			}
			// System.out.println("communtiy: " + communtiy);
			communities.add(communtiy);
		}
		return communities;
	}

	public ArrayList<TreeSet<Integer>> run_wcpm()
	{
		// ArrayList<TreeSet<Integer>> finial_communities = new
		// ArrayList<TreeSet<Integer>>();
		get_all_nodes_priority();
		ArrayList<TreeSet<Integer>> weak_clique_set = get_weak_clique_set();
		ArrayList<TreeSet<Integer>> communities = merger_weak_cliques(weak_clique_set);
		// for (Iterator<TreeSet<Integer>> iter = communities.iterator(); iter
		// .hasNext();)
		// {
		// TreeSet<Integer> communtiy = iter.next();
		// TreeSet<Integer> temp_community = new TreeSet<Integer>();
		// temp_community.addAll(communtiy);
		// finial_communities.add(temp_community);
		// }
		return communities;
	}

	public static void main(String[] args) throws IOException
	{
		String file_path = "D:/real world networks/";
		String file_name = "amazon";
		// karate;dolphin;football;krebsbook;dblp;amazon;youtube
		String community = "_community.txt";
		String table = "_table.txt";
		String file_path_community = file_path + file_name + community;
		String file_path_table = file_path + file_name + table;

		DataReaderRealWorldNetwork data_reader = new DataReaderRealWorldNetwork(
				file_path_community, file_path_table);
		data_reader.read_realworld_network();

		WCPMAlgorithm wcpm = new WCPMAlgorithm(data_reader.n,
				data_reader.adjacencyTable);
		wcpm.run_wcpm();
	}
}
