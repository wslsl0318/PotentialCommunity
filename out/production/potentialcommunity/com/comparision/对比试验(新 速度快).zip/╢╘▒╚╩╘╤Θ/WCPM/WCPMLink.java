package com.dingxiaoyu.WCPM;

import java.util.Comparator;

public class WCPMLink implements Comparator<WCPMLink>
{
	public int id1;
	public int id2;

	public WCPMLink()
	{

	}

	public WCPMLink(int id1, int id2)
	{
		this.id1 = id1;
		this.id2 = id2;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + id1;
		result = prime * result + id2;
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WCPMLink other = (WCPMLink) obj;
		if (id1 != other.id1)
			return false;
		if (id2 != other.id2)
			return false;
		return true;
	}

	@Override
	public String toString()
	{
		return "WCPMLink [id1=" + id1 + ", id2=" + id2 + "]";
	}

	@Override
	public int compare(WCPMLink o1, WCPMLink o2)
	{
		WCPMLink node1 = o1;
		WCPMLink node2 = o2;
		if (node1.id1 < node2.id1)
		{
			return -1;
		} else if (node1.id1 == node2.id1)
		{
			if (node1.id2 < node2.id2)
			{
				return -1;
			} else if (node1.id2 == node2.id2)
			{
				return 0;
			} else if (node1.id2 > node2.id2)
			{
				return 1;
			}
		} else if (node1.id1 > node2.id1)
		{
			return 1;
		}
		return 0;
	}

}
