package com.dingxiaoyu.TWD;

public class NodeLIV
{
	public int id;
	public double liv;

	public NodeLIV()
	{

	}

	public NodeLIV(int id, double liv)
	{
		this.id = id;
		this.liv = liv;
	}

	@Override
	public String toString()
	{
		return "NodeLIV [id=" + id + ", liv=" + liv + "]";
	}

}
