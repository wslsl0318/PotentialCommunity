package com.dingxiaoyu.methods;

import java.util.ArrayList;

public class Measures
{
	public double NMI;
	public double Q;
	public long time;
	public ArrayList<Double> rpf;

	public Measures()
	{

	}

	public Measures(double NMI, double Q, long costTime, ArrayList<Double> rpf)
	{
		this.NMI = NMI;
		this.Q = Q;
		this.time = costTime;
		this.rpf = rpf;
	}

	@Override
	public String toString()
	{
		return "Measures [NMI=" + NMI + ", Q=" + Q + ", time=" + time
				+ ", rpf=" + rpf + "]";
	}
}
