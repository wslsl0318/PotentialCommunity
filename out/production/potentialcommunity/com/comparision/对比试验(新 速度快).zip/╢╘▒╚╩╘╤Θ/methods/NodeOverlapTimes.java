package com.dingxiaoyu.methods;

public class NodeOverlapTimes
{
	public int node_id;
	public int overlap_times;

	public NodeOverlapTimes()
	{

	}

	public NodeOverlapTimes(int node_id, int overlap_times)
	{
		this.node_id = node_id;
		this.overlap_times = overlap_times;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + node_id;
		result = prime * result + overlap_times;
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NodeOverlapTimes other = (NodeOverlapTimes) obj;
		if (node_id != other.node_id)
			return false;
		if (overlap_times != other.overlap_times)
			return false;
		return true;
	}

	@Override
	public String toString()
	{
		return "NodeOverlapTimes [node_id=" + node_id + ", overlap_times="
				+ overlap_times + "]";
	}

	
}
