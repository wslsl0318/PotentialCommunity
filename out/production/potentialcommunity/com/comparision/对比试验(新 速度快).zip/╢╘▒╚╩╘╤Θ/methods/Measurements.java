package com.dingxiaoyu.methods;

public class Measurements
{
	public String algorithm_name;
	public long Time;
	public double NMI;
	public double Q;
	public double R;
	public double P;
	public double F;
	public double FMeasure;
	public double V;
	public double no;
	public double D;

	public Measurements()
	{

	}

	public Measurements(String algorithm_name, long Time, double NMI, double Q,
			double R, double P, double F, double FMeasure, double V, double no,
			double C)
	{
		this.algorithm_name = algorithm_name;
		this.Time = Time;
		this.NMI = NMI;
		this.Q = Q;
		this.R = R;
		this.P = P;
		this.F = F;
		this.FMeasure = FMeasure;
		this.V = V;
		this.no = no;
		this.D = C;
	}
}
