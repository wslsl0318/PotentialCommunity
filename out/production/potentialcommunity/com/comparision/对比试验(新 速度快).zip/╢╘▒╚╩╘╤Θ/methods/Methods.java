//package com.dingxiaoyu.methods;
//
//import java.io.IOException;
//import java.security.AllPermission;
//import java.util.ArrayList;
//import java.util.Iterator;
//import java.util.TreeSet;
//
//import com.dingxiaoyu.cfinder.CFinder;
//import com.dingxiaoyu.coresimple.CommunityBasedOnCores;
//import com.dingxiaoyu.docnet.DOCnet;
//import com.dingxiaoyu.eagle.EAGLE;
//import com.dingxiaoyu.gce.GCE;
//import com.dingxiaoyu.lfm.LFM;
//import com.fileoperations.methods.FileReaders;
//import com.fileoperations.methods.FileWriters;
//import com.publicstructures.methods.CommunityStructure;
//import com.publicstructures.methods.CommunityStructureOverlap;
//import com.pulicoperations.methods.AdjacencyTables;
//import com.pulicoperations.methods.NMI;
//import com.pulicoperations.methods.OverlapNMI;
//import com.pulicoperations.methods.Partitions;
//import com.pulicoperations.methods.RPF;
//
//public class Methods
//{
//	public String filePath;
//	public String filePathOfRealCommunities;
//	public FileReaders fr;
//	public int size;
//	public int m;
//	public int[][] adjacencyMatrix;
//	public ArrayList<ArrayList<Integer>> adjacencyTable;
//	public ArrayList<ArrayList<Integer>> realCommunities;
//	public ArrayList<ArrayList<Integer>> realCommunities_overlap;
//
//	public Methods()
//	{
//		this.adjacencyTable = new ArrayList<ArrayList<Integer>>();
//		this.realCommunities = new ArrayList<ArrayList<Integer>>();
//		this.realCommunities_overlap = new ArrayList<ArrayList<Integer>>();
//	}
//
//	public Methods(String filePath, String filePathOfRealCommunities)
//			throws IOException
//	{
//		this.filePath = filePath;
//		this.filePathOfRealCommunities = filePathOfRealCommunities;
//		this.fr = new FileReaders(filePath);
//		try
//		{
//			fr.readFile(false, false);
//		} catch (IOException e)
//		{
//			e.printStackTrace();
//		}
//		this.size = fr.size;
//		this.adjacencyMatrix = fr.adjacencyMatrix;
//		this.adjacencyTable = AdjacencyTables.getAdjacencyTable(size,
//				fr.adjacencyMatrix);
//		this.m = get_edge_number();
//		String[] strs = FileReaders
//				.readRealCommunities(filePathOfRealCommunities);
//		this.realCommunities = CommunityStructure.getComponentsFromString(strs);
//		// ArrayList<CommunityStructureOverlap> communities_structure_overlap =
//		// FileReaders
//		// .get_communities_structure_overlap(filePathOfRealCommunities);
//		// this.realCommunities_overlap = CommunityStructureOverlap
//		// .get_communities_overlap(communities_structure_overlap);
//	}
//
//	/********************************************************************************************/
//	/* Get overlap modularity */
//	/* Get number of edges */
//	public int get_edge_number()
//	{
//		int m = 0;
//		for (Iterator<ArrayList<Integer>> iter_line = adjacencyTable.iterator(); iter_line
//				.hasNext();)
//		{
//			ArrayList<Integer> line = iter_line.next();
//			m += (line.size() - 1);
//		}
//		m = m / 2;
//		return m;
//	}
//
//	/*
//	 * Get number of overlap communities(the number of communities that node
//	 * belongs to)
//	 */
//	public int get_overlap_number(
//			ArrayList<NodeOverlapTimes> partition_overlap_nodes, int node_id)
//	{
//		int overlap_number = 0;
//		for (Iterator<NodeOverlapTimes> iter_node = partition_overlap_nodes
//				.iterator(); iter_node.hasNext();)
//		{
//			NodeOverlapTimes node = iter_node.next();
//			if (node.node_id == node_id)
//			{
//				return node.overlap_times;
//			}
//		}
//		return overlap_number;
//	}
//
//	/* Calculate overlap modularity */
//	public double calculate_Q(ArrayList<ArrayList<Integer>> communities,
//			ArrayList<NodeOverlapTimes> partition_overlap_nodes)
//	{
//		double Q = 0;
//		for (int i = 0; i < communities.size(); i++)
//		{
//			ArrayList<Integer> community = new ArrayList<Integer>();
//			community.addAll(communities.get(i));
//			double sum = 0;
//			for (int j = 0; j < community.size(); j++)
//			{
//				int node_1 = community.get(j);
//				for (int k = 0; k < community.size(); k++)
//				{
//					int node_2 = community.get(k);
//					int avw;
//					if (adjacencyMatrix[node_1][node_2] != 0)
//					{
//						avw = 1;
//					} else
//					{
//						avw = 0;
//					}
//					int kv = adjacencyTable.get(node_1).size() - 1;
//					int kw = adjacencyTable.get(node_2).size() - 1;
//					double x = kv * kw / (double) (2 * m);
//					int o_node_1 = get_overlap_number(partition_overlap_nodes,
//							node_1);
//					int o_node_2 = get_overlap_number(partition_overlap_nodes,
//							node_2);
//					sum += ((avw - x) / (o_node_1 * o_node_2));
//				}
//			}
//			Q += sum;
//		}
//		Q /= (2 * m);
//		return Q;
//	}
//
//	/********************************************************************************************/
//	/* Get overlap NMI */
//	/* Get Hx or Hy */
//	public double get_Hx_or_Hy(ArrayList<ArrayList<Integer>> communities, int N)
//	{
//		int h = 0;
//		for (int k = 0; k < communities.size(); k++)
//		{
//			double h1 = h(communities.get(k).size(), N);
//			double h2 = h(N - communities.get(k).size(), N);
//			h += (h1 + h2);
//		}
//		return h;
//	}
//
//	/* Get a,b,c,d (tested) */
//	public int[] get_abcd(ArrayList<ArrayList<Integer>> partitionTruth, int i,
//			ArrayList<ArrayList<Integer>> partitionFound, int j, int N)
//	{
//		int[] abcd = new int[4];
//		int a = 0;
//		int b = 0;
//		int c = 0;
//		int d = 0;
//		TreeSet<Integer> community_truth = new TreeSet<Integer>();
//		community_truth.addAll(partitionTruth.get(i));
//		TreeSet<Integer> community_found = new TreeSet<Integer>();
//		community_found.addAll(partitionFound.get(j));
//		for (int k = 0; k < N; k++)
//		{
//			if (!community_truth.contains((Integer) k)
//					&& !community_found.contains((Integer) k))
//			{
//				a++;
//			} else if (!community_truth.contains((Integer) k)
//					&& community_found.contains((Integer) k))
//			{
//				b++;
//			} else if (community_truth.contains((Integer) k)
//					&& !community_found.contains((Integer) k))
//			{
//				c++;
//			} else if (community_truth.contains((Integer) k)
//					&& community_found.contains((Integer) k))
//			{
//				d++;
//			}
//		}
//		abcd[0] = a;
//		abcd[1] = b;
//		abcd[2] = c;
//		abcd[3] = d;
//		return abcd;
//	}
//
//	/* Get overlap NMI */
//	public double NMIPartitionLFK(ArrayList<ArrayList<Integer>> partitionTruth,
//			ArrayList<ArrayList<Integer>> partitionFound, int nodeCount)
//	{
//		int i = 0;
//		int j = 0;
//		int N = nodeCount;
//		double Hx = 0;
//		double Hy = 0;
//		Hx = get_Hx_or_Hy(partitionTruth, N);
//		// System.out.println(Hx);
//		Hy = get_Hx_or_Hy(partitionFound, N);
//		// System.out.println(Hy);
//		// calculate the H(X|Y) and H(Y|x)
//		double Hx_y = 0.0;
//		double Hy_x = 0.0;
//		double Ha, Hb, Hc, Hd, Hxi_yj;
//		// H(X|Y)
//		for (i = 0; i < partitionTruth.size(); i++)
//		{
//			double Hxi_y = Double.MAX_VALUE;
//			for (j = 0; j < partitionFound.size(); j++)
//			{
//				Hxi_yj = 0.0;
//				int[] abcd = new int[4];
//				abcd = get_abcd(partitionTruth, i, partitionFound, j, N);
//				if (abcd[0] == 0 || abcd[0] == N)
//				{
//					Ha = 0;
//				} else
//				{
//					Ha = h(abcd[0], N);
//				}
//				if (abcd[1] == 0 || abcd[1] == N)
//				{
//					Hb = 0;
//				} else
//				{
//					Hb = h(abcd[1], N);
//				}
//				if (abcd[2] == 0 || abcd[2] == N)
//				{
//					Hc = 0;
//				} else
//				{
//					Hc = h(abcd[2], N);
//				}
//				if (abcd[3] == 0 || abcd[3] == N)
//				{
//					Hd = 0;
//				} else
//				{
//					Hd = h(abcd[3], N);
//				}
//				// System.out.println(abcd[0] + "," + abcd[1] + "," + abcd[2]
//				// + "," + abcd[3]);
//				// System.out.println(Ha + "," + Hb + "," + Hc + "," + Hd);
//				if ((Ha + Hd) >= (Hb + Hc))
//				{
//					double Hac = 0;
//					if (abcd[0] + abcd[2] == 0 || abcd[0] + abcd[2] == N)
//					{
//						Hac = 0;
//					} else
//					{
//						Hac = h(abcd[0] + abcd[2], N);
//					}
//					double Hbd = 0;
//					if (abcd[1] + abcd[3] == 0 || abcd[1] + abcd[3] == N)
//					{
//						Hbd = 0;
//					} else
//					{
//						Hbd = h(abcd[1] + abcd[3], N);
//					}
//					Hxi_yj = Ha + Hb + Hc + Hd - Hac - Hbd;
//				} else
//				{
//					double Hab = 0;
//					if (abcd[0] + abcd[1] == 0 || abcd[0] + abcd[1] == N)
//					{
//						Hab = 0;
//					} else
//					{
//						Hab = h(abcd[0] + abcd[1], N);
//					}
//					double Hcd = 0;
//					if (abcd[2] + abcd[3] == 0 || abcd[2] + abcd[3] == N)
//					{
//						Hcd = 0;
//					} else
//					{
//						Hcd = h(abcd[2] + abcd[3], N);
//					}
//					Hxi_yj = Hab + Hcd;
//				}
//				if (Hxi_yj < Hxi_y)
//				{
//					Hxi_y = Hxi_yj;
//				}
//			}
//			Hx_y += Hxi_y;
//		}
//		// H(Y|X)
//		for (i = 0; i < partitionFound.size(); i++)
//		{
//			double Hxi_y = Double.MAX_VALUE;
//			for (j = 0; j < partitionTruth.size(); j++)
//			{
//				Hxi_yj = 0.0;
//				int[] abcd = new int[4];
//				abcd = get_abcd(partitionFound, i, partitionTruth, j, N);
//				if (abcd[0] == 0 || abcd[0] == N)
//				{
//					Ha = 0;
//				} else
//				{
//					Ha = h(abcd[0], N);
//				}
//				if (abcd[1] == 0 || abcd[1] == N)
//				{
//					Hb = 0;
//				} else
//				{
//					Hb = h(abcd[1], N);
//				}
//				if (abcd[2] == 0 || abcd[2] == N)
//				{
//					Hc = 0;
//				} else
//				{
//					Hc = h(abcd[2], N);
//				}
//				if (abcd[3] == 0 || abcd[3] == N)
//				{
//					Hd = 0;
//				} else
//				{
//					Hd = h(abcd[3], N);
//				}
//				if ((Ha + Hd) >= (Hb + Hc))
//				{
//					double Hac = 0;
//					if (abcd[0] + abcd[2] == 0 || abcd[0] + abcd[2] == N)
//					{
//						Hac = 0;
//					} else
//					{
//						Hac = h(abcd[0] + abcd[2], N);
//					}
//					double Hbd = 0;
//					if (abcd[1] + abcd[3] == 0 || abcd[1] + abcd[3] == N)
//					{
//						Hbd = 0;
//					} else
//					{
//						Hbd = h(abcd[1] + abcd[3], N);
//					}
//					Hxi_yj = Ha + Hb + Hc + Hd - Hac - Hbd;
//				} else
//				{
//					double Hab = 0;
//					if (abcd[0] + abcd[1] == 0 || abcd[0] + abcd[1] == N)
//					{
//						Hab = 0;
//					} else
//					{
//						Hab = h(abcd[0] + abcd[1], N);
//					}
//					double Hcd = 0;
//					if (abcd[2] + abcd[3] == 0 || abcd[2] + abcd[3] == N)
//					{
//						Hcd = 0;
//					} else
//					{
//						Hcd = h(abcd[2] + abcd[3], N);
//					}
//					Hxi_yj = Hab + Hcd;
//				}
//				if (Hxi_yj < Hxi_y)
//				{
//					Hxi_y = Hxi_yj;
//				}
//			}
//			Hy_x += Hxi_y;
//		}
//		// System.out.println(Hx_y + "," + Hy_x);
//		double Hxy_Hx = 0;
//		if (Hx_y == 0 && Hx == 0)
//		{
//			Hxy_Hx = 0;
//		} else
//		{
//			Hxy_Hx = Hx_y / Hx;
//		}
//		double Hyx_Hy = 0;
//		if (Hy_x == 0 && Hy == 0)
//		{
//			Hyx_Hy = 0;
//		} else
//		{
//			Hyx_Hy = Hy_x / Hy;
//		}
//		double Ixy = 0.5 * (Hxy_Hx + Hyx_Hy);
//		double InormXY = 1 - Ixy;
//		return InormXY;
//	}
//
//	/* Build the Matrix from clu and node (tested) */
//	public int[][] bulid_matrix(ArrayList<ArrayList<Integer>> partition)
//	{
//		int size_row = size;
//		int size_column = partition.size();
//		int[][] matrix = new int[size_row][size_column];
//		for (int i = 0; i < size_row; i++)
//		{
//			for (int j = 0; j < size_column; j++)
//			{
//				if (partition.get(j).contains((Integer) i))
//				{
//					matrix[i][j] = 1;
//				} else
//				{
//					matrix[i][j] = 0;
//				}
//			}
//		}
//		return matrix;
//	}
//
//	/* Calculate a,b,c,d (tested) */
//	public int[] calculate_a_b_c_d(int[][] matrix_X, int[][] matrix_Y, int i,
//			int j)
//	{
//		int[] a_b_c_d = new int[4];
//		int a = 0;
//		int b = 0;
//		int c = 0;
//		int d = 0;
//		for (int m = 0; m < size; m++)
//		{
//			if (matrix_X[m][i] == 0 && matrix_Y[m][j] == 0)
//			{
//				a++;
//			} else if (matrix_X[m][i] == 0 && matrix_Y[m][j] != 0)
//			{
//				b++;
//			} else if (matrix_X[m][i] != 0 && matrix_Y[m][j] == 0)
//			{
//				c++;
//			} else if (matrix_X[m][i] != 0 && matrix_Y[m][j] != 0)
//			{
//				d++;
//			}
//		}
//		a_b_c_d[0] = a;
//		a_b_c_d[1] = b;
//		a_b_c_d[2] = c;
//		a_b_c_d[3] = d;
//		return a_b_c_d;
//	}
//
//	/* calculate H*(Xi|Yj) (tested) */
//	public double calculate_H_Xi_Yj(int[][] matrix_X, int[][] matrix_Y, int i,
//			int j)
//	{
//		double H_Xi_Yj = 0;
//		double H_a = 0;
//		double H_b = 0;
//		double H_c = 0;
//		double H_d = 0;
//		double H_a_c = 0;
//		double H_b_d = 0;
//		double H_a_b = 0;
//		double H_c_d = 0;
//		int[] a_b_c_d = calculate_a_b_c_d(matrix_X, matrix_Y, i, j);
//		H_a = h(a_b_c_d[0], size);
//		H_b = h(a_b_c_d[1], size);
//		H_c = h(a_b_c_d[2], size);
//		H_d = h(a_b_c_d[3], size);
//		if ((H_a + H_d) >= (H_b + H_c))
//		{
//			H_a_c = h(a_b_c_d[0] + a_b_c_d[2], size);
//			H_b_d = h(a_b_c_d[1] + a_b_c_d[3], size);
//			H_Xi_Yj = H_a + H_b + H_c + H_d - H_a_c - H_b_d;
//		} else
//		{
//			H_a_b = h(a_b_c_d[0] + a_b_c_d[1], size);
//			H_c_d = h(a_b_c_d[2] + a_b_c_d[3], size);
//			H_Xi_Yj = H_a_b + H_c_d;
//		}
//		return H_Xi_Yj;
//	}
//
//	/* calculate H(X|Y) (tested) */
//	public double calculate_H_X_Y(int[][] matrix_X, int[][] matrix_Y,
//			int k_X_size, int k_Y_size)
//	{
//		double H_X_Y = 0;
//		/* calculate H(X|Y) */
//		for (int i = 0; i < k_X_size; i++)
//		{
//			/* calculate H(Xi|Y) */
//			double H_Xi_Y = Double.POSITIVE_INFINITY;
//			for (int j = 0; j < k_Y_size; j++)
//			{
//				double H_Xi_Yj = calculate_H_Xi_Yj(matrix_X, matrix_Y, i, j);
//				if (H_Xi_Y > H_Xi_Yj)
//				{
//					H_Xi_Y = H_Xi_Yj;
//				}
//			}
//			H_X_Y += H_Xi_Y;
//		}
//		return H_X_Y;
//	}
//
//	/* calculate H(X) (or H(Y)) (tested) */
//	public double calculate_H_X_or_H_Y(int[][] matrix_X, int k_X_size)
//	{
//		double H_X = 0;
//		for (int i = 0; i < k_X_size; i++)
//		{
//			int value_0 = 0;
//			int value_1 = 0;
//			for (int m = 0; m < size; m++)
//			{
//				if (matrix_X[m][i] == 0)
//				{
//					value_0++;
//				} else
//				{
//					value_1++;
//				}
//			}
//			H_X += (h(value_0, size) + h(value_1, size));
//		}
//		return H_X;
//	}
//
//	/* calculate NMI_LFK (tested) */
//	public double NMIPartitionLFK(ArrayList<ArrayList<Integer>> partitionTruth,
//			ArrayList<ArrayList<Integer>> partitionFound)
//	{
//		if (partitionFound.size() == 1)
//		{
//			return 0;
//		}
//		double nmi_lfk = 0;
//		/* Get matrix X and Y (tested) */
//		int[][] matrix_X = bulid_matrix(partitionTruth);
//		int[][] matrix_Y = bulid_matrix(partitionFound);
//		int k_X_size = partitionTruth.size();
//		int k_Y_size = partitionFound.size();
//		double H_X = calculate_H_X_or_H_Y(matrix_X, k_X_size);
//		double H_Y = calculate_H_X_or_H_Y(matrix_Y, k_Y_size);
//		double H_X_Y = calculate_H_X_Y(matrix_X, matrix_Y, k_X_size, k_Y_size);
//		double H_Y_X = calculate_H_X_Y(matrix_Y, matrix_X, k_Y_size, k_X_size);
//		nmi_lfk = 1 - 0.5 * (H_X_Y / H_X + H_Y_X / H_Y);
//		return nmi_lfk;
//	}
//
//	/* h function */
//	private double h(int w, int n)
//	{
//		if (w == n || w == 0)
//		{
//			return 0;
//		} else
//		{
//			return -w * 1.0 * Math.log(w * 1.0 / (1.0 * n)) / Math.log(2.0);
//		}
//	}
//
//	/********************************************************************************************/
//	/* Get recall,precision,f-score */
//	/* Get overlap nodes */
//	public ArrayList<NodeOverlapTimes> get_overlap_nodes(
//			ArrayList<ArrayList<Integer>> partition)
//	{
//		ArrayList<NodeOverlapTimes> overlap_nodes = new ArrayList<NodeOverlapTimes>();
//		for (int i = 0; i < size; i++)
//		{
//			int count = 0;
//			for (Iterator<ArrayList<Integer>> iter_community = partition
//					.iterator(); iter_community.hasNext();)
//			{
//				ArrayList<Integer> community = iter_community.next();
//				if (community.contains((Integer) i))
//				{
//					count++;
//				}
//			}
//			NodeOverlapTimes node_overlap_times = new NodeOverlapTimes(i, count);
//			overlap_nodes.add(node_overlap_times);
//		}
//		return overlap_nodes;
//	}
//
//	/* get insection */
//	public TreeSet<Integer> get_insection(TreeSet<Integer> set_1,
//			TreeSet<Integer> set_2)
//	{
//		TreeSet<Integer> insection = new TreeSet<Integer>();
//		for (Iterator<Integer> iter = set_1.iterator(); iter.hasNext();)
//		{
//			Integer member = iter.next();
//			if (set_2.contains(member))
//			{
//				insection.add(member);
//			}
//		}
//		return insection;
//	}
//
//	/* Get recall,precision,f-score */
//	public ArrayList<Double> get_recall_precision_fscore(
//			ArrayList<NodeOverlapTimes> partitionR_overlap_nodes,
//			ArrayList<NodeOverlapTimes> partitionF_overlap_nodes)
//	{
//		ArrayList<Double> rpf = new ArrayList<Double>();
//		TreeSet<Integer> partitionR_overlap_node_ids = new TreeSet<Integer>();
//		TreeSet<Integer> partitionF_overlap_node_ids = new TreeSet<Integer>();
//		for (Iterator<NodeOverlapTimes> iter = partitionR_overlap_nodes
//				.iterator(); iter.hasNext();)
//		{
//			NodeOverlapTimes member = iter.next();
//			if (member.overlap_times > 1)
//			{
//				partitionR_overlap_node_ids.add(member.node_id);
//			}
//		}
//		for (Iterator<NodeOverlapTimes> iter = partitionF_overlap_nodes
//				.iterator(); iter.hasNext();)
//		{
//			NodeOverlapTimes member = iter.next();
//			if (member.overlap_times > 1)
//			{
//				partitionF_overlap_node_ids.add(member.node_id);
//			}
//		}
//		TreeSet<Integer> insection = get_insection(partitionR_overlap_node_ids,
//				partitionF_overlap_node_ids);
//		// System.out.println(partitionR_overlap_node_ids);
//		// System.out.println(partitionF_overlap_node_ids);
//		// System.out.println(insection);
//		double insection_overlap_node_size = insection.size();
//		double partitionR_overlap_node_size = partitionR_overlap_node_ids
//				.size();
//		double partitionF_overlap_node_size = partitionF_overlap_node_ids
//				.size();
//		// System.out.println(partitionR_overlap_node_size + ","
//		// + partitionF_overlap_node_size + ","
//		// + insection_overlap_node_size);
//		double r = 0;
//		double p = 0;
//		double f = 0;
//		if (insection_overlap_node_size != 0)
//		{
//			if (partitionR_overlap_node_size != 0)
//			{
//				r = insection_overlap_node_size / partitionR_overlap_node_size;
//			}
//			if (partitionF_overlap_node_size != 0)
//			{
//				p = insection_overlap_node_size / partitionF_overlap_node_size;
//			}
//			if (partitionR_overlap_node_size != 0
//					&& partitionF_overlap_node_size != 0)
//			{
//				f = (2 * r * p) / (r + p);
//			}
//		}
//		rpf.add(r);
//		rpf.add(p);
//		rpf.add(f);
//		return rpf;
//	}
//
//	/********************************************************************************************/
//	/* Is a node do not belong to any community */
//	public boolean is_overlap_community_times_zero(
//			ArrayList<NodeOverlapTimes> partition_overlap_nodes, int node_id)
//	{
//		for (Iterator<NodeOverlapTimes> iter_node = partition_overlap_nodes
//				.iterator(); iter_node.hasNext();)
//		{
//			NodeOverlapTimes node = iter_node.next();
//			if (node.node_id == node_id && node.overlap_times == 0)
//			{
//				return true;
//			}
//		}
//		return false;
//	}
//
//	/* Get partationR_part */
//	public ArrayList<ArrayList<Integer>> get_partationR_part(
//			ArrayList<NodeOverlapTimes> partitionF_overlap_nodes,
//			ArrayList<ArrayList<Integer>> partitionR)
//	{
//		ArrayList<ArrayList<Integer>> partitionR_part = new ArrayList<ArrayList<Integer>>();
//		for (Iterator<ArrayList<Integer>> iter_community = partitionR
//				.iterator(); iter_community.hasNext();)
//		{
//			ArrayList<Integer> community = iter_community.next();
//			ArrayList<Integer> community_new = new ArrayList<Integer>();
//			for (Iterator<Integer> iter_node = community.iterator(); iter_node
//					.hasNext();)
//			{
//				Integer node = iter_node.next();
//				if (!is_overlap_community_times_zero(partitionF_overlap_nodes,
//						node))
//				{
//					community_new.add(node);
//				}
//			}
//			partitionR_part.add(community_new);
//		}
//		return partitionR_part;
//	}
//
//	public void out_print_partationF_measures(
//			ArrayList<ArrayList<Integer>> partitionF, double NMI, double Q,
//			long costTime, double r, double p, double f)
//	{
//		// System.out.println("partitionF:");
//		// for (Iterator<ArrayList<Integer>> iter_community = partitionF
//		// .iterator(); iter_community.hasNext();)
//		// {
//		// ArrayList<Integer> community = iter_community.next();
//		// System.out.println(community);
//		// }
//		System.out.println("NMI: " + NMI);
//		System.out.println("Q: " + Q);
//		System.out.println("Time cost: " + costTime);
//		System.out.println("R: " + r);
//		System.out.println("P: " + p);
//		System.out.println("F: " + f);
//	}
//
//	public void runMethods(String targetPath) throws IOException
//	{
//		System.out.println("*************************************************");
//		ArrayList<ArrayList<Integer>> partitionF = new ArrayList<ArrayList<Integer>>();
//		ArrayList<ArrayList<Integer>> partitionR = new ArrayList<ArrayList<Integer>>();
//		partitionR.addAll(realCommunities);
//		System.out.println("partitionR:");
//		for (Iterator<ArrayList<Integer>> iter_community = partitionR
//				.iterator(); iter_community.hasNext();)
//		{
//			ArrayList<Integer> community = iter_community.next();
//			for (Iterator<Integer> iter_member = community.iterator(); iter_member
//					.hasNext();)
//			{
//				Integer member = iter_member.next();
//				System.out.print(member + "\t");
//			}
//			System.out.println();
//		}
//		ArrayList<ArrayList<Integer>> partitionR_part = new ArrayList<ArrayList<Integer>>();
//		ArrayList<NodeOverlapTimes> partitionR_overlap_nodes = get_overlap_nodes(partitionR);
//		ArrayList<NodeOverlapTimes> partitionF_overlap_nodes = new ArrayList<NodeOverlapTimes>();
//		System.out.println("*************************************************");
//
//		Partitions partitions = null;
//		FileWriters fw = new FileWriters(fr);
//		String s1 = "_";
//		String s3 = ".clu";
//		String s2 = new String();
//		String targetCluPath = new String();
//
//		long startTime;
//		long endTime;
//		long costTime;
//
//		CommunityBasedOnCores cbc = new CommunityBasedOnCores(fr);
//		System.out.println("Coresimple:");
//		startTime = System.currentTimeMillis();
//		partitionF = cbc.get_final_communities();
//		endTime = System.currentTimeMillis();
//		costTime = endTime - startTime;
//		partitionF_overlap_nodes = get_overlap_nodes(partitionF);
//		// double coresimple_NMI = NMIPartitionLFK(partitionF, partitionR,
//		// size);
//		double coresimple_NMI = NMIPartitionLFK(partitionR, partitionF);
//		double coresimple_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
//		// ArrayList<Double> coresimple_RPF = RPF.getRecall_Precision_F(
//		// partitionF, partitionR);
//		// partitions = new Partitions(partitionF);
//		// s2 = "CommunityBasedOnCores_";
//		// targetCluPath = targetPath + s1 + s2 + s3;
//		// fw.writeCluFile(partitions, targetCluPath);
//		// out_print_partationF_measures(partitionF, coresimple_NMI,
//		// coresimple_Q,
//		// costTime);
//		double nmi_lfk = NMIPartitionLFK(partitionF, partitionR, size);
//		System.out.println("NMI:" + coresimple_NMI + "," + "Q: " + coresimple_Q
//				+ "time: " + costTime);
//		System.out.println("*************************************************");
//
//		// CFinder cfinder = new CFinder(fr, 3);
//		// System.out.println("CFinder:");
//		// partitionF = cfinder.get_k_clique_communities();
//		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
//		// partitionR_part = get_partationR_part(partitionF_overlap_nodes,
//		// partitionR);
//		// double cfinder_NMI = NMIPartitionLFK(partitionF, partitionR_part,
//		// size);
//		// double cfinder_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
//		// out_print_partationF_measures(partitionF, cfinder_NMI, cfinder_Q,
//		// costTime);
//		// System.out.println("*************************************************");
//		//
//		// EAGLE eagle = new EAGLE(fr, 4);
//		// System.out.println("EAGLE:");
//		// partitionF = eagle.merge_all_possiable_communities();
//		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
//		// double eagle_NMI = NMIPartitionLFK(partitionF, partitionR, size);
//		// double eagle_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
//		// out_print_partationF_measures(partitionF, eagle_NMI, eagle_Q,
//		// costTime);
//		// System.out.println("*************************************************");
//		//
//		// LFM lfm = new LFM(fr, 1);
//		// System.out.println("LFM:");
//		// partitionF = lfm.get_nature_communities();
//		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
//		// double lfm_NMI = NMIPartitionLFK(partitionF, partitionR, size);
//		// double lfm_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
//		// out_print_partationF_measures(partitionF, lfm_NMI, lfm_Q, costTime);
//		// System.out.println("*************************************************");
//		//
//		// GCE gce = new GCE(fr, 3, 1, 0.25);
//		// System.out.println("GCE:");
//		// partitionF = gce.get_nature_communities();
//		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
//		// double gce_NMI = NMIPartitionLFK(partitionF, partitionR, size);
//		// double gce_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
//		// out_print_partationF_measures(partitionF, gce_NMI, gce_Q, costTime);
//		// System.out.println("*************************************************");
//		//
//		// DOCnet docnet = new DOCnet(fr);
//		// System.out.println("DOCnet:");
//		// partitionF = docnet.get_all_communities();
//		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
//		// double docnet_NMI = NMIPartitionLFK(partitionF, partitionR, size);
//		// double docnet_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
//		// out_print_partationF_measures(partitionF, docnet_NMI, docnet_Q,
//		// costTime);
//		// System.out.println("*************************************************");
//	}
//
//	public ArrayList<Measures> runMethods(String targetPath, boolean flag)
//			throws IOException
//	{
//		ArrayList<Measures> all_algorithm_measure_values = new ArrayList<Measures>();
//		// System.out.println("*************************************************");
//		ArrayList<ArrayList<Integer>> partitionF = new ArrayList<ArrayList<Integer>>();
//		ArrayList<ArrayList<Integer>> partitionR = new ArrayList<ArrayList<Integer>>();
//		partitionR.addAll(realCommunities_overlap);
//		// System.out.println("partitionR:");
//		// for (Iterator<ArrayList<Integer>> iter_community = partitionR
//		// .iterator(); iter_community.hasNext();)
//		// {
//		// ArrayList<Integer> community = iter_community.next();
//		// System.out.println(community);
//		// }
//		ArrayList<ArrayList<Integer>> partitionR_part = new ArrayList<ArrayList<Integer>>();
//		ArrayList<NodeOverlapTimes> partitionR_overlap_nodes = get_overlap_nodes(partitionR);
//		ArrayList<NodeOverlapTimes> partitionF_overlap_nodes = new ArrayList<NodeOverlapTimes>();
//		ArrayList<Double> rpf = new ArrayList<Double>();
//		// System.out.println("*************************************************");
//
//		Partitions partitions = null;
//		FileWriters fw = new FileWriters(fr);
//		String s1 = "_";
//		String s3 = ".clu";
//		String s2 = new String();
//		String targetCluPath = new String();
//
//		long startTime;
//		long endTime;
//		long costTime;
//
//		CommunityBasedOnCores cbc = new CommunityBasedOnCores(fr);
//		// System.out.println("Coresimple:");
//		startTime = System.currentTimeMillis();
//		partitionF = cbc.get_final_communities();
//		endTime = System.currentTimeMillis();
//		costTime = endTime - startTime;
//		partitionF_overlap_nodes = get_overlap_nodes(partitionF);
//		double coresimple_NMI = NMIPartitionLFK(partitionR, partitionF);
//		double coresimple_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
//		rpf = get_recall_precision_fscore(partitionR_overlap_nodes,
//				partitionF_overlap_nodes);
//		Measures coresimple_measures = new Measures(coresimple_NMI,
//				coresimple_Q, costTime, rpf);
//
//		// CFinder cfinder = new CFinder(fr, 3);
//		// startTime = System.currentTimeMillis();
//		// partitionF = cfinder.get_k_clique_communities();
//		// endTime = System.currentTimeMillis();
//		// costTime = endTime - startTime;
//		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
//		// double cfinder_NMI = NMIPartitionLFK(partitionR, partitionF);
//		// double cfinder_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
//		// rpf = get_recall_precision_fscore(partitionR_overlap_nodes,
//		// partitionF_overlap_nodes);
//		// Measures cfinder_measures = new Measures(cfinder_NMI, cfinder_Q,
//		// costTime, rpf);
//		//
//		// EAGLE eagle = new EAGLE(fr, 4);
//		// startTime = System.currentTimeMillis();
//		// partitionF = eagle.merge_all_possiable_communities();
//		// endTime = System.currentTimeMillis();
//		// costTime = endTime - startTime;
//		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
//		// double eagle_NMI = NMIPartitionLFK(partitionR, partitionF);
//		// double eagle_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
//		// rpf = get_recall_precision_fscore(partitionR_overlap_nodes,
//		// partitionF_overlap_nodes);
//		// Measures eagle_measures = new Measures(eagle_NMI, eagle_Q, costTime,
//		// rpf);
//		//
//		// LFM lfm = new LFM(fr, 1);
//		// startTime = System.currentTimeMillis();
//		// partitionF = lfm.get_nature_communities();
//		// endTime = System.currentTimeMillis();
//		// costTime = endTime - startTime;
//		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
//		// double lfm_NMI = NMIPartitionLFK(partitionR, partitionF);
//		// double lfm_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
//		// rpf = get_recall_precision_fscore(partitionR_overlap_nodes,
//		// partitionF_overlap_nodes);
//		// Measures lfm_measures = new Measures(lfm_NMI, lfm_Q, costTime, rpf);
//		//
//		// GCE gce = new GCE(fr, 3, 1, 0.25);
//		// startTime = System.currentTimeMillis();
//		// partitionF = gce.get_nature_communities();
//		// endTime = System.currentTimeMillis();
//		// costTime = endTime - startTime;
//		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
//		// double gce_NMI = NMIPartitionLFK(partitionR, partitionF);
//		// double gce_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
//		// rpf = get_recall_precision_fscore(partitionR_overlap_nodes,
//		// partitionF_overlap_nodes);
//		// Measures gce_measures = new Measures(gce_NMI, gce_Q, costTime, rpf);
//		//
//		// DOCnet docnet = new DOCnet(fr);
//		// startTime = System.currentTimeMillis();
//		// partitionF = docnet.get_all_communities();
//		// endTime = System.currentTimeMillis();
//		// costTime = endTime - startTime;
//		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
//		// double docnet_NMI = NMIPartitionLFK(partitionR, partitionF);
//		// double docnet_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
//		// rpf = get_recall_precision_fscore(partitionR_overlap_nodes,
//		// partitionF_overlap_nodes);
//		// Measures docnet_measures = new Measures(docnet_NMI, docnet_Q,
//		// costTime,
//		// rpf);
//
//		all_algorithm_measure_values.add(coresimple_measures);
//		// all_algorithm_measure_values.add(cfinder_measures);
//		// all_algorithm_measure_values.add(eagle_measures);
//		// all_algorithm_measure_values.add(lfm_measures);
//		// all_algorithm_measure_values.add(gce_measures);
//		// all_algorithm_measure_values.add(docnet_measures);
//		return all_algorithm_measure_values;
//	}
//
//	public void run_methords_artificial_networks() throws IOException
//	{
//		/* Tests on artificial(lfr) networks */
//		String lfrFilePath = "D:/Sixth/tests on artificial(lfr) networks/";
//		String parameterFilePath = new String();
//		parameterFilePath = "mu/";
//		for (int i = 1; i <= 8; i++)
//		{
//			String valueFilePath = new String();
//			System.out.println(lfrFilePath + parameterFilePath
//					+ String.valueOf(i));
//			ArrayList<Measures> all_algorithm_measure_values_average = new ArrayList<Measures>();
//			/* NMI */
//			double average_coresimple_NMI = 0;
//			// double average_cfinder_NMI = 0;
//			// double average_eagle_NMI = 0;
//			// double average_lfm_NMI = 0;
//			// double average_gce_NMI = 0;
//			// double average_docnet_NMI = 0;
//			/* Q */
//			double average_coresimple_Q = 0;
//			// double average_cfinder_Q = 0;
//			// double average_eagle_Q = 0;
//			// double average_lfm_Q = 0;
//			// double average_gce_Q = 0;
//			// double average_docnet_Q = 0;
//			/* time */
//			long average_coresimple_time = 0;
//			// long average_cfinder_time = 0;
//			// long average_eagle_time = 0;
//			// long average_lfm_time = 0;
//			// long average_gce_time = 0;
//			// long average_docnet_time = 0;
//			/* rpf */
//			ArrayList<Double> average_coresimple_rpf = new ArrayList<Double>();
//			double average_coresimple_r = 0;
//			double average_coresimple_p = 0;
//			double average_coresimple_f = 0;
//			// ArrayList<Double> average_cfinder_rpf = new ArrayList<Double>();
//			// double average_cfinder_r = 0;
//			// double average_cfinder_p = 0;
//			// double average_cfinder_f = 0;
//			// ArrayList<Double> average_eagle_rpf = new ArrayList<Double>();
//			// double average_eagle_r = 0;
//			// double average_eagle_p = 0;
//			// double average_eagle_f = 0;
//			// ArrayList<Double> average_lfm_rpf = new ArrayList<Double>();
//			// double average_lfm_r = 0;
//			// double average_lfm_p = 0;
//			// double average_lfm_f = 0;
//			// ArrayList<Double> average_gce_rpf = new ArrayList<Double>();
//			// double average_gce_r = 0;
//			// double average_gce_p = 0;
//			// double average_gce_f = 0;
//			// ArrayList<Double> average_docnet_rpf = new ArrayList<Double>();
//			// double average_docnet_r = 0;
//			// double average_docnet_p = 0;
//			// double average_docnet_f = 0;
//
//			for (int j = 1; j <= 5; j++)
//			{
//				valueFilePath = String.valueOf(i) + "/" + String.valueOf(j);
//				String targetPath = lfrFilePath + parameterFilePath
//						+ valueFilePath;
//				String filePath = targetPath + ".txt";
//				String filePathOfRealCommunities = targetPath + ".clu";
//				// System.out.println(filePath);
//				// System.out.println(filePathOfRealCommunities);
//				Methods m = new Methods(filePath, filePathOfRealCommunities);
//				ArrayList<Measures> all_algorithm_measure_values = m
//						.runMethods(targetPath, false);
//				/* Measures */
//				Measures coresimple_measures = all_algorithm_measure_values
//						.get(0);
//				// Measures cfinder_measures =
//				// all_algorithm_measure_values.get(1);
//				// Measures eagle_measures =
//				// all_algorithm_measure_values.get(2);
//				// Measures lfm_measures = all_algorithm_measure_values.get(3);
//				// Measures gce_measures = all_algorithm_measure_values.get(4);
//				// Measures docnet_measures =
//				// all_algorithm_measure_values.get(5);
//				/* NMI */
//				average_coresimple_NMI += coresimple_measures.NMI;
//				// average_cfinder_NMI += cfinder_measures.NMI;
//				// average_eagle_NMI += eagle_measures.NMI;
//				// average_lfm_NMI += lfm_measures.NMI;
//				// average_gce_NMI += gce_measures.NMI;
//				// average_docnet_NMI += docnet_measures.NMI;
//				/* Q */
//				average_coresimple_Q += coresimple_measures.Q;
//				// average_cfinder_Q += cfinder_measures.Q;
//				// average_eagle_Q += eagle_measures.Q;
//				// average_lfm_Q += lfm_measures.Q;
//				// average_gce_Q += gce_measures.Q;
//				// average_docnet_Q += docnet_measures.Q;
//				/* time */
//				average_coresimple_time += coresimple_measures.time;
//				// average_cfinder_time += cfinder_measures.time;
//				// average_eagle_time += eagle_measures.time;
//				// average_lfm_time += lfm_measures.time;
//				// average_gce_time += gce_measures.time;
//				// average_docnet_time += docnet_measures.time;
//				/* r */
//				average_coresimple_r += coresimple_measures.rpf.get(0);
//				// average_cfinder_r += cfinder_measures.rpf.get(0);
//				// average_eagle_r += eagle_measures.rpf.get(0);
//				// average_lfm_r += lfm_measures.rpf.get(0);
//				// average_gce_r += gce_measures.rpf.get(0);
//				// average_docnet_r += docnet_measures.rpf.get(0);
//				/* p */
//				average_coresimple_p += coresimple_measures.rpf.get(1);
//				// average_cfinder_p += cfinder_measures.rpf.get(1);
//				// average_eagle_p += eagle_measures.rpf.get(1);
//				// average_lfm_p += lfm_measures.rpf.get(1);
//				// average_gce_p += gce_measures.rpf.get(1);
//				// average_docnet_p += docnet_measures.rpf.get(1);
//				/* f */
//				average_coresimple_f += coresimple_measures.rpf.get(2);
//				// average_cfinder_f += cfinder_measures.rpf.get(2);
//				// average_eagle_f += eagle_measures.rpf.get(2);
//				// average_lfm_f += lfm_measures.rpf.get(2);
//				// average_gce_f += gce_measures.rpf.get(2);
//				// average_docnet_f += docnet_measures.rpf.get(2);
//			}
//			/* NMI */
//			average_coresimple_NMI /= 5;
//			// average_cfinder_NMI /= 5;
//			// average_eagle_NMI /= 5;
//			// average_lfm_NMI /= 5;
//			// average_gce_NMI /= 5;
//			// average_docnet_NMI /= 5;
//			/* Q */
//			average_coresimple_Q /= 5;
//			// average_cfinder_Q /= 5;
//			// average_eagle_Q /= 5;
//			// average_lfm_Q /= 5;
//			// average_gce_Q /= 5;
//			// average_docnet_Q /= 5;
//			/* time */
//			average_coresimple_time /= 5;
//			// average_cfinder_time /= 5;
//			// average_eagle_time /= 5;
//			// average_lfm_time /= 5;
//			// average_gce_time /= 5;
//			// average_docnet_time /= 5;
//			/* r */
//			average_coresimple_r /= 5;
//			// average_cfinder_r /= 5;
//			// average_eagle_r /= 5;
//			// average_lfm_r /= 5;
//			// average_gce_r /= 5;
//			// average_docnet_r /= 5;
//			/* p */
//			average_coresimple_p /= 5;
//			// average_cfinder_p /= 5;
//			// average_eagle_p /= 5;
//			// average_lfm_p /= 5;
//			// average_gce_p /= 5;
//			// average_docnet_p /= 5;
//			/* f */
//			average_coresimple_f /= 5;
//			// average_cfinder_f /= 5;
//			// average_eagle_f /= 5;
//			// average_lfm_f /= 5;
//			// average_gce_f /= 5;
//			// average_docnet_f /= 5;
//			/* rpf */
//			average_coresimple_rpf.add(average_coresimple_r);
//			average_coresimple_rpf.add(average_coresimple_p);
//			average_coresimple_rpf.add(average_coresimple_f);
//
//			// average_cfinder_rpf.add(average_cfinder_r);
//			// average_cfinder_rpf.add(average_cfinder_p);
//			// average_cfinder_rpf.add(average_cfinder_f);
//			//
//			// average_eagle_rpf.add(average_eagle_r);
//			// average_eagle_rpf.add(average_eagle_p);
//			// average_eagle_rpf.add(average_eagle_f);
//			//
//			// average_lfm_rpf.add(average_lfm_r);
//			// average_lfm_rpf.add(average_lfm_p);
//			// average_lfm_rpf.add(average_lfm_f);
//			//
//			// average_gce_rpf.add(average_gce_r);
//			// average_gce_rpf.add(average_gce_p);
//			// average_gce_rpf.add(average_gce_f);
//			//
//			// average_docnet_rpf.add(average_docnet_r);
//			// average_docnet_rpf.add(average_docnet_p);
//			// average_docnet_rpf.add(average_docnet_f);
//			/* Measures */
//			Measures coresimple_measures_average = new Measures(
//					average_coresimple_NMI, average_coresimple_Q,
//					average_coresimple_time, average_coresimple_rpf);
//			// Measures cfinder_measures_average = new Measures(
//			// average_cfinder_NMI, average_cfinder_Q,
//			// average_cfinder_time, average_cfinder_rpf);
//			// Measures eagle_measures_average = new Measures(average_eagle_NMI,
//			// average_eagle_Q, average_eagle_time, average_eagle_rpf);
//			// Measures lfm_measures_average = new Measures(average_lfm_NMI,
//			// average_lfm_Q, average_lfm_time, average_lfm_rpf);
//			// Measures gce_measures_average = new Measures(average_gce_NMI,
//			// average_gce_Q, average_gce_time, average_gce_rpf);
//			// Measures docnet_measures_average = new
//			// Measures(average_docnet_NMI,
//			// average_docnet_Q, average_docnet_time, average_docnet_rpf);
//			all_algorithm_measure_values_average
//					.add(coresimple_measures_average);
//			// all_algorithm_measure_values_average.add(cfinder_measures_average);
//			// all_algorithm_measure_values_average.add(eagle_measures_average);
//			// all_algorithm_measure_values_average.add(lfm_measures_average);
//			// all_algorithm_measure_values_average.add(gce_measures_average);
//			// all_algorithm_measure_values_average.add(docnet_measures_average);
//			for (int k = 0; k < all_algorithm_measure_values_average.size(); k++)
//			{
//				if (k == 0)
//				{
//					System.out.println("coresimple: ");
//				} else if (k == 1)
//				{
//					System.out.println("cfinder");
//				} else if (k == 2)
//				{
//					System.out.println("eagle: ");
//				} else if (k == 3)
//				{
//					System.out.println("lfm");
//				} else if (k == 4)
//				{
//					System.out.println("gce");
//				} else if (k == 5)
//				{
//					System.out.println("docnet");
//				}
//				System.out.println(all_algorithm_measure_values_average.get(k));
//			}
//		}
//		System.out.println("*************************************************");
//	}
//
//	public static void main(String[] args) throws IOException
//	{
//		/* Tests on real word networks */
//		/**************************************************************************/
//		String filePath = "D:/Sixth/tests on real word networks/karate.txt";// changed
//		// karate,krebs' book,football,dolphin
//		/* test on real networks */
//		String filePathOfRealCommunities = "D:/Sixth/tests on real word networks/karate.clu";// changed
//		String targetPath = "D:/Sixth/karate";
//		Methods m = new Methods(filePath, filePathOfRealCommunities);
//		m.runMethods(targetPath);
//		/**************************************************************************/
//		// Methods m = new Methods();
//		// m.run_methords_artificial_networks();
//	}
//}
