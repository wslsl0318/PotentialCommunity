package com.dingxiaoyu.methods;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeSet;

public class RealWorldNetworksRPF
{
	public int n;// node number
	public ArrayList<ArrayList<Integer>> partation_R;
	public ArrayList<ArrayList<Integer>> partation_F;
	public String partation_R_file;
	public String partation_F_file;

	public RealWorldNetworksRPF(String partation_R_file, String partation_F_file)
	{
		this.partation_R_file = partation_R_file;
		this.partation_F_file = partation_F_file;
		this.partation_R = new ArrayList<ArrayList<Integer>>();
		this.partation_F = new ArrayList<ArrayList<Integer>>();
	}

	/* Get overlap nodes */
	public ArrayList<OverlapNode> get_overlap_nodes(
			ArrayList<ArrayList<Integer>> partition)
	{
		ArrayList<OverlapNode> overlap_nodes = new ArrayList<OverlapNode>();
		for (int i = 0; i < n; i++)
		{
			int count = 0;
			TreeSet<Integer> community_ids = new TreeSet<Integer>();
			for (int j = 0; j < partition.size(); j++)
			{
				ArrayList<Integer> community = partition.get(j);
				if (community.contains((Integer) i))
				{
					count++;
					community_ids.add(j);
				}
			}
			OverlapNode overlap_node = new OverlapNode(i, count);
			// overlap_node.community_ids.addAll(community_ids);
			overlap_nodes.add(overlap_node);
		}
		return overlap_nodes;
	}

	/* get insection */
	public TreeSet<Integer> get_insection(TreeSet<Integer> set_1,
			TreeSet<Integer> set_2)
	{
		TreeSet<Integer> insection = new TreeSet<Integer>();
		for (Iterator<Integer> iter = set_1.iterator(); iter.hasNext();)
		{
			Integer member = iter.next();
			if (set_2.contains(member))
			{
				insection.add(member);
			}
		}
		return insection;
	}

	/* Get recall,precision,f-score */
	public ArrayList<Double> get_recall_precision_fscore(
			ArrayList<OverlapNode> partitionR_overlap_nodes,
			ArrayList<OverlapNode> partitionF_overlap_nodes)
	{
		ArrayList<Double> rpf = new ArrayList<Double>();
		TreeSet<Integer> partitionR_overlap_node_ids = new TreeSet<Integer>();
		TreeSet<Integer> partitionF_overlap_node_ids = new TreeSet<Integer>();
		for (Iterator<OverlapNode> iter = partitionR_overlap_nodes.iterator(); iter
				.hasNext();)
		{
			OverlapNode member = iter.next();
			if (member.overlap_times > 1)
			{
				partitionR_overlap_node_ids.add(member.node_id);
			}
		}
		for (Iterator<OverlapNode> iter = partitionF_overlap_nodes.iterator(); iter
				.hasNext();)
		{
			OverlapNode member = iter.next();
			if (member.overlap_times > 1)
			{
				partitionF_overlap_node_ids.add(member.node_id);
			}
		}
		TreeSet<Integer> insection = get_insection(partitionR_overlap_node_ids,
				partitionF_overlap_node_ids);
		double insection_overlap_node_size = insection.size();
		double partitionR_overlap_node_size = partitionR_overlap_node_ids
				.size();
		double partitionF_overlap_node_size = partitionF_overlap_node_ids
				.size();
		double r = 0;
		double p = 0;
		double f = 0;
		if (insection_overlap_node_size != 0)
		{
			if (partitionR_overlap_node_size != 0)
			{
				r = insection_overlap_node_size / partitionR_overlap_node_size;
			}
			if (partitionF_overlap_node_size != 0)
			{
				p = insection_overlap_node_size / partitionF_overlap_node_size;
			}
			if (partitionR_overlap_node_size != 0
					&& partitionF_overlap_node_size != 0)
			{
				f = (2 * r * p) / (r + p);
			}
		}
		rpf.add(r);
		rpf.add(p);
		rpf.add(f);
		return rpf;
	}

	/* Read partation R file */
	public void read_file_by_line_community_R()
	{
		TreeSet<Integer> distinct_node_ids = new TreeSet<Integer>();
		File file = new File(this.partation_R_file);
		BufferedReader reader = null;
		try
		{
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			while ((tempString = reader.readLine()) != null)
			{
				String[] strs;
				strs = tempString.split("\t");
				ArrayList<Integer> community = new ArrayList<Integer>();
				for (int i = 0; i < strs.length; i++)
				{
					int node_id = Integer.parseInt(strs[i]);
					distinct_node_ids.add(node_id);
					community.add(node_id);
				}
				this.partation_R.add(community);
			}
			this.n = distinct_node_ids.size();
			reader.close();
		} catch (IOException e)
		{
			e.printStackTrace();
		} finally
		{
			if (reader != null)
			{
				try
				{
					reader.close();
				} catch (IOException e1)
				{
				}
			}
		}
	}

	/* Read partation F file */
	public void read_file_by_line_community_F()
	{
		// System.out.println(this.partation_F_file);
		File file = new File(this.partation_F_file);
		BufferedReader reader = null;
		try
		{
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			int line_count = 0;
			while ((tempString = reader.readLine()) != null)
			{
				if (line_count < 5)
				{
					line_count++;
					continue;
				}
				String[] strs;
				strs = tempString.split("\t");
				ArrayList<Integer> community = new ArrayList<Integer>();
				for (int i = 0; i < strs.length; i++)
				{
					int node_id = Integer.parseInt(strs[i]);
					community.add(node_id);
				}
				this.partation_F.add(community);
				// System.out.println(community);
			}
			reader.close();
		} catch (IOException e)
		{
			e.printStackTrace();
		} finally
		{
			if (reader != null)
			{
				try
				{
					reader.close();
				} catch (IOException e1)
				{
				}
			}
		}
	}

	/* Get RPF */
	public ArrayList<Double> get_RPF()
	{
		read_file_by_line_community_R();
		read_file_by_line_community_F();
		ArrayList<OverlapNode> partition_R_overlap_nodes = get_overlap_nodes(partation_R);
		// System.out.println(partition_R_overlap_nodes);
		ArrayList<OverlapNode> partition_F_overlap_nodes = get_overlap_nodes(partation_F);
		ArrayList<Double> RPF = get_recall_precision_fscore(
				partition_R_overlap_nodes, partition_F_overlap_nodes);
		return RPF;
	}

	public static void main(String[] args)
	{
		String file_path = "D:/Sixth results/real world networks/";
		String file_name = "karate";
		// karate;dolphin;football;krebsbook;
		// CCSB-YI1;Combined-APMS;Ito-core;LC-multiple;Uetz-screen;Y2H-union;
		// amazon;dblp;youtube;
		String community = "_community.txt";
		String result = "_result";
		String six = "(six).txt";
		String cfinder = "(cfinder).txt";
		String eagle = "(eagle).txt";
		String lfm = "(lfm).txt";
		String gce = "(gce).txt";
		String docnet = "(docnet).txt";
		ArrayList<String> algorithms = new ArrayList<String>();
		algorithms.add(six);
		algorithms.add(cfinder);
		algorithms.add(eagle);
		algorithms.add(lfm);
		algorithms.add(gce);
		algorithms.add(docnet);
		String partation_R_file = file_path + file_name + community;
		String partation_F_file = "";
		ArrayList<Double> six_RPF = new ArrayList<Double>();
		ArrayList<Double> cfinder_RPF = new ArrayList<Double>();
		ArrayList<Double> eagle_RPF = new ArrayList<Double>();
		ArrayList<Double> lfm_RPF = new ArrayList<Double>();
		ArrayList<Double> gce_RPF = new ArrayList<Double>();
		ArrayList<Double> docnet_RPF = new ArrayList<Double>();
		for (int i = 0; i < 6; i++)
		{
			String algorithm = algorithms.get(i);
			partation_F_file = file_path + file_name + result + algorithm;
			RealWorldNetworksRPF real_world_networks_RPF = new RealWorldNetworksRPF(
					partation_R_file, partation_F_file);
			if (i == 0)
			{
				six_RPF = real_world_networks_RPF.get_RPF();
			} else if (i == 1)
			{
				cfinder_RPF = real_world_networks_RPF.get_RPF();
			} else if (i == 2)
			{
				eagle_RPF = real_world_networks_RPF.get_RPF();
			} else if (i == 3)
			{
				lfm_RPF = real_world_networks_RPF.get_RPF();
			} else if (i == 4)
			{
				gce_RPF = real_world_networks_RPF.get_RPF();
			} else if (i == 5)
			{
				docnet_RPF = real_world_networks_RPF.get_RPF();
			}
		}
		System.out.println("Algorithms" + " & Six" + " & CFinder" + " & EAGLE"
				+ " & LFM" + " & GCE" + " & DOCnet");
		System.out.println("R:    " + "& " + six_RPF.get(0) + " " + "& "
				+ cfinder_RPF.get(0) + " " + "& " + eagle_RPF.get(0) + " "
				+ "& " + lfm_RPF.get(0) + " " + "& " + gce_RPF.get(0) + " "
				+ "& " + docnet_RPF.get(0));
		System.out.println("P:    " + "& " + six_RPF.get(1) + " " + "& "
				+ cfinder_RPF.get(1) + " " + "& " + eagle_RPF.get(1) + " "
				+ "& " + lfm_RPF.get(1) + " " + "& " + gce_RPF.get(1) + " "
				+ "& " + docnet_RPF.get(1));
		System.out.println("F:    " + "& " + six_RPF.get(2) + " " + "& "
				+ cfinder_RPF.get(2) + " " + "& " + eagle_RPF.get(2) + " "
				+ "& " + lfm_RPF.get(2) + " " + "& " + gce_RPF.get(2) + " "
				+ "& " + docnet_RPF.get(2));
	}
}
