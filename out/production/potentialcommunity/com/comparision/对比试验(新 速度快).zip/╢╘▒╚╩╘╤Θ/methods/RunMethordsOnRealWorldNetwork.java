package com.dingxiaoyu.methods;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeSet;

import DataReaderRealWorldNetwork.DataReaderRealWorldNetwork;

import com.dingxiaoyu.CFM.CFMAlgorithm;
import com.dingxiaoyu.DOCNET.DOCnetAlgorithm;
import com.dingxiaoyu.EAGLE.EAGLEAlgorithm;
import com.dingxiaoyu.LFM.LFMAlgorithm;
import com.dingxiaoyu.SEVEN.KCoreExtensionAlgorithm;
import com.dingxiaoyu.SEVEN.KCoreExtensionAlgorithm1;
import com.dingxiaoyu.SEVEN.KCoreExtensionAlgorithm2;
import com.dingxiaoyu.SEVEN.KCoreExtensionAlgorithm3;
import com.dingxiaoyu.SEVEN.NodeLocalCoreValue;
import com.dingxiaoyu.SEVEN.NodeLocalDegree;
import com.dingxiaoyu.SIX.BoundaryIdentification1;
import com.dingxiaoyu.SIX.BoundaryIdentification2;
import com.dingxiaoyu.SIX.BoundaryIdentification3;
import com.dingxiaoyu.SIX.CommunityBasedOnCores3;
import com.dingxiaoyu.TWD.TWDAlgorithm;
import com.dingxiaoyu.WCPM.WCPMAlgorithm;
import com.dingxiayu.NCB.NCBAlgorithm;
import com.fileoperations.methods.FileReaders;
import com.fileoperations.methods.FileWriters;
import com.pulicoperations.methods.Partitions;
import com.pulicoperations.methods.RPF;

public class RunMethordsOnRealWorldNetwork
{
	public DataReaderRealWorldNetwork data_reader;
	public int n;// node number
	public int m;// link number
	public int nc;// community number;
	public ArrayList<ArrayList<Integer>> adjacencyTable;
	public ArrayList<TreeSet<Integer>> adjacencyTable_tree;
	public ArrayList<ArrayList<Integer>> real_communities;
	public String file_path_result;

	public RunMethordsOnRealWorldNetwork(String file_path_community,
			String file_path_table, String file_path_result)
	{
		this.data_reader = new DataReaderRealWorldNetwork(file_path_community,
				file_path_table);
		this.adjacencyTable = new ArrayList<ArrayList<Integer>>();
		this.adjacencyTable_tree = new ArrayList<TreeSet<Integer>>();
		this.real_communities = new ArrayList<ArrayList<Integer>>();
		this.file_path_result = file_path_result;
	}

	/********************************************************************************************/
	/* Get overlap modularity */
	/********************************************************************************************/

	/* Calculate overlap modularity */
	public double calculate_Q(ArrayList<TreeSet<Integer>> communities,
			ArrayList<OverlapNode> partition_overlap_nodes)
	{
		double Q = 0;
		for (int i = 0; i < communities.size(); i++)
		{
			ArrayList<Integer> community = new ArrayList<Integer>();
			community.addAll(communities.get(i));
			double sum = 0;
			for (int j = 0; j < community.size(); j++)
			{
				int node_1 = community.get(j);
				for (int k = 0; k < community.size(); k++)
				{
					int node_2 = community.get(k);
					int avw;
					if (j == k)
					{
						avw = 0;
					} else
					{
						if (adjacencyTable_tree.get(node_1).contains(node_2))
						{
							avw = 1;
						} else
						{
							avw = 0;
						}
					}
					int kv = adjacencyTable.get(node_1).size() - 1;
					int kw = adjacencyTable.get(node_2).size() - 1;
					double x = kv * kw / (double) (2 * m);
					int o_node_1 = partition_overlap_nodes.get(node_1).overlap_times;
					int o_node_2 = partition_overlap_nodes.get(node_2).overlap_times;
					sum += ((avw - x) / (o_node_1 * o_node_2));
				}
			}
			Q += sum;
		}
		Q /= (2 * m);
		return Q;
	}

	/********************************************************************************************/
	/* Get overlap NMI */
	/********************************************************************************************/

	/* Calculate a,b,c,d (table version) (tested) */
	public int[] calculate_a_b_c_d_community(TreeSet<Integer> node_set_1,
			TreeSet<Integer> node_set_2)
	{
		int[] a_b_c_d = new int[4];
		int a = 0;
		int b = 0;
		int c = 0;
		int d = 0;
		TreeSet<Integer> temp_set = new TreeSet<Integer>();
		/* Calculate a */
		temp_set.addAll(node_set_1);
		temp_set.addAll(node_set_2);
		a = n - temp_set.size();
		temp_set.clear();
		/* Calculate d */
		temp_set = get_insection(node_set_1, node_set_2);
		d = temp_set.size();
		/* Calculate b */
		b = node_set_2.size() - d;
		/* Calculate c */
		c = node_set_1.size() - d;

		a_b_c_d[0] = a;
		a_b_c_d[1] = b;
		a_b_c_d[2] = c;
		a_b_c_d[3] = d;
		return a_b_c_d;
	}

	/* Calculate_H_X_Y */
	public double calculate_H_X_Y(int k_X_size, int k_Y_size,
			ArrayList<TreeSet<Integer>> partationTruth,
			ArrayList<TreeSet<Integer>> partationFound)
	{
		double H_X_Y = 0;
		for (int i = 0; i < k_X_size; i++)
		{
			double H_Xi_Y = Double.POSITIVE_INFINITY;
			TreeSet<Integer> community_truth = partationTruth.get(i);
			for (int j = 0; j < k_Y_size; j++)
			{
				TreeSet<Integer> community_found = partationFound.get(j);
				int[] a_b_c_d = calculate_a_b_c_d_community(community_truth,
						community_found);
				double H_Xi_Yj = 0;
				double H_a = 0;
				double H_b = 0;
				double H_c = 0;
				double H_d = 0;
				double H_a_c = 0;
				double H_b_d = 0;
				double H_a_b = 0;
				double H_c_d = 0;
				H_a = h(a_b_c_d[0], n);
				H_b = h(a_b_c_d[1], n);
				H_c = h(a_b_c_d[2], n);
				H_d = h(a_b_c_d[3], n);
				if ((H_a + H_d) >= (H_b + H_c))
				{
					H_a_c = h(a_b_c_d[0] + a_b_c_d[2], n);
					H_b_d = h(a_b_c_d[1] + a_b_c_d[3], n);
					H_Xi_Yj = H_a + H_b + H_c + H_d - H_a_c - H_b_d;
				} else
				{
					H_a_b = h(a_b_c_d[0] + a_b_c_d[1], n);
					H_c_d = h(a_b_c_d[2] + a_b_c_d[3], n);
					H_Xi_Yj = H_a_b + H_c_d;
				}
				if (H_Xi_Y > H_Xi_Yj)
				{
					H_Xi_Y = H_Xi_Yj;
				}
			}
			H_X_Y += H_Xi_Y;
		}
		return H_X_Y;
	}

	/* Calculate_H_Y_X */
	public double calculate_H_Y_X(int k_Y_size, int k_X_size,
			ArrayList<TreeSet<Integer>> partationFound,
			ArrayList<TreeSet<Integer>> partationTruth)
	{
		double H_Y_X = 0;
		for (int i = 0; i < k_Y_size; i++)
		{
			double H_Yi_X = Double.POSITIVE_INFINITY;
			TreeSet<Integer> community_found = partationFound.get(i);
			for (int j = 0; j < k_X_size; j++)
			{
				TreeSet<Integer> community_truth = partationTruth.get(j);
				int[] a_b_c_d = calculate_a_b_c_d_community(community_found,
						community_truth);
				double H_Yi_Xj = 0;
				double H_a = 0;
				double H_b = 0;
				double H_c = 0;
				double H_d = 0;
				double H_a_c = 0;
				double H_b_d = 0;
				double H_a_b = 0;
				double H_c_d = 0;
				H_a = h(a_b_c_d[0], n);
				H_b = h(a_b_c_d[1], n);
				H_c = h(a_b_c_d[2], n);
				H_d = h(a_b_c_d[3], n);
				if ((H_a + H_d) >= (H_b + H_c))
				{
					H_a_c = h(a_b_c_d[0] + a_b_c_d[2], n);
					H_b_d = h(a_b_c_d[1] + a_b_c_d[3], n);
					H_Yi_Xj = H_a + H_b + H_c + H_d - H_a_c - H_b_d;
				} else
				{
					H_a_b = h(a_b_c_d[0] + a_b_c_d[1], n);
					H_c_d = h(a_b_c_d[2] + a_b_c_d[3], n);
					H_Yi_Xj = H_a_b + H_c_d;
				}
				if (H_Yi_X > H_Yi_Xj)
				{
					H_Yi_X = H_Yi_Xj;
				}
			}
			H_Y_X += H_Yi_X;
		}
		return H_Y_X;
	}

	/* calculate H(X) (or H(Y)) (tested) */
	public double calculate_H_X_or_H_Y(int k_X_size,
			ArrayList<TreeSet<Integer>> partition)
	{
		double H_X = 0;
		for (int i = 0; i < k_X_size; i++)
		{
			int value_0 = n - partition.get(i).size();
			int value_1 = partition.get(i).size();
			H_X += (h(value_0, n) + h(value_1, n));
		}
		return H_X;
	}

	/* calculate NMI_LFK (tested) */
	public double NMIPartitionLFK(ArrayList<TreeSet<Integer>> partitionTruth,
			ArrayList<TreeSet<Integer>> partitionFound)
	{
		if (partitionFound.size() == 1)
		{
			return 0;
		}
		double nmi_lfk = 0;

		int k_X_size = partitionTruth.size();
		int k_Y_size = partitionFound.size();

		double H_X = calculate_H_X_or_H_Y(k_X_size, partitionTruth);
		double H_Y = calculate_H_X_or_H_Y(k_Y_size, partitionFound);

		double H_X_Y = calculate_H_X_Y(k_X_size, k_Y_size, partitionTruth,
				partitionFound);
		double H_Y_X = calculate_H_Y_X(k_Y_size, k_X_size, partitionFound,
				partitionTruth);

		nmi_lfk = 1 - 0.5 * (H_X_Y / H_X + H_Y_X / H_Y);
		return nmi_lfk;
	}

	/* h function */
	private double h(int w, int n)
	{
		if (w == n || w == 0)
		{
			return 0;
		} else
		{
			return -w * 1.0 * Math.log(w * 1.0 / (1.0 * n)) / Math.log(2.0);
		}
	}

	/********************************************************************************************/
	/* Get recall,precision,f-score of overlap nodes */
	/********************************************************************************************/
	/* Get overlap nodes */
	public ArrayList<OverlapNode> get_overlap_nodes(
			ArrayList<TreeSet<Integer>> partition)
	{
		ArrayList<OverlapNode> overlap_nodes = new ArrayList<OverlapNode>();
		for (int i = 0; i < n; i++)
		{
			int count = 0;
			for (Iterator<TreeSet<Integer>> iter = partition.iterator(); iter
					.hasNext();)
			{
				TreeSet<Integer> community = iter.next();
				if (community.contains((Integer) i))
				{
					count++;
				}
			}
			OverlapNode overlap_node = new OverlapNode(i, count);
			overlap_nodes.add(overlap_node);
		}
		return overlap_nodes;
	}

	/* get insection */
	public TreeSet<Integer> get_insection(TreeSet<Integer> set_1,
			TreeSet<Integer> set_2)
	{
		TreeSet<Integer> insection = new TreeSet<Integer>();
		if (set_1.size() < set_2.size())
		{
			for (Iterator<Integer> iter = set_1.iterator(); iter.hasNext();)
			{
				Integer member = iter.next();
				if (set_2.contains(member))
				{
					insection.add(member);
				}
			}
		} else
		{
			for (Iterator<Integer> iter = set_2.iterator(); iter.hasNext();)
			{
				Integer member = iter.next();
				if (set_1.contains(member))
				{
					insection.add(member);
				}
			}
		}
		return insection;
	}

	/* Get recall,precision,f-score */
	public ArrayList<Double> get_recall_precision_fscore(
			ArrayList<OverlapNode> partitionR_overlap_nodes,
			ArrayList<OverlapNode> partitionF_overlap_nodes)
	{
		ArrayList<Double> rpf = new ArrayList<Double>();
		TreeSet<Integer> partitionR_overlap_node_ids = new TreeSet<Integer>();
		TreeSet<Integer> partitionF_overlap_node_ids = new TreeSet<Integer>();
		for (Iterator<OverlapNode> iter = partitionR_overlap_nodes.iterator(); iter
				.hasNext();)
		{
			OverlapNode member = iter.next();
			if (member.overlap_times > 1)
			{
				partitionR_overlap_node_ids.add(member.node_id);
			}
		}
		for (Iterator<OverlapNode> iter = partitionF_overlap_nodes.iterator(); iter
				.hasNext();)
		{
			OverlapNode member = iter.next();
			if (member.overlap_times > 1)
			{
				partitionF_overlap_node_ids.add(member.node_id);
			}
		}
		TreeSet<Integer> insection = get_insection(partitionR_overlap_node_ids,
				partitionF_overlap_node_ids);
		double insection_overlap_node_size = insection.size();
		double partitionR_overlap_node_size = partitionR_overlap_node_ids
				.size();
		double partitionF_overlap_node_size = partitionF_overlap_node_ids
				.size();
		double r = 0;
		double p = 0;
		double f = 0;
		if (insection_overlap_node_size != 0)
		{
			if (partitionR_overlap_node_size != 0)
			{
				r = insection_overlap_node_size / partitionR_overlap_node_size;
			}
			if (partitionF_overlap_node_size != 0)
			{
				p = insection_overlap_node_size / partitionF_overlap_node_size;
			}
			if (partitionR_overlap_node_size != 0
					&& partitionF_overlap_node_size != 0)
			{
				f = (2 * r * p) / (r + p);
			}
		}
		rpf.add(r);
		rpf.add(p);
		rpf.add(f);
		return rpf;
	}

	/********************************************************************************************/
	/* Get f-measure */
	public double get_fmeasure(ArrayList<TreeSet<Integer>> partitionTruth,
			ArrayList<TreeSet<Integer>> partitionFound)
	{
		double f_measure = 0;
		for (Iterator<TreeSet<Integer>> iter_truth = partitionTruth.iterator(); iter_truth
				.hasNext();)
		{
			TreeSet<Integer> community_truth = iter_truth.next();
			double f_max = 0;
			for (Iterator<TreeSet<Integer>> iter_found = partitionFound
					.iterator(); iter_found.hasNext();)
			{
				TreeSet<Integer> community_found = iter_found.next();
				TreeSet<Integer> insection = get_insection(community_truth,
						community_found);
				double insection_size = insection.size();
				double r = insection_size / community_truth.size();
				double p = insection_size / community_found.size();
				double f = (2 * r * p) / (r + p);
				if (f > f_max)
				{
					f_max = f;
				}
			}
			f_measure += f_max;
		}
		f_measure /= partitionTruth.size();
		return f_measure;
	}

	/********************************************************************************************/
	/* Calculate variance */
	public double calculate_variance(
			ArrayList<OverlapNode> partitionF_overlap_nodes,
			ArrayList<OverlapNode> partitionR_overlap_nodes)
	{
		double variance = 0;
		double x = 0;
		for (int i = 0; i < n; i++)
		{
			x = partitionF_overlap_nodes.get(i).overlap_times
					- partitionR_overlap_nodes.get(i).overlap_times;
			variance += (x * x);
		}
		variance = variance / (double) n;
		return variance;
	}

	/********************************************************************************************/
	/* Calculate number of overlapping nodes */
	public double calculate_no(ArrayList<OverlapNode> partitionR_overlap_nodes,
			ArrayList<OverlapNode> partitionF_overlap_nodes)
	{
		// double no_D = 0;
		// double no_R = 0;
		// for (Iterator<OverlapNode> iter =
		// partitionR_overlap_nodes.iterator(); iter
		// .hasNext();)
		// {
		// OverlapNode node = iter.next();
		// if (node.overlap_times > 1)
		// {
		// no_R++;
		// }
		// }
		double no_F = 0;
		for (Iterator<OverlapNode> iter = partitionF_overlap_nodes.iterator(); iter
				.hasNext();)
		{
			OverlapNode node = iter.next();
			if (node.overlap_times > 1)
			{
				no_F++;
			}
		}
		// if (no_F >= no_R)
		// {
		// no_D = (double) (no_F - no_R) / (double) (no_R);
		// } else
		// {
		// no_D = -(double) (no_R - no_F) / (double) (no_F);
		// }
		return no_F;
	}

	/********************************************************************************************/
	/* Calculate variance */
	public double calculate_no(ArrayList<OverlapNode> partitionF_overlap_nodes)
	{
		double no = 0;
		for (Iterator<OverlapNode> iter = partitionF_overlap_nodes.iterator(); iter
				.hasNext();)
		{
			OverlapNode node = iter.next();
			if (node.overlap_times > 1)
			{
				no++;
			}
		}
		return no;
	}

	/********************************************************************************************/
	/* Calculate D-Score */
	public double calculate_D(int partitionF_size, int partitionR_size)
	{
		double D = 0;
		if (partitionF_size >= partitionR_size)
		{
			D = (double) (partitionF_size - partitionR_size)
					/ (double) (partitionR_size);
		} else
		{
			D = -(double) (partitionR_size - partitionF_size)
					/ (double) (partitionF_size);
		}
		return D;
	}

	/********************************************************************************************/
	/* (Tested) initial n, m, nc, adjacency table, real communities */
	public void initial_paramaters() throws IOException
	{
		this.data_reader.read_realworld_network();
		this.n = this.data_reader.n;
		this.m = this.data_reader.m;
		this.nc = this.data_reader.nc;
		this.adjacencyTable.addAll(this.data_reader.adjacencyTable);
		this.data_reader.adjacencyTable.clear();
		this.data_reader.adjacencyTable.clear();
		for (Iterator<ArrayList<Integer>> iter = this.adjacencyTable.iterator(); iter
				.hasNext();)
		{
			ArrayList<Integer> community = iter.next();
			TreeSet<Integer> community_tree = new TreeSet<Integer>();
			community_tree.addAll(community);
			this.adjacencyTable_tree.add(community_tree);
		}
		this.real_communities.addAll(this.data_reader.real_communities);
		this.data_reader.real_communities.clear();
	}

	/* (Tested) write results into files */
	public void write_results_into_files(String algorithm_name, double NMI,
			double Q, double R, double P, double F, double FMeasure, double V,
			double no, double C, long time,
			ArrayList<TreeSet<Integer>> detected_communities)
			throws IOException
	{
		String file = this.file_path_result + algorithm_name;
		FileOutputStream fos = new FileOutputStream(file);
		OutputStreamWriter osw = new OutputStreamWriter(fos);
		BufferedWriter bw = new BufferedWriter(osw);
		bw.write("NMI: " + NMI + "\r\n");
		bw.write("Q: " + Q + "\r\n");
		bw.write("R: " + R + "\r\n");
		bw.write("P: " + P + "\r\n");
		bw.write("F-Score: " + F + "\r\n");
		bw.write("F-Measure: " + FMeasure + "\r\n");
		bw.write("V: " + V + "\r\n");
		bw.write("no: " + no + "\r\n");
		bw.write("C: " + C + "\r\n");
		bw.write("Time: " + time + "\r\n");
		bw.write("detected_communities:" + "\r\n");
		for (Iterator<TreeSet<Integer>> iter_community = detected_communities
				.iterator(); iter_community.hasNext();)
		{
			TreeSet<Integer> community = iter_community.next();
			for (Iterator<Integer> iter_member = community.iterator(); iter_member
					.hasNext();)
			{
				Integer member = iter_member.next();
				bw.write(member + "\t");
			}
			bw.write("\r\n");
		}
		bw.close();
	}

	public double get_NMI(String algorithm)
	{
		File file = new File(file_path_result + "(" + algorithm + ")" + ".txt");
		BufferedReader reader = null;
		try
		{
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			int line = 0;
			while ((tempString = reader.readLine()) != null)
			{
				line++;
				if (line == 1)
				{
					String[] strs;
					strs = tempString.split(" ");
					return Double.parseDouble(strs[1]);
				}
			}
			reader.close();
		} catch (IOException e)
		{
			e.printStackTrace();
		} finally
		{
			if (reader != null)
			{
				try
				{
					reader.close();
				} catch (IOException e1)
				{
				}
			}
		}
		return -1;
	}

	public double get_Q(String algorithm)
	{
		File file = new File(file_path_result + "(" + algorithm + ")" + ".txt");
		BufferedReader reader = null;
		try
		{
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			int line = 0;
			while ((tempString = reader.readLine()) != null)
			{
				line++;
				if (line == 2)
				{
					String[] strs;
					strs = tempString.split(" ");
					return Double.parseDouble(strs[1]);
				}
			}
			reader.close();
		} catch (IOException e)
		{
			e.printStackTrace();
		} finally
		{
			if (reader != null)
			{
				try
				{
					reader.close();
				} catch (IOException e1)
				{
				}
			}
		}
		return -1;
	}

	public double get_R(String algorithm)
	{
		File file = new File(file_path_result + "(" + algorithm + ")" + ".txt");
		BufferedReader reader = null;
		try
		{
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			int line = 0;
			while ((tempString = reader.readLine()) != null)
			{
				line++;
				if (line == 3)
				{
					String[] strs;
					strs = tempString.split(" ");
					return Double.parseDouble(strs[1]);
				}
			}
			reader.close();
		} catch (IOException e)
		{
			e.printStackTrace();
		} finally
		{
			if (reader != null)
			{
				try
				{
					reader.close();
				} catch (IOException e1)
				{
				}
			}
		}
		return -1;
	}

	public double get_P(String algorithm)
	{
		File file = new File(file_path_result + "(" + algorithm + ")" + ".txt");
		BufferedReader reader = null;
		try
		{
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			int line = 0;
			while ((tempString = reader.readLine()) != null)
			{
				line++;
				if (line == 4)
				{
					String[] strs;
					strs = tempString.split(" ");
					return Double.parseDouble(strs[1]);
				}
			}
			reader.close();
		} catch (IOException e)
		{
			e.printStackTrace();
		} finally
		{
			if (reader != null)
			{
				try
				{
					reader.close();
				} catch (IOException e1)
				{
				}
			}
		}
		return -1;
	}

	public double get_F(String algorithm)
	{
		File file = new File(file_path_result + "(" + algorithm + ")" + ".txt");
		BufferedReader reader = null;
		try
		{
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			int line = 0;
			while ((tempString = reader.readLine()) != null)
			{
				line++;
				if (line == 5)
				{
					String[] strs;
					strs = tempString.split(" ");
					return Double.parseDouble(strs[1]);
				}
			}
			reader.close();
		} catch (IOException e)
		{
			e.printStackTrace();
		} finally
		{
			if (reader != null)
			{
				try
				{
					reader.close();
				} catch (IOException e1)
				{
				}
			}
		}
		return -1;
	}

	public double get_FMeasure(String algorithm)
	{
		File file = new File(file_path_result + "(" + algorithm + ")" + ".txt");
		BufferedReader reader = null;
		try
		{
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			int line = 0;
			while ((tempString = reader.readLine()) != null)
			{
				line++;
				if (line == 6)
				{
					String[] strs;
					strs = tempString.split(" ");
					return Double.parseDouble(strs[1]);
				}
			}
			reader.close();
		} catch (IOException e)
		{
			e.printStackTrace();
		} finally
		{
			if (reader != null)
			{
				try
				{
					reader.close();
				} catch (IOException e1)
				{
				}
			}
		}
		return -1;
	}

	public double get_V(String algorithm)
	{
		File file = new File(file_path_result + "(" + algorithm + ")" + ".txt");
		BufferedReader reader = null;
		try
		{
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			int line = 0;
			while ((tempString = reader.readLine()) != null)
			{
				line++;
				if (line == 7)
				{
					String[] strs;
					strs = tempString.split(" ");
					return Double.parseDouble(strs[1]);
				}
			}
			reader.close();
		} catch (IOException e)
		{
			e.printStackTrace();
		} finally
		{
			if (reader != null)
			{
				try
				{
					reader.close();
				} catch (IOException e1)
				{
				}
			}
		}
		return -1;
	}

	public double get_no(String algorithm)
	{
		File file = new File(file_path_result + "(" + algorithm + ")" + ".txt");
		BufferedReader reader = null;
		try
		{
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			int line = 0;
			while ((tempString = reader.readLine()) != null)
			{
				line++;
				if (line == 8)
				{
					String[] strs;
					strs = tempString.split(" ");
					return Double.parseDouble(strs[1]);
				}
			}
			reader.close();
		} catch (IOException e)
		{
			e.printStackTrace();
		} finally
		{
			if (reader != null)
			{
				try
				{
					reader.close();
				} catch (IOException e1)
				{
				}
			}
		}
		return -1;
	}

	public double get_D(String algorithm)
	{
		File file = new File(file_path_result + "(" + algorithm + ")" + ".txt");
		BufferedReader reader = null;
		try
		{
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			int line = 0;
			while ((tempString = reader.readLine()) != null)
			{
				line++;
				if (line == 9)
				{
					String[] strs;
					strs = tempString.split(" ");
					return Double.parseDouble(strs[1]);
				}
			}
			reader.close();
		} catch (IOException e)
		{
			e.printStackTrace();
		} finally
		{
			if (reader != null)
			{
				try
				{
					reader.close();
				} catch (IOException e1)
				{
				}
			}
		}
		return -1;
	}

	public long get_Time(String algorithm)
	{
		File file = new File(file_path_result + "(" + algorithm + ")" + ".txt");
		BufferedReader reader = null;
		try
		{
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			int line = 0;
			while ((tempString = reader.readLine()) != null)
			{
				line++;
				if (line == 10)
				{
					String[] strs;
					strs = tempString.split(" ");
					return Long.parseLong(strs[1]);
				}
			}
			reader.close();
		} catch (IOException e)
		{
			e.printStackTrace();
		} finally
		{
			if (reader != null)
			{
				try
				{
					reader.close();
				} catch (IOException e1)
				{
				}
			}
		}
		return -1;
	}

	/* Get partitionF from detected communities file */
	public ArrayList<TreeSet<Integer>> get_partitionF(String algorithm)
	{
		ArrayList<TreeSet<Integer>> partitionF = new ArrayList<TreeSet<Integer>>();
		File file = new File(file_path_result + "(" + algorithm + ")" + ".txt");
		BufferedReader reader = null;
		try
		{
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			int line = 0;
			while ((tempString = reader.readLine()) != null)
			{
				line++;
				if (line > 11)
				{
					String[] strs;
					strs = tempString.split("\t");
					TreeSet<Integer> community = new TreeSet<Integer>();
					for (int i = 0; i < strs.length; i++)
					{
						community.add(Integer.parseInt(strs[i]));
					}
					partitionF.add(community);
					// System.out.println(community);
				}
			}
			reader.close();
		} catch (IOException e)
		{
			e.printStackTrace();
		} finally
		{
			if (reader != null)
			{
				try
				{
					reader.close();
				} catch (IOException e1)
				{
				}
			}
		}
		return partitionF;
	}

	public void run_methords_on_realworld_network() throws IOException
	{
		initial_paramaters();
		ArrayList<TreeSet<Integer>> partitionF = new ArrayList<TreeSet<Integer>>();
		// ArrayList<TreeSet<Integer>> partitionR = new
		// ArrayList<TreeSet<Integer>>();
		// for (Iterator<ArrayList<Integer>> iter = real_communities.iterator();
		// iter
		// .hasNext();)
		// {
		// ArrayList<Integer> communtiy = iter.next();
		// TreeSet<Integer> temp_community = new TreeSet<Integer>();
		// temp_community.addAll(communtiy);
		// partitionR.add(temp_community);
		// }
		// ArrayList<OverlapNode> partitionF_overlap_nodes = new
		// ArrayList<OverlapNode>();
		// ArrayList<OverlapNode> partitionR_overlap_nodes =
		// get_overlap_nodes(partitionR);

		String wcpm_algorithm_name = "(wcpm).txt";
		String lfm_algorithm_name = "(lfm).txt";
		String docnet_algorithm_name = "(docnet).txt";
		String cfm_algorithm_name = "(cfm).txt";
		String twd_algorithm_name = "(twd).txt";
		String kce_algorithm_name = "(kce).txt";
		String kce1_algorithm_name = "(kce1).txt";
		String kce2_algorithm_name = "(kce2).txt";
		String kce3_algorithm_name = "(kce3).txt";
		String secd1_algorithm_name = "(secd1).txt";
		String secd2_algorithm_name = "(secd2).txt";
		String secd3_algorithm_name = "(secd3).txt";
		String cdbi1_algorithm_name = "(cdbi1).txt";
		String cdbi2_algorithm_name = "(cdbi2).txt";
		String cdbi3_algorithm_name = "(cdbi3).txt";

		long startTime;
		long endTime;

		/* NMI */
		double wcpm_NMI = 0;
		double lfm_NMI = 0;
		double docnet_NMI = 0;
		double cfm_NMI = 0;
		double twd_NMI = 0;
		double kce_NMI = 0;
		double kce1_NMI = 0;
		double kce2_NMI = 0;
		double kce3_NMI = 0;
		double secd1_NMI = 0;
		double secd2_NMI = 0;
		double secd3_NMI = 0;
		double cdbi1_NMI = 0;
		double cdbi2_NMI = 0;
		double cdbi3_NMI = 0;

		/* Q */
		double wcpm_Q = 0;
		double lfm_Q = 0;
		double docnet_Q = 0;
		double cfm_Q = 0;
		double twd_Q = 0;
		double kce_Q = 0;
		double kce1_Q = 0;
		double kce2_Q = 0;
		double kce3_Q = 0;
		double secd1_Q = 0;
		double secd2_Q = 0;
		double secd3_Q = 0;
		double cdbi1_Q = 0;
		double cdbi2_Q = 0;
		double cdbi3_Q = 0;

		/* rpf */
		ArrayList<Double> wcpm_rpf = new ArrayList<Double>();
		ArrayList<Double> lfm_rpf = new ArrayList<Double>();
		ArrayList<Double> docnet_rpf = new ArrayList<Double>();
		ArrayList<Double> cfm_rpf = new ArrayList<Double>();
		ArrayList<Double> twd_rpf = new ArrayList<Double>();
		ArrayList<Double> kce_rpf = new ArrayList<Double>();
		ArrayList<Double> kce1_rpf = new ArrayList<Double>();
		ArrayList<Double> kce2_rpf = new ArrayList<Double>();
		ArrayList<Double> kce3_rpf = new ArrayList<Double>();
		ArrayList<Double> secd1_rpf = new ArrayList<Double>();
		ArrayList<Double> secd2_rpf = new ArrayList<Double>();
		ArrayList<Double> secd3_rpf = new ArrayList<Double>();
		ArrayList<Double> cdbi1_rpf = new ArrayList<Double>();
		ArrayList<Double> cdbi2_rpf = new ArrayList<Double>();
		ArrayList<Double> cdbi3_rpf = new ArrayList<Double>();

		/* R */
		double wcpm_R = 0;
		double lfm_R = 0;
		double docnet_R = 0;
		double cfm_R = 0;
		double twd_R = 0;
		double kce_R = 0;
		double kce1_R = 0;
		double kce2_R = 0;
		double kce3_R = 0;
		double secd1_R = 0;
		double secd2_R = 0;
		double secd3_R = 0;
		double cdbi1_R = 0;
		double cdbi2_R = 0;
		double cdbi3_R = 0;

		/* P */
		double wcpm_P = 0;
		double lfm_P = 0;
		double docnet_P = 0;
		double cfm_P = 0;
		double twd_P = 0;
		double kce_P = 0;
		double kce1_P = 0;
		double kce2_P = 0;
		double kce3_P = 0;
		double secd1_P = 0;
		double secd2_P = 0;
		double secd3_P = 0;
		double cdbi1_P = 0;
		double cdbi2_P = 0;
		double cdbi3_P = 0;

		/* F */
		double wcpm_F = 0;
		double lfm_F = 0;
		double docnet_F = 0;
		double cfm_F = 0;
		double twd_F = 0;
		double kce_F = 0;
		double kce1_F = 0;
		double kce2_F = 0;
		double kce3_F = 0;
		double secd1_F = 0;
		double secd2_F = 0;
		double secd3_F = 0;
		double cdbi1_F = 0;
		double cdbi2_F = 0;
		double cdbi3_F = 0;

		/* FMeasure */
		double wcpm_FMeasure = 0;
		double lfm_FMeasure = 0;
		double docnet_FMeasure = 0;
		double cfm_FMeasure = 0;
		double twd_FMeasure = 0;
		double kce_FMeasure = 0;
		double kce1_FMeasure = 0;
		double kce2_FMeasure = 0;
		double kce3_FMeasure = 0;
		double secd1_FMeasure = 0;
		double secd2_FMeasure = 0;
		double secd3_FMeasure = 0;
		double cdbi1_FMeasure = 0;
		double cdbi2_FMeasure = 0;
		double cdbi3_FMeasure = 0;

		/* V */
		double wcpm_V = 0;
		double lfm_V = 0;
		double docnet_V = 0;
		double cfm_V = 0;
		double twd_V = 0;
		double kce_V = 0;
		double kce1_V = 0;
		double kce2_V = 0;
		double kce3_V = 0;
		double secd1_V = 0;
		double secd2_V = 0;
		double secd3_V = 0;
		double cdbi1_V = 0;
		double cdbi2_V = 0;
		double cdbi3_V = 0;

		/* no */
		double wcpm_no = 0;
		double lfm_no = 0;
		double docnet_no = 0;
		double cfm_no = 0;
		double twd_no = 0;
		double kce_no = 0;
		double kce1_no = 0;
		double kce2_no = 0;
		double kce3_no = 0;
		double secd1_no = 0;
		double secd2_no = 0;
		double secd3_no = 0;
		double cdbi1_no = 0;
		double cdbi2_no = 0;
		double cdbi3_no = 0;

		/* D */
		double wcpm_D = 0;
		double lfm_D = 0;
		double docnet_D = 0;
		double cfm_D = 0;
		double twd_D = 0;
		double kce_D = 0;
		double kce1_D = 0;
		double kce2_D = 0;
		double kce3_D = 0;
		double secd1_D = 0;
		double secd2_D = 0;
		double secd3_D = 0;
		double cdbi1_D = 0;
		double cdbi2_D = 0;
		double cdbi3_D = 0;

		/* Time */
		long wcpm_costTime = 0;
		long lfm_costTime = 0;
		long docnet_costTime = 0;
		long cfm_costTime = 0;
		long twd_costTime = 0;
		long kce_costTime = 0;
		long kce1_costTime = 0;
		long kce2_costTime = 0;
		long kce3_costTime = 0;
		long secd1_costTime = 0;
		long secd2_costTime = 0;
		long secd3_costTime = 0;
		long cdbi1_costTime = 0;
		long cdbi2_costTime = 0;
		long cdbi3_costTime = 0;

		/*****************************************************************************************/
		// partitionF = get_partitionF("kce1");
		// kce1_NMI = get_NMI("kce1");
		// kce1_Q = get_Q("kce1");
		// kce1_R = get_R("kce1");
		// kce1_P = get_P("kce1");
		// kce1_F = get_F("kce1");
		// kce1_FMeasure = get_FMeasure("kce1");
		// kce1_V = get_V("kce1");
		// kce1_D = get_D("kce1");
		// kce1_Q = get_Q("kce1");
		// kce1_costTime = get_Time("kce1");

		// KCoreExtensionAlgorithm1 kce1 = new KCoreExtensionAlgorithm1(n,
		// adjacencyTable);
		// startTime = System.currentTimeMillis();
		// partitionF = kce1.run_kce1();
		// endTime = System.currentTimeMillis();
		// kce1_costTime = endTime - startTime;
		// System.out.println("kce1_costTime: " + kce1_costTime);
		// xstartTime = System.currentTimeMillis();
		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
		// kce1_NMI = NMIPartitionLFK(partitionR, partitionF);
		// kce1_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
		// kce1_rpf = get_recall_precision_fscore(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// kce1_R = kce1_rpf.get(0);
		// kce1_P = kce1_rpf.get(1);
		// kce1_F = kce1_rpf.get(2);
		// kce1_V = calculate_variance(partitionF_overlap_nodes,
		// partitionR_overlap_nodes);
		// kce1_no =
		// calculate_no(partitionR_overlap_nodes,partitionF_overlap_nodes);
		// kce1_D = calculate_D(partitionF.size(), partitionR.size());
		// kce1_FMeasure = get_fmeasure(partitionR, partitionF);

		// write_results_into_files(kce1_algorithm_name, kce1_NMI, kce1_Q,
		// kce1_R,
		// kce1_P, kce1_F, kce1_FMeasure, kce1_V, kce1_D, kce1_costTime,
		// partitionF);
		/*****************************************************************************************/
		// partitionF = get_partitionF("kce2");
		// kce2_NMI = get_NMI("kce2");
		// kce2_Q = get_Q("kce2");
		// kce2_R = get_R("kce2");
		// kce2_P = get_P("kce2");
		// kce2_F = get_F("kce2");
		// kce2_FMeasure = get_FMeasure("kce2");
		// kce2_V = get_V("kce2");
		// kce2_D = get_D("kce2");
		// kce2_Q = get_Q("kce2");
		// kce2_costTime = get_Time("kce2");

		// KCoreExtensionAlgorithm2 kce2 = new KCoreExtensionAlgorithm2(n,
		// adjacencyTable);
		// startTime = System.currentTimeMillis();
		// partitionF = kce2.run_kce2();
		// endTime = System.currentTimeMillis();
		// kce2_costTime = endTime - startTime;
		// System.out.println("kce2_costTime: " + kce2_costTime);
		// xstartTime = System.currentTimeMillis();
		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
		// kce2_NMI = NMIPartitionLFK(partitionR, partitionF);
		// kce2_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
		// kce2_rpf = get_recall_precision_fscore(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// kce2_R = kce2_rpf.get(0);
		// kce2_P = kce2_rpf.get(1);
		// kce2_F = kce2_rpf.get(2);
		// kce2_V = calculate_variance(partitionF_overlap_nodes,
		// partitionR_overlap_nodes);
		// kce2_no =
		// calculate_no(partitionR_overlap_nodes,partitionF_overlap_nodes);
		// kce2_D = calculate_D(partitionF.size(), partitionR.size());
		// kce2_FMeasure = get_fmeasure(partitionR, partitionF);

		// write_results_into_files(kce2_algorithm_name, kce2_NMI, kce2_Q,
		// kce2_R,
		// kce2_P, kce2_F, kce2_FMeasure, kce2_V, kce2_D, kce2_costTime,
		// partitionF);
		/*****************************************************************************************/
		// partitionF = get_partitionF("kce3");
		// kce3_NMI = get_NMI("kce3");
		// kce3_Q = get_Q("kce3");
		// kce3_R = get_R("kce3");
		// kce3_P = get_P("kce3");
		// kce3_F = get_F("kce3");
		// kce3_FMeasure = get_FMeasure("kce3");
		// kce3_V = get_V("kce3");
		// kce3_D = get_D("kce3");
		// kce3_Q = get_Q("kce3");
		// kce3_costTime = get_Time("kce3");

		// KCoreExtensionAlgorithm3 kce3 = new KCoreExtensionAlgorithm3(n,
		// adjacencyTable);
		// startTime = System.currentTimeMillis();
		// partitionF = kce3.run_kce3();
		// endTime = System.currentTimeMillis();
		// kce3_costTime = endTime - startTime;
		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
		// kce3_NMI = NMIPartitionLFK(partitionR, partitionF);
		// kce3_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
		// kce3_rpf = get_recall_precision_fscore(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// kce3_R = kce3_rpf.get(0);
		// kce3_P = kce3_rpf.get(1);
		// kce3_F = kce3_rpf.get(2);
		// kce3_V = calculate_variance(partitionF_overlap_nodes,
		// partitionR_overlap_nodes);
		// kce3_no =
		// calculate_no(partitionR_overlap_nodes,partitionF_overlap_nodes);
		// kce3_D = calculate_D(partitionF.size(), partitionR.size());
		// kce3_FMeasure = get_fmeasure(partitionR, partitionF);

		// write_results_into_files(kce3_algorithm_name, kce3_NMI, kce3_Q,
		// kce3_R,
		// kce3_P, kce3_F, kce3_FMeasure, kce3_V, kce3_D, kce3_costTime,
		// partitionF);
		/*****************************************************************************************/
		// partitionF = get_partitionF("kce");
		// kce_NMI = get_NMI("kce");
		// kce_Q = get_Q("kce");
		// kce_R = get_R("kce");
		// kce_P = get_P("kce");
		// kce_F = get_F("kce");
		// kce_FMeasure = get_FMeasure("kce");
		// kce_V = get_V("kce");
		// kce_D = get_D("kce");
		// kce_Q = get_Q("kce");
		// kce_costTime = get_Time("kce");

		// KCoreExtensionAlgorithm kce = new KCoreExtensionAlgorithm(n,
		// adjacencyTable);
		// startTime = System.currentTimeMillis();
		// partitionF = kce.run_kce();
		// endTime = System.currentTimeMillis();
		// kce_costTime = endTime - startTime;
		// System.out.println("kce_costTime: " + kce_costTime);
		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
		// kce_NMI = NMIPartitionLFK(partitionR, partitionF);
		// kce_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
		// kce_rpf = get_recall_precision_fscore(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// kce_R = kce_rpf.get(0);
		// kce_P = kce_rpf.get(1);
		// kce_F = kce_rpf.get(2);
		// kce_V = calculate_variance(partitionF_overlap_nodes,
		// partitionR_overlap_nodes);
		// kce_no =
		// calculate_no(partitionR_overlap_nodes,partitionF_overlap_nodes);
		// kce_D = calculate_D(partitionF.size(), partitionR.size());
		// kce_FMeasure = get_fmeasure(partitionR, partitionF);

		// write_results_into_files(kce_algorithm_name, kce_NMI, kce_Q, kce_R,
		// kce_P, kce_F, kce_FMeasure, kce_V, kce_D, kce_costTime,
		// partitionF);
		/*****************************************************************************************/
		partitionF = get_partitionF("cdbi1");
		cdbi1_NMI = get_NMI("cdbi1");
		cdbi1_Q = get_Q("cdbi1");
		cdbi1_R = get_R("cdbi1");
		cdbi1_P = get_P("cdbi1");
		cdbi1_F = get_F("cdbi1");
		cdbi1_FMeasure = get_FMeasure("cdbi1");
		cdbi1_V = get_V("cdbi1");
		cdbi1_no = get_no("cdbi1");
		cdbi1_D = get_D("cdbi1");
		cdbi1_costTime = get_Time("cdbi1");
		System.out.println("cdbi1_costTime: " + cdbi1_costTime);

		// BoundaryIdentification1 cdbi1 = new BoundaryIdentification1(n, m,
		// adjacencyTable);
		// startTime = System.currentTimeMillis();
		// partitionF = cdbi1.run_six();
		// endTime = System.currentTimeMillis();
		// cdbi1_costTime = endTime - startTime;
		// System.out.println("cdbi1_costTime: " + cdbi1_costTime);
		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
		// cdbi1_NMI = NMIPartitionLFK(partitionR, partitionF);
		// cdbi1_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
		// cdbi1_rpf = get_recall_precision_fscore(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// cdbi1_R = cdbi1_rpf.get(0);
		// cdbi1_P = cdbi1_rpf.get(1);
		// cdbi1_F = cdbi1_rpf.get(2);
		// cdbi1_V = calculate_variance(partitionF_overlap_nodes,
		// partitionR_overlap_nodes);
		// cdbi1_no = calculate_no(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// cdbi1_D = calculate_D(partitionF.size(), partitionR.size());
		// cdbi1_FMeasure = get_fmeasure(partitionR, partitionF);

		// write_results_into_files(cdbi1_algorithm_name, cdbi1_NMI, cdbi1_Q,
		// cdbi1_R, cdbi1_P, cdbi1_F, cdbi1_FMeasure, cdbi1_V, cdbi1_no,
		// cdbi1_D, cdbi1_costTime, partitionF);
		/*****************************************************************************************/
		partitionF = get_partitionF("cdbi2");
		cdbi2_NMI = get_NMI("cdbi2");
		cdbi2_Q = get_Q("cdbi2");
		cdbi2_R = get_R("cdbi2");
		cdbi2_P = get_P("cdbi2");
		cdbi2_F = get_F("cdbi2");
		cdbi2_FMeasure = get_FMeasure("cdbi2");
		cdbi2_V = get_V("cdbi2");
		cdbi2_no = get_no("cdbi2");
		cdbi2_D = get_D("cdbi2");
		cdbi2_costTime = get_Time("cdbi2");
		System.out.println("cdbi2_costTime: " + cdbi2_costTime);

		// BoundaryIdentification2 cdbi2 = new BoundaryIdentification2(n, m,
		// adjacencyTable);
		// startTime = System.currentTimeMillis();
		// partitionF = cdbi2.run_six();
		// endTime = System.currentTimeMillis();
		// cdbi2_costTime = endTime - startTime;
		// System.out.println("cdbi2_costTime: " + cdbi2_costTime);
		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
		// cdbi2_NMI = NMIPartitionLFK(partitionR, partitionF);
		// cdbi2_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
		// cdbi2_rpf = get_recall_precision_fscore(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// cdbi2_R = cdbi2_rpf.get(0);
		// cdbi2_P = cdbi2_rpf.get(1);
		// cdbi2_F = cdbi2_rpf.get(2);
		// cdbi2_V = calculate_variance(partitionF_overlap_nodes,
		// partitionR_overlap_nodes);
		// cdbi2_no = calculate_no(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// cdbi2_D = calculate_D(partitionF.size(), partitionR.size());
		// cdbi2_FMeasure = get_fmeasure(partitionR, partitionF);

		// write_results_into_files(cdbi2_algorithm_name, cdbi2_NMI, cdbi2_Q,
		// cdbi2_R, cdbi2_P, cdbi2_F, cdbi2_FMeasure, cdbi2_V, cdbi2_no,
		// cdbi2_D, cdbi2_costTime, partitionF);
		/*****************************************************************************************/
		partitionF = get_partitionF("cdbi3");
		cdbi3_NMI = get_NMI("cdbi3");
		cdbi3_Q = get_Q("cdbi3");
		cdbi3_R = get_R("cdbi3");
		cdbi3_P = get_P("cdbi3");
		cdbi3_F = get_F("cdbi3");
		cdbi3_FMeasure = get_FMeasure("cdbi3");
		cdbi3_V = get_V("cdbi3");
		cdbi3_no = get_no("cdbi3");
		cdbi3_D = get_D("cdbi3");
		cdbi3_costTime = get_Time("cdbi3");
		System.out.println("cdbi3_costTime: " + cdbi3_costTime);

		// BoundaryIdentification3 cdbi3 = new BoundaryIdentification3(n, m,
		// adjacencyTable);
		// startTime = System.currentTimeMillis();
		// partitionF = cdbi3.run_six();
		// endTime = System.currentTimeMillis();
		// cdbi3_costTime = endTime - startTime;
		// System.out.println("cdbi3_costTime: " + cdbi3_costTime);
		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
		// cdbi3_NMI = NMIPartitionLFK(partitionR, partitionF);
		// cdbi3_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
		// cdbi3_rpf = get_recall_precision_fscore(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// cdbi3_R = cdbi3_rpf.get(0);
		// cdbi3_P = cdbi3_rpf.get(1);
		// cdbi3_F = cdbi3_rpf.get(2);
		// cdbi3_V = calculate_variance(partitionF_overlap_nodes,
		// partitionR_overlap_nodes);
		// cdbi3_no = calculate_no(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// cdbi3_D = calculate_D(partitionF.size(), partitionR.size());
		// cdbi3_FMeasure = get_fmeasure(partitionR, partitionF);

		// write_results_into_files(cdbi3_algorithm_name, cdbi3_NMI, cdbi3_Q,
		// cdbi3_R, cdbi3_P, cdbi3_F, cdbi3_FMeasure, cdbi3_V, cdbi3_no,
		// cdbi3_D, cdbi3_costTime, partitionF);
		/*****************************************************************************************/
		// partitionF = get_partitionF("secd1");
		// secd1_NMI = get_NMI("secd1");
		// secd1_Q = get_Q("secd1");
		// secd1_R = get_R("secd1");
		// secd1_P = get_P("secd1");
		// secd1_F = get_F("secd1");
		// secd1_FMeasure = get_FMeasure("secd1");
		// secd1_V = get_V("secd1");
		// secd1_D = get_D("secd1");
		// secd1_costTime = get_Time("secd1");

		// CommunityBasedOnCores1 secd1 = new CommunityBasedOnCores1(n, m,
		// adjacencyTable);
		// startTime = System.currentTimeMillis();
		// partitionF = secd1.run_six();
		// endTime = System.currentTimeMillis();
		// secd1_costTime = endTime - startTime;
		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
		// secd1_NMI = NMIPartitionLFK(partitionR, partitionF);
		// secd1_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
		// secd1_rpf = get_recall_precision_fscore(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// secd1_R = secd1_rpf.get(0);
		// secd1_P = secd1_rpf.get(1);
		// secd1_F = secd1_rpf.get(2);
		// secd1_V = calculate_variance(partitionF_overlap_nodes,
		// partitionR_overlap_nodes);
		// secd1_no = calculate_no(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// secd1_D = calculate_D(partitionF.size(), partitionR.size());
		// secd1_FMeasure = get_fmeasure(partitionR, partitionF);

		// write_results_into_files(secd1_algorithm_name, secd1_NMI, secd1_Q,
		// secd1_R, secd1_P, secd1_F, secd1_FMeasure, secd1_V, secd1_no,
		// secd1_D, secd1_costTime, partitionF);
		/*****************************************************************************************/
		// partitionF = get_partitionF("secd2");
		// secd2_NMI = get_NMI("secd2");
		// secd2_Q = get_Q("secd2");
		// secd2_R = get_R("secd2");
		// secd2_P = get_P("secd2");
		// secd2_F = get_F("secd2");
		// secd2_FMeasure = get_FMeasure("secd2");
		// secd2_V = get_V("secd2");
		// secd2_D = get_D("secd2");
		// secd2_costTime = get_Time("secd2");

		// CommunityBasedOnCores2 secd2 = new CommunityBasedOnCores2(n, m,
		// adjacencyTable);
		// startTime = System.currentTimeMillis();
		// partitionF = secd2.run_six();
		// endTime = System.currentTimeMillis();
		// secd2_costTime = endTime - startTime;
		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
		// secd2_NMI = NMIPartitionLFK(partitionR, partitionF);
		// secd2_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
		// secd2_rpf = get_recall_precision_fscore(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// secd2_R = secd2_rpf.get(0);
		// secd2_P = secd2_rpf.get(1);
		// secd2_F = secd2_rpf.get(2);
		// secd2_V = calculate_variance(partitionF_overlap_nodes,
		// partitionR_overlap_nodes);
		// secd2_no = calculate_no(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// secd2_D = calculate_D(partitionF.size(), partitionR.size());
		// secd2_FMeasure = get_fmeasure(partitionR, partitionF);

		// write_results_into_files(secd2_algorithm_name, secd2_NMI, secd2_Q,
		// secd2_R, secd2_P, secd2_F, secd2_FMeasure, secd2_V, secd2_no,
		// secd2_D, secd2_costTime, partitionF);
		/*****************************************************************************************/
		// partitionF = get_partitionF("secd3");
		// secd3_NMI = get_NMI("secd3");
		// secd3_Q = get_Q("secd3");
		// secd3_R = get_R("secd3");
		// secd3_P = get_P("secd3");
		// secd3_F = get_F("secd3");
		// secd3_FMeasure = get_FMeasure("secd3");
		// secd3_V = get_V("secd3");
		// secd3_D = get_D("secd3");
		// secd3_costTime = get_Time("secd3");

		// CommunityBasedOnCores3 secd3 = new CommunityBasedOnCores3(n, m,
		// adjacencyTable);
		// startTime = System.currentTimeMillis();
		// partitionF = secd3.run_six();
		// endTime = System.currentTimeMillis();
		// secd3_costTime = endTime - startTime;
		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
		// secd3_NMI = NMIPartitionLFK(partitionR, partitionF);
		// secd3_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
		// secd3_rpf = get_recall_precision_fscore(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// secd3_R = secd3_rpf.get(0);
		// secd3_P = secd3_rpf.get(1);
		// secd3_F = secd3_rpf.get(2);
		// secd3_V = calculate_variance(partitionF_overlap_nodes,
		// partitionR_overlap_nodes);
		// secd3_no = calculate_no(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// secd3_D = calculate_D(partitionF.size(), partitionR.size());
		// secd3_FMeasure = get_fmeasure(partitionR, partitionF);

		// write_results_into_files(secd3_algorithm_name, secd3_NMI, secd3_Q,
		// secd3_R, secd3_P, secd3_F, secd3_FMeasure, secd3_V, secd3_no,
		// secd3_D, secd3_costTime, partitionF);
		/*****************************************************************************************/
		partitionF = get_partitionF("wcpm");
		wcpm_NMI = get_NMI("wcpm");
		wcpm_Q = get_Q("wcpm");
		wcpm_R = get_R("wcpm");
		wcpm_P = get_P("wcpm");
		wcpm_F = get_F("wcpm");
		wcpm_FMeasure = get_FMeasure("wcpm");
		wcpm_V = get_V("wcpm");
		wcpm_no = get_no("wcpm");
		wcpm_D = get_D("wcpm");
		wcpm_costTime = get_Time("wcpm");
		System.out.println("wcpm_costTime: " + wcpm_costTime);

		// WCPMAlgorithm wcpm = new WCPMAlgorithm(n, adjacencyTable);
		// startTime = System.currentTimeMillis();
		// partitionF = wcpm.run_wcpm();
		// endTime = System.currentTimeMillis();
		// wcpm_costTime = endTime - startTime;
		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
		// wcpm_NMI = NMIPartitionLFK(partitionR, partitionF);
		// wcpm_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
		// wcpm_rpf = get_recall_precision_fscore(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// wcpm_R = wcpm_rpf.get(0);
		// wcpm_P = wcpm_rpf.get(1);
		// wcpm_F = wcpm_rpf.get(2);
		// wcpm_V = calculate_variance(partitionF_overlap_nodes,
		// partitionR_overlap_nodes);
		// wcpm_no = calculate_no(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// wcpm_D = calculate_D(partitionF.size(), partitionR.size());
		// wcpm_FMeasure = get_fmeasure(partitionR, partitionF);

		// write_results_into_files(wcpm_algorithm_name, wcpm_NMI, wcpm_Q,
		// wcpm_R,
		// wcpm_P, wcpm_F, wcpm_FMeasure, wcpm_V, wcpm_no, wcpm_D,
		// wcpm_costTime, partitionF);
		/*****************************************************************************************/
		partitionF = get_partitionF("lfm");
		lfm_NMI = get_NMI("lfm");
		lfm_Q = get_Q("lfm");
		lfm_R = get_R("lfm");
		lfm_P = get_P("lfm");
		lfm_F = get_F("lfm");
		lfm_FMeasure = get_FMeasure("lfm");
		lfm_V = get_V("lfm");
		lfm_no = get_no("lfm");
		lfm_D = get_D("lfm");
		lfm_costTime = get_Time("lfm");
		System.out.println("lfm_costTime: " + lfm_costTime);

		// LFMAlgorithm lfm = new LFMAlgorithm(n, adjacencyTable, 1);
		// startTime = System.currentTimeMillis();
		// partitionF = lfm.run_lfm();
		// endTime = System.currentTimeMillis();
		// lfm_costTime = endTime - startTime;
		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
		// lfm_NMI = NMIPartitionLFK(partitionR, partitionF);
		// lfm_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
		// lfm_rpf = get_recall_precision_fscore(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// lfm_R = lfm_rpf.get(0);
		// lfm_P = lfm_rpf.get(1);
		// lfm_F = lfm_rpf.get(2);
		// lfm_V = calculate_variance(partitionF_overlap_nodes,
		// partitionR_overlap_nodes);
		// lfm_no = calculate_no(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// lfm_D = calculate_D(partitionF.size(), partitionR.size());
		// lfm_FMeasure = get_fmeasure(partitionR, partitionF);

		// write_results_into_files(lfm_algorithm_name, lfm_NMI, lfm_Q, lfm_R,
		// lfm_P, lfm_F, lfm_FMeasure, lfm_V, lfm_no, lfm_D, lfm_costTime,
		// partitionF);
		/*****************************************************************************************/
		partitionF = get_partitionF("docnet");
		docnet_NMI = get_NMI("docnet");
		docnet_Q = get_Q("docnet");
		docnet_R = get_R("docnet");
		docnet_P = get_P("docnet");
		docnet_F = get_F("docnet");
		docnet_FMeasure = get_FMeasure("docnet");
		docnet_V = get_V("docnet");
		docnet_no = get_no("docnet");
		docnet_D = get_D("docnet");
		docnet_costTime = get_Time("docnet");
		System.out.println("docnet_costTime: " + docnet_costTime);

		// DOCnetAlgorithm docnet = new DOCnetAlgorithm(n, adjacencyTable);
		// startTime = System.currentTimeMillis();
		// partitionF = docnet.run_docnet();
		// endTime = System.currentTimeMillis();
		// docnet_costTime = endTime - startTime;
		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
		// docnet_NMI = NMIPartitionLFK(partitionR, partitionF);
		// docnet_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
		// docnet_rpf = get_recall_precision_fscore(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// docnet_R = docnet_rpf.get(0);
		// docnet_P = docnet_rpf.get(1);
		// docnet_F = docnet_rpf.get(2);
		// docnet_V = calculate_variance(partitionF_overlap_nodes,
		// partitionR_overlap_nodes);
		// docnet_no = calculate_no(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// docnet_D = calculate_D(partitionF.size(), partitionR.size());
		// docnet_FMeasure = get_fmeasure(partitionR, partitionF);

		// write_results_into_files(docnet_algorithm_name, docnet_NMI, docnet_Q,
		// docnet_R, docnet_P, docnet_F, docnet_FMeasure, docnet_V,
		// docnet_no, docnet_D, docnet_costTime, partitionF);
		/*****************************************************************************************/
		// partitionF = get_partitionF("cfm");
		cfm_NMI = get_NMI("cfm");
		cfm_Q = get_Q("cfm");
		cfm_R = get_R("cfm");
		cfm_P = get_P("cfm");
		cfm_F = get_F("cfm");
		cfm_FMeasure = get_FMeasure("cfm");
		cfm_V = get_V("cfm");
		cfm_no = get_no("cfm");
		cfm_D = get_D("cfm");
		cfm_costTime = get_Time("cfm");
		System.out.println("cfm_costTime: " + cfm_costTime);

		// CFMAlgorithm cfm = new CFMAlgorithm(n, m, adjacencyTable);
		// startTime = System.currentTimeMillis();
		// partitionF = cfm.run_cfm();
		// endTime = System.currentTimeMillis();
		// cfm_costTime = endTime - startTime;
		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
		// cfm_NMI = NMIPartitionLFK(partitionR, partitionF);
		// cfm_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
		// cfm_rpf = get_recall_precision_fscore(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// cfm_R = cfm_rpf.get(0);
		// cfm_P = cfm_rpf.get(1);
		// cfm_F = cfm_rpf.get(2);
		// cfm_V = calculate_variance(partitionF_overlap_nodes,
		// partitionR_overlap_nodes);
		// cfm_no = calculate_no(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// cfm_D = calculate_D(partitionF.size(), partitionR.size());
		// cfm_FMeasure = get_fmeasure(partitionR, partitionF);

		// write_results_into_files(cfm_algorithm_name, cfm_NMI, cfm_Q, cfm_R,
		// cfm_P, cfm_F, cfm_FMeasure, cfm_V, cfm_no, cfm_D, cfm_costTime,
		// partitionF);
		/*****************************************************************************************/
		partitionF = get_partitionF("twd");
		twd_NMI = get_NMI("twd");
		twd_Q = get_Q("twd");
		twd_R = get_R("twd");
		twd_P = get_P("twd");
		twd_F = get_F("twd");
		twd_FMeasure = get_FMeasure("twd");
		twd_V = get_V("twd");
		twd_no = get_no("twd");
		twd_D = get_D("twd");
		twd_costTime = get_Time("twd");
		System.out.println("twd_costTime: " + twd_costTime);

		// TWDAlgorithm twd = new TWDAlgorithm(n, adjacencyTable, 0.48, 0.47,
		// 0.5);
		// startTime = System.currentTimeMillis();
		// partitionF = twd.run_twd();
		// endTime = System.currentTimeMillis();
		// twd_costTime = endTime - startTime;
		// partitionF_overlap_nodes = get_overlap_nodes(partitionF);
		// twd_NMI = NMIPartitionLFK(partitionR, partitionF);
		// twd_Q = calculate_Q(partitionF, partitionF_overlap_nodes);
		// twd_rpf = get_recall_precision_fscore(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// twd_R = twd_rpf.get(0);
		// twd_P = twd_rpf.get(1);
		// twd_F = twd_rpf.get(2);
		// twd_V = calculate_variance(partitionF_overlap_nodes,
		// partitionR_overlap_nodes);
		// twd_no = calculate_no(partitionR_overlap_nodes,
		// partitionF_overlap_nodes);
		// twd_D = calculate_D(partitionF.size(), partitionR.size());
		// twd_FMeasure = get_fmeasure(partitionR, partitionF);

		// write_results_into_files(twd_algorithm_name, twd_NMI, twd_Q, twd_R,
		// twd_P, twd_F, twd_FMeasure, twd_V, twd_no, twd_D, twd_costTime,
		// partitionF);
		/*****************************************************************************************/

		kce1_NMI = (double) (Math.round(kce1_NMI * 10000) / 10000.0);
		kce1_Q = (double) (Math.round(kce1_Q * 10000) / 10000.0);
		kce1_R = (double) (Math.round(kce1_R * 10000) / 10000.0);
		kce1_P = (double) (Math.round(kce1_P * 10000) / 10000.0);
		kce1_F = (double) (Math.round(kce1_F * 10000) / 10000.0);
		kce1_FMeasure = (double) (Math.round(kce1_FMeasure * 10000) / 10000.0);
		kce1_V = (double) (Math.round(kce1_V * 10000) / 10000.0);
		kce1_no = (double) (Math.round(kce1_no * 10000) / 10000.0);
		kce1_D = (double) (Math.round(kce1_D * 10000) / 10000.0);
		kce1_costTime = (long) (Math.round(kce1_costTime * 10000) / 10000.0);

		kce2_NMI = (double) (Math.round(kce2_NMI * 10000) / 10000.0);
		kce2_Q = (double) (Math.round(kce2_Q * 10000) / 10000.0);
		kce2_R = (double) (Math.round(kce2_R * 10000) / 10000.0);
		kce2_P = (double) (Math.round(kce2_P * 10000) / 10000.0);
		kce2_F = (double) (Math.round(kce2_F * 10000) / 10000.0);
		kce2_FMeasure = (double) (Math.round(kce2_FMeasure * 10000) / 10000.0);
		kce2_V = (double) (Math.round(kce2_V * 10000) / 10000.0);
		kce2_no = (double) (Math.round(kce2_no * 10000) / 10000.0);
		kce2_D = (double) (Math.round(kce2_D * 10000) / 10000.0);
		kce2_costTime = (long) (Math.round(kce2_costTime * 10000) / 10000.0);

		kce3_NMI = (double) (Math.round(kce3_NMI * 10000) / 10000.0);
		kce3_Q = (double) (Math.round(kce3_Q * 10000) / 10000.0);
		kce3_R = (double) (Math.round(kce3_R * 10000) / 10000.0);
		kce3_P = (double) (Math.round(kce3_P * 10000) / 10000.0);
		kce3_F = (double) (Math.round(kce3_F * 10000) / 10000.0);
		kce3_FMeasure = (double) (Math.round(kce3_FMeasure * 10000) / 10000.0);
		kce3_V = (double) (Math.round(kce3_V * 10000) / 10000.0);
		kce3_no = (double) (Math.round(kce3_no * 10000) / 10000.0);
		kce3_D = (double) (Math.round(kce3_D * 10000) / 10000.0);
		kce3_costTime = (long) (Math.round(kce3_costTime * 10000) / 10000.0);

		kce_NMI = (double) (Math.round(kce_NMI * 10000) / 10000.0);
		kce_Q = (double) (Math.round(kce_Q * 10000) / 10000.0);
		kce_R = (double) (Math.round(kce_R * 10000) / 10000.0);
		kce_P = (double) (Math.round(kce_P * 10000) / 10000.0);
		kce_F = (double) (Math.round(kce_F * 10000) / 10000.0);
		kce_FMeasure = (double) (Math.round(kce_FMeasure * 10000) / 10000.0);
		kce_V = (double) (Math.round(kce_V * 10000) / 10000.0);
		kce_no = (double) (Math.round(kce_no * 10000) / 10000.0);
		kce_D = (double) (Math.round(kce_D * 10000) / 10000.0);
		kce_costTime = (long) (Math.round(kce_costTime * 10000) / 10000.0);

		wcpm_NMI = (double) (Math.round(wcpm_NMI * 10000) / 10000.0);
		wcpm_Q = (double) (Math.round(wcpm_Q * 10000) / 10000.0);
		wcpm_R = (double) (Math.round(wcpm_R * 10000) / 10000.0);
		wcpm_P = (double) (Math.round(wcpm_P * 10000) / 10000.0);
		wcpm_F = (double) (Math.round(wcpm_F * 10000) / 10000.0);
		wcpm_FMeasure = (double) (Math.round(wcpm_FMeasure * 10000) / 10000.0);
		wcpm_V = (double) (Math.round(wcpm_V * 10000) / 10000.0);
		wcpm_no = (double) (Math.round(wcpm_no * 10000) / 10000.0);
		wcpm_D = (double) (Math.round(wcpm_D * 10000) / 10000.0);
		wcpm_costTime = (long) (Math.round(wcpm_costTime * 10000) / 10000.0);

		lfm_NMI = (double) (Math.round(lfm_NMI * 10000) / 10000.0);
		lfm_Q = (double) (Math.round(lfm_Q * 10000) / 10000.0);
		lfm_R = (double) (Math.round(lfm_R * 10000) / 10000.0);
		lfm_P = (double) (Math.round(lfm_P * 10000) / 10000.0);
		lfm_F = (double) (Math.round(lfm_F * 10000) / 10000.0);
		lfm_FMeasure = (double) (Math.round(lfm_FMeasure * 10000) / 10000.0);
		lfm_V = (double) (Math.round(lfm_V * 10000) / 10000.0);
		lfm_no = (double) (Math.round(lfm_no * 10000) / 10000.0);
		lfm_D = (double) (Math.round(lfm_D * 10000) / 10000.0);
		lfm_costTime = (long) (Math.round(lfm_costTime * 10000) / 10000.0);

		docnet_NMI = (double) (Math.round(docnet_NMI * 10000) / 10000.0);
		docnet_Q = (double) (Math.round(docnet_Q * 10000) / 10000.0);
		docnet_R = (double) (Math.round(docnet_R * 10000) / 10000.0);
		docnet_P = (double) (Math.round(docnet_P * 10000) / 10000.0);
		docnet_F = (double) (Math.round(docnet_F * 10000) / 10000.0);
		docnet_FMeasure = (double) (Math.round(docnet_FMeasure * 10000) / 10000.0);
		docnet_V = (double) (Math.round(docnet_V * 10000) / 10000.0);
		docnet_no = (double) (Math.round(docnet_no * 10000) / 10000.0);
		docnet_D = (double) (Math.round(docnet_D * 10000) / 10000.0);
		docnet_costTime = (long) (Math.round(docnet_costTime * 10000) / 10000.0);

		cfm_NMI = (double) (Math.round(cfm_NMI * 10000) / 10000.0);
		cfm_Q = (double) (Math.round(cfm_Q * 10000) / 10000.0);
		cfm_R = (double) (Math.round(cfm_R * 10000) / 10000.0);
		cfm_P = (double) (Math.round(cfm_P * 10000) / 10000.0);
		cfm_F = (double) (Math.round(cfm_F * 10000) / 10000.0);
		cfm_FMeasure = (double) (Math.round(cfm_FMeasure * 10000) / 10000.0);
		cfm_V = (double) (Math.round(cfm_V * 10000) / 10000.0);
		cfm_no = (double) (Math.round(cfm_no * 10000) / 10000.0);
		cfm_D = (double) (Math.round(cfm_D * 10000) / 10000.0);
		cfm_costTime = (long) (Math.round(cfm_costTime * 10000) / 10000.0);

		twd_NMI = (double) (Math.round(twd_NMI * 10000) / 10000.0);
		twd_Q = (double) (Math.round(twd_Q * 10000) / 10000.0);
		twd_R = (double) (Math.round(twd_R * 10000) / 10000.0);
		twd_P = (double) (Math.round(twd_P * 10000) / 10000.0);
		twd_F = (double) (Math.round(twd_F * 10000) / 10000.0);
		twd_FMeasure = (double) (Math.round(twd_FMeasure * 10000) / 10000.0);
		twd_V = (double) (Math.round(twd_V * 10000) / 10000.0);
		twd_no = (double) (Math.round(twd_no * 10000) / 10000.0);
		twd_D = (double) (Math.round(twd_D * 10000) / 10000.0);
		twd_costTime = (long) (Math.round(twd_costTime * 10000) / 10000.0);

		secd1_NMI = (double) (Math.round(secd1_NMI * 10000) / 10000.0);
		secd1_Q = (double) (Math.round(secd1_Q * 10000) / 10000.0);
		secd1_R = (double) (Math.round(secd1_R * 10000) / 10000.0);
		secd1_P = (double) (Math.round(secd1_P * 10000) / 10000.0);
		secd1_F = (double) (Math.round(secd1_F * 10000) / 10000.0);
		secd1_FMeasure = (double) (Math.round(secd1_FMeasure * 10000) / 10000.0);
		secd1_V = (double) (Math.round(secd1_V * 10000) / 10000.0);
		secd1_no = (double) (Math.round(secd1_no * 10000) / 10000.0);
		secd1_D = (double) (Math.round(secd1_D * 10000) / 10000.0);
		secd1_costTime = (long) (Math.round(secd1_costTime * 10000) / 10000.0);

		secd2_NMI = (double) (Math.round(secd2_NMI * 10000) / 10000.0);
		secd2_Q = (double) (Math.round(secd2_Q * 10000) / 10000.0);
		secd2_R = (double) (Math.round(secd2_R * 10000) / 10000.0);
		secd2_P = (double) (Math.round(secd2_P * 10000) / 10000.0);
		secd2_F = (double) (Math.round(secd2_F * 10000) / 10000.0);
		secd2_FMeasure = (double) (Math.round(secd2_FMeasure * 10000) / 10000.0);
		secd2_V = (double) (Math.round(secd2_V * 10000) / 10000.0);
		secd2_no = (double) (Math.round(secd2_no * 10000) / 10000.0);
		secd2_D = (double) (Math.round(secd2_D * 10000) / 10000.0);
		secd2_costTime = (long) (Math.round(secd2_costTime * 10000) / 10000.0);

		secd3_NMI = (double) (Math.round(secd3_NMI * 10000) / 10000.0);
		secd3_Q = (double) (Math.round(secd3_Q * 10000) / 10000.0);
		secd3_R = (double) (Math.round(secd3_R * 10000) / 10000.0);
		secd3_P = (double) (Math.round(secd3_P * 10000) / 10000.0);
		secd3_F = (double) (Math.round(secd3_F * 10000) / 10000.0);
		secd3_FMeasure = (double) (Math.round(secd3_FMeasure * 10000) / 10000.0);
		secd3_V = (double) (Math.round(secd3_V * 10000) / 10000.0);
		secd3_no = (double) (Math.round(secd3_no * 10000) / 10000.0);
		secd3_D = (double) (Math.round(secd3_D * 10000) / 10000.0);
		secd3_costTime = (long) (Math.round(secd3_costTime * 10000) / 10000.0);

		cdbi1_NMI = (double) (Math.round(cdbi1_NMI * 10000) / 10000.0);
		cdbi1_Q = (double) (Math.round(cdbi1_Q * 10000) / 10000.0);
		cdbi1_R = (double) (Math.round(cdbi1_R * 10000) / 10000.0);
		cdbi1_P = (double) (Math.round(cdbi1_P * 10000) / 10000.0);
		cdbi1_F = (double) (Math.round(cdbi1_F * 10000) / 10000.0);
		cdbi1_FMeasure = (double) (Math.round(cdbi1_FMeasure * 10000) / 10000.0);
		cdbi1_V = (double) (Math.round(cdbi1_V * 10000) / 10000.0);
		cdbi1_no = (double) (Math.round(cdbi1_no * 10000) / 10000.0);
		cdbi1_D = (double) (Math.round(cdbi1_D * 10000) / 10000.0);
		cdbi1_costTime = (long) (Math.round(cdbi1_costTime * 10000) / 10000.0);

		cdbi2_NMI = (double) (Math.round(cdbi2_NMI * 10000) / 10000.0);
		cdbi2_Q = (double) (Math.round(cdbi2_Q * 10000) / 10000.0);
		cdbi2_R = (double) (Math.round(cdbi2_R * 10000) / 10000.0);
		cdbi2_P = (double) (Math.round(cdbi2_P * 10000) / 10000.0);
		cdbi2_F = (double) (Math.round(cdbi2_F * 10000) / 10000.0);
		cdbi2_FMeasure = (double) (Math.round(cdbi2_FMeasure * 10000) / 10000.0);
		cdbi2_V = (double) (Math.round(cdbi2_V * 10000) / 10000.0);
		cdbi2_no = (double) (Math.round(cdbi2_no * 10000) / 10000.0);
		cdbi2_D = (double) (Math.round(cdbi2_D * 10000) / 10000.0);
		cdbi2_costTime = (long) (Math.round(cdbi2_costTime * 10000) / 10000.0);

		cdbi3_NMI = (double) (Math.round(cdbi3_NMI * 10000) / 10000.0);
		cdbi3_Q = (double) (Math.round(cdbi3_Q * 10000) / 10000.0);
		cdbi3_R = (double) (Math.round(cdbi3_R * 10000) / 10000.0);
		cdbi3_P = (double) (Math.round(cdbi3_P * 10000) / 10000.0);
		cdbi3_F = (double) (Math.round(cdbi3_F * 10000) / 10000.0);
		cdbi3_FMeasure = (double) (Math.round(cdbi3_FMeasure * 10000) / 10000.0);
		cdbi3_V = (double) (Math.round(cdbi3_V * 10000) / 10000.0);
		cdbi3_no = (double) (Math.round(cdbi3_no * 10000) / 10000.0);
		cdbi3_D = (double) (Math.round(cdbi3_D * 10000) / 10000.0);
		cdbi3_costTime = (long) (Math.round(cdbi3_costTime * 10000) / 10000.0);

		System.out.println("Algorithms" + "    " + "\tCDBI1" + "\tCDBI2"
				+ "\tCDBI3" + "\tWCPM" + "\tLFM" + "\tDOCnet" + "\tCFM"
				+ "\tTWD");
		System.out.println("NMI:    " + "\t" + cdbi1_NMI + "\t" + cdbi2_NMI
				+ "\t" + cdbi3_NMI + "\t" + wcpm_NMI + "\t" + lfm_NMI + "\t"
				+ docnet_NMI + "\t" + cfm_NMI + "\t" + twd_NMI);
		System.out.println("Q:      " + "\t" + cdbi1_Q + "\t" + cdbi2_Q + "\t"
				+ cdbi3_Q + "\t" + wcpm_Q + "\t" + lfm_Q + "\t" + docnet_Q
				+ "\t" + cfm_Q + "\t" + twd_Q);
		System.out.println("R:      " + "\t" + cdbi1_R + "\t" + cdbi2_R + "\t"
				+ cdbi3_R + "\t" + wcpm_R + "\t" + lfm_R + "\t" + docnet_R
				+ "\t" + cfm_R + "\t" + twd_R);
		System.out.println("P:      " + "\t" + cdbi1_P + "\t" + cdbi2_P + "\t"
				+ cdbi3_P + "\t" + wcpm_P + "\t" + lfm_P + "\t" + docnet_P
				+ "\t" + cfm_P + "\t" + twd_P);
		System.out.println("F:      " + "\t" + cdbi1_F + "\t" + cdbi2_F + "\t"
				+ cdbi3_F + "\t" + wcpm_F + "\t" + lfm_F + "\t" + docnet_F
				+ "\t" + cfm_F + "\t" + twd_F);
		System.out.println("FMeasure:" + "\t" + cdbi1_FMeasure + "\t"
				+ cdbi2_FMeasure + "\t" + cdbi3_FMeasure + "\t" + wcpm_FMeasure
				+ "\t" + lfm_FMeasure + "\t" + docnet_FMeasure + "\t"
				+ cfm_FMeasure + "\t" + twd_FMeasure);
		System.out.println("V:      " + "\t" + cdbi1_V + "\t" + cdbi2_V + "\t"
				+ cdbi3_V + "\t" + wcpm_V + "\t" + lfm_V + "\t" + docnet_V
				+ "\t" + cfm_V + "\t" + twd_V);
		System.out.println("no:     " + "\t" + cdbi1_no + "\t" + cdbi2_no
				+ "\t" + cdbi3_no + "\t" + wcpm_no + "\t" + lfm_no + "\t"
				+ docnet_no + "\t" + cfm_no + "\t" + twd_no);
		System.out.println("D:      " + "\t" + cdbi1_D + "\t" + cdbi2_D + "\t"
				+ cdbi3_D + "\t" + wcpm_D + "\t" + lfm_D + "\t" + docnet_D
				+ "\t" + cfm_D + "\t" + twd_D);
		System.out.println("Time:   " + "\t" + cdbi1_costTime + "\t"
				+ cdbi2_costTime + "\t" + cdbi3_costTime + "\t" + wcpm_costTime
				+ "\t" + lfm_costTime + "\t" + docnet_costTime + "\t"
				+ cfm_costTime + "\t" + twd_costTime);

		// Measurements wcpm_algorithme = new Measurements(wcpm_algorithm_name,
		// wcpm_costTime, wcpm_NMI, wcpm_Q, wcpm_F, wcpm_V, wcpm_C);
		// Measurements lfm_algorithme = new Measurements(lfm_algorithm_name,
		// lfm_costTime, lfm_NMI, lfm_Q, lfm_F, lfm_V, lfm_C);
		// Measurements docnet_algorithm = new
		// Measurements(docnet_algorithm_name,
		// docnet_costTime, docnet_NMI, docnet_Q, docnet_F, docnet_V,
		// docnet_C);
		// Measurements cfm_algorithm = new Measurements(cfm_algorithm_name,
		// cfm_costTime, cfm_NMI, cfm_Q, cfm_F, cfm_V, cfm_C);
		// Measurements twd_algorithm = new Measurements(twd_algorithm_name,
		// twd_costTime, twd_NMI, twd_Q, twd_F, twd_V, twd_C);
		// Measurements ncb_algorithm = new Measurements(ncb_algorithm_name,
		// ncb_costTime, ncb_NMI, ncb_Q, ncb_F, ncb_V, ncb_C);
		// Measurements kce_algorithm = new Measurements(kce_algorithm_name,
		// kce_costTime, kce_NMI, kce_Q, kce_F, kce_V, kce_C);
		// Measurements kce1_algorithm = new Measurements(kce1_algorithm_name,
		// kce1_costTime, kce1_NMI, kce1_Q, kce1_F, kce1_V, kce1_C);
		// Measurements kce2_algorithm = new Measurements(kce2_algorithm_name,
		// kce2_costTime, kce2_NMI, kce2_Q, kce2_F, kce2_V, kce2_C);
		// Measurements kce3_algorithm = new Measurements(kce3_algorithm_name,
		// kce3_costTime, kce3_NMI, kce3_Q, kce3_F, kce3_V, kce3_C);
		// Measurements eagle_algorithm = new Measurements(eagle_algorithm_name,
		// eagle_costTime, eagle_NMI, eagle_Q, eagle_F, eagle_V, eagle_C);
		//
		// measurements_of_all_algorithm_on_one_data_set.add(wcpm_algorithme);
		// measurements_of_all_algorithm_on_one_data_set.add(lfm_algorithme);
		// measurements_of_all_algorithm_on_one_data_set.add(docnet_algorithm);
		// measurements_of_all_algorithm_on_one_data_set.add(cfm_algorithm);
		// measurements_of_all_algorithm_on_one_data_set.add(twd_algorithm);
		// measurements_of_all_algorithm_on_one_data_set.add(ncb_algorithm);
		// measurements_of_all_algorithm_on_one_data_set.add(kce_algorithm);
		// measurements_of_all_algorithm_on_one_data_set.add(kce1_algorithm);
		// measurements_of_all_algorithm_on_one_data_set.add(kce2_algorithm);
		// measurements_of_all_algorithm_on_one_data_set.add(kce3_algorithm);
		// measurements_of_all_algorithm_on_one_data_set.add(eagle_algorithm);

		// return measurements_of_all_algorithm_on_one_data_set;
	}

	public static void main(String[] args) throws IOException
	{
		// karate;dolphin;football;krebsbook;
		// CCSB-YI1;Combined-APMS;Ito-core;LC-multiple;Uetz-screen;Y2H-union;
		// amazon;dblp;youtube;lj
		String file_name = "lj";
		String file_path = "F:/god/Seven/Six results/tests on real world networks/"
				+ file_name + "/";
		System.out.println(file_name);
		String community = "_community.txt";
		String table = "_table.txt";
		String result = "_result";
		String file_path_community = file_path + file_name + community;
		String file_path_table = file_path + file_name + table;
		String file_path_result = file_path + file_name + result;
		RunMethordsOnRealWorldNetwork run_methords = new RunMethordsOnRealWorldNetwork(
				file_path_community, file_path_table, file_path_result);
		run_methords.run_methords_on_realworld_network();
	}
}
