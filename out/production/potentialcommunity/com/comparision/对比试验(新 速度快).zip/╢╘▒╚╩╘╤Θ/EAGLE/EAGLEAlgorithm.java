package com.dingxiaoyu.EAGLE;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeSet;

import DataReaderRealWorldNetwork.DataReaderRealWorldNetwork;

import com.dingxiaoyu.EAGLE.K_Clique;
import com.dingxiaoyu.SIX.CommunityBasedOnCores3;
import com.fileoperations.methods.FileReaders;
import com.pulicoperations.methods.AdjacencyTables;

public class EAGLEAlgorithm
{
	public int size;
	public int m;
	// public int[][] adjacencyMatrix;
	public ArrayList<ArrayList<Integer>> adjacencyTable;
	public int k;
	// node in decrease order
	public TreeSet<Node_ID_Degree> nodes_decrease_degree;
	// node without order
	public ArrayList<Node_ID_Degree> nodes_degree;
	// All k-cliques
	public TreeSet<K_Clique> all_k_cliques;

	// Clique Matrix
	// public int[][] clique_matrix;

	public EAGLEAlgorithm(int n, ArrayList<ArrayList<Integer>> adjacencyTable,
			int k)
	{
		this.size = n;
		// this.adjacencyMatrix = fr.adjacencyMatrix;
		this.adjacencyTable = adjacencyTable;
		this.k = k;
		this.nodes_decrease_degree = new TreeSet<Node_ID_Degree>(
				new Node_ID_Degree());
		this.nodes_degree = new ArrayList<Node_ID_Degree>();
		this.all_k_cliques = new TreeSet<K_Clique>(new K_Clique());
		this.m = get_edge_number();
		// System.out.println("AdjacencyTable:");
		// for (Iterator<ArrayList<Integer>> iter = adjacencyTable.iterator();
		// iter
		// .hasNext();)
		// {
		// System.out.println(iter.next());
		// }
	}

	/* Is a neighbor of set A connecting all the nodes in set A */
	public boolean is_all_connected(int neighbor, TreeSet<Integer> set_A)
	{
		/* Judge from degree */
		if (this.nodes_degree.get(neighbor).degree < set_A.size())
		{
			// System.out.println("false_1");
			return false;
		}
		/* Judge from connectness */
		for (Iterator<Integer> iter_node_in_A = set_A.iterator(); iter_node_in_A
				.hasNext();)
		{
			Integer node_in_A = iter_node_in_A.next();
			if (!adjacencyTable.get(neighbor).contains(node_in_A))
			{
				return false;
			}
			// if (adjacencyMatrix[neighbor][node_in_A] == 0)
			// {
			// // System.out.println("false_2");
			// return false;
			// }
		}
		// System.out.println("true");
		return true;
	}

	/* Is the new clique is already exists */
	public boolean is_clique_exist(TreeSet<K_Clique> cliques, K_Clique clique)
	{
		for (Iterator<K_Clique> iter_cliques_member = cliques.iterator(); iter_cliques_member
				.hasNext();)
		{
			K_Clique cliques_member = iter_cliques_member.next();
			if (cliques_member.k == clique.k
					&& cliques_member.clique.equals(clique.clique))
			{
				return true;
			}
		}
		return false;
	}

	/* Get sub-cliques in order k */
	public TreeSet<K_Clique> get_k_subcliques(int k)
	{
		TreeSet<K_Clique> k_subcliques = new TreeSet<K_Clique>(new K_Clique());
		for (Iterator<K_Clique> iter_cliques_member = this.all_k_cliques
				.iterator(); iter_cliques_member.hasNext();)
		{
			K_Clique cliques_member = iter_cliques_member.next();
			if (cliques_member.k == k)
			{
				k_subcliques.add(cliques_member);
			}
		}
		return k_subcliques;
	}

	/* r=s-1 iteration, get all the cliques(k=s) of a specified node */
	public TreeSet<K_Clique> get_nodes_cliques(int node_ID, int s)
	{
		/* Stop condition */
		if (s == 1)
		{
			TreeSet<K_Clique> s_cliques = new TreeSet<K_Clique>(new K_Clique());
			K_Clique s_clique = new K_Clique();
			TreeSet<Integer> clique = new TreeSet<Integer>();
			clique.add(node_ID);
			s_clique.k = s;
			s_clique.clique.addAll(clique);
			if (!is_clique_exist(s_cliques, s_clique))
			{
				s_cliques.add(s_clique);
				this.all_k_cliques.add(s_clique);
			}
			return s_cliques;
		} else
		{
			TreeSet<K_Clique> s_cliques = new TreeSet<K_Clique>(new K_Clique());
			TreeSet<K_Clique> r_cliques = get_nodes_cliques(node_ID, s - 1);
			for (Iterator<K_Clique> iter_r_clique = r_cliques.iterator(); iter_r_clique
					.hasNext();)
			{
				K_Clique r_clique = iter_r_clique.next();
				/* Get set A */
				TreeSet<Integer> set_A = new TreeSet<Integer>();
				set_A.addAll(r_clique.clique);
				/* Get set B */
				for (Iterator<Integer> iter_node_in_A = set_A.iterator(); iter_node_in_A
						.hasNext();)
				{
					Integer node_in_A = iter_node_in_A.next();
					for (Iterator<Integer> iter_neighbor = adjacencyTable.get(
							node_in_A).iterator(); iter_neighbor.hasNext();)
					{
						Integer neighbor = iter_neighbor.next();
						if (!set_A.contains(neighbor)
								&& is_all_connected(neighbor, set_A))
						{
							/* Get a new s-clique */
							K_Clique s_clique = new K_Clique();
							TreeSet<Integer> clique = new TreeSet<Integer>();
							clique.add(neighbor);
							clique.addAll(set_A);
							s_clique.k = s;
							s_clique.clique.addAll(clique);
							if (!is_clique_exist(s_cliques, s_clique))
							{
								s_cliques.add(s_clique);
							}
						}
					}
				}
			}
			TreeSet<K_Clique> k_order_cliques = get_k_subcliques(s);
			for (Iterator<K_Clique> iter_s_cliques_member = s_cliques
					.iterator(); iter_s_cliques_member.hasNext();)
			{
				K_Clique s_cliques_member = iter_s_cliques_member.next();
				if (!is_clique_exist(k_order_cliques, s_cliques_member))
				{
					this.all_k_cliques.add(s_cliques_member);
				}
			}
			return s_cliques;
		}
	}

	/* Is clique_1 a sub-set of lique_2 */
	public boolean is_subset(K_Clique clique_1, K_Clique clique_2)
	{
		/* Judge from size */
		if (clique_1.k == clique_2.k)
		{
			return false;
		}
		/* Judge from containness */
		for (Iterator<Integer> iter_member_clique1 = clique_1.clique.iterator(); iter_member_clique1
				.hasNext();)
		{
			Integer member_clique1 = iter_member_clique1.next();
			if (!clique_2.clique.contains(member_clique1))
			{
				return false;
			}
		}
		return true;
	}

	/* Remove sub-cliques */
	public void remove_subcliques()
	{
		/* Get cliques in derease order */
		K_Clique[] cliques_decrase = new K_Clique[all_k_cliques.size()];
		int count = all_k_cliques.size() - 1;
		for (Iterator<K_Clique> iter_clique = all_k_cliques.iterator(); iter_clique
				.hasNext();)
		{
			K_Clique clique = iter_clique.next();
			cliques_decrase[count] = clique;
			count--;
		}
		/* Get removed cliques */
		TreeSet<K_Clique> removed_cliques = new TreeSet<K_Clique>(
				new K_Clique());
		for (int i = 0; i < cliques_decrase.length; i++)
		{
			K_Clique clique_1 = cliques_decrase[i];
			for (int j = i + 1; j < cliques_decrase.length; j++)
			{
				K_Clique clique_2 = cliques_decrase[j];
				if (is_subset(clique_1, clique_2))
				{
					removed_cliques.add(clique_1);
					clique_1.clique.clear();
					break;
				}
			}
		}
		/* Remove sub-cliques */
		all_k_cliques.clear();
		for (int i = 0; i < cliques_decrase.length; i++)
		{
			if (!cliques_decrase[i].clique.isEmpty())
			{
				all_k_cliques.add(cliques_decrase[i]);
			}
		}
	}

	/* Get all cliques of all nodes */
	public void locating_cliques()
	{
		/* Get node in decrease order and without order of degree */
		for (Iterator<ArrayList<Integer>> iter = adjacencyTable.iterator(); iter
				.hasNext();)
		{
			ArrayList<Integer> line = iter.next();
			Node_ID_Degree node = new Node_ID_Degree(line.get(0),
					line.size() - 1);
			nodes_decrease_degree.add(node);
			nodes_degree.add(node);
		}
		/* Get all cliques of each node in decrease order of degree */
		for (Iterator<Node_ID_Degree> iter_node = this.nodes_degree.iterator(); iter_node
				.hasNext();)
		{
			Node_ID_Degree node = iter_node.next();
			get_nodes_cliques(node.id, node.degree);
		}
		remove_subcliques();
	}

	/* Get sub-cliques with order >= k */
	public TreeSet<K_Clique> get_more_k_subcliques()
	{
		TreeSet<K_Clique> more_k_subcliques = new TreeSet<K_Clique>(
				new K_Clique());
		for (Iterator<K_Clique> iter_cliques_member = this.all_k_cliques
				.iterator(); iter_cliques_member.hasNext();)
		{
			K_Clique cliques_member = iter_cliques_member.next();
			if (cliques_member.k >= k)
			{
				more_k_subcliques.add(cliques_member);
			} else
			{
				break;
			}
		}
		return more_k_subcliques;
	}

	/* Remnove subordinate maximal cliques */
	public void remove_subordinate_maximal_cliques()
	{
		TreeSet<K_Clique> more_k_subcliques = get_more_k_subcliques();
		this.all_k_cliques.clear();
		this.all_k_cliques.addAll(more_k_subcliques);
	}

	public ArrayList<TreeSet<Integer>> get_initial_communities()
	{
		/* Get all maximal cliques */
		locating_cliques();
		/* Remove subordinate maximal cliques */
		remove_subordinate_maximal_cliques();
		int nodes_number = this.size;
		int count = 0;
		boolean[] flags = new boolean[nodes_number];
		ArrayList<TreeSet<Integer>> initial_communities = new ArrayList<TreeSet<Integer>>();
		for (Iterator<K_Clique> iter_clique = all_k_cliques.iterator(); iter_clique
				.hasNext();)
		{
			K_Clique clique = iter_clique.next();
			initial_communities.add(clique.clique);
			for (Iterator<Integer> iter_member = clique.clique.iterator(); iter_member
					.hasNext();)
			{
				Integer member = iter_member.next();
				if (flags[member] == false)
				{
					flags[member] = true;
					count++;
				}
			}
		}
		/* Collect the nodes which are not belong to any community */
		for (int i = 0; i < nodes_number; i++)
		{
			if (flags[i] == false)
			{
				flags[i] = true;
				count++;
				TreeSet<Integer> community = new TreeSet<Integer>();
				community.add(i);
				initial_communities.add(community);
			}
		}
		// System.out.println("Initial communitiers: ");
		// for (Iterator<TreeSet<Integer>> iter_community = initial_communities
		// .iterator(); iter_community.hasNext();)
		// {
		// TreeSet<Integer> community = iter_community.next();
		// for (Iterator<Integer> iter_member = community.iterator();
		// iter_member
		// .hasNext();)
		// {
		// Integer member = iter_member.next();
		// System.out.print(member + " ");
		// }
		// System.out.println();
		// }
		// System.out.println("************************************************");
		return initial_communities;
	}

	/* Get possable edges between the two communities */
	public ArrayList<Edge> get_between_edges(TreeSet<Integer> community_1,
			TreeSet<Integer> community_2)
	{
		ArrayList<Edge> edges = new ArrayList<Edge>();
		for (Iterator<Integer> iter_member_1 = community_1.iterator(); iter_member_1
				.hasNext();)
		{
			Integer member_1 = iter_member_1.next();
			for (Iterator<Integer> iter_member_2 = community_2.iterator(); iter_member_2
					.hasNext();)
			{
				Integer member_2 = iter_member_2.next();
				if (!member_1.equals(member_2))
				{
					Edge edge = new Edge(member_1, member_2);
					if (adjacencyTable.get(edge.id1).contains(edge.id2))
					{
						edge.Avw = 1;
					} else
					{
						edge.Avw = 0;
					}
					// if (adjacencyMatrix[edge.id1][edge.id2] != 0)
					// {
					// edge.Avw = 1;
					// } else
					// {
					// edge.Avw = 0;
					// }
					edges.add(edge);
				}
				/* The version without repeat edges */
				// if (!member_1.equals(member_2))
				// {
				// Edge edge = new Edge();
				// if (member_1 > member_2)
				// {
				// edge.id1 = member_1;
				// edge.id2 = member_2;
				// } else
				// {
				// edge.id1 = member_2;
				// edge.id2 = member_1;
				// }
				// if (adjacencyMatrix[edge.id1][edge.id2] != 0)
				// {
				// edge.Avw = 1;
				// if (!edges.contains(edge))
				// {
				// edges.add(edge);
				// }
				// } else
				// {
				// edge.Avw = 0;
				// if (!edges.contains(edge))
				// {
				// edges.add(edge);
				// }
				// }
				// }
			}
		}
		// for (Iterator<Edge> iter_edge = edges.iterator();
		// iter_edge.hasNext();)
		// {
		// Edge ex = iter_edge.next();
		// System.out.println(ex.id1 + "," + ex.id2 + "," + ex.Avw);
		// }
		return edges;
	}

	/* Get number of edges */
	public int get_edge_number()
	{
		int m = 0;
		for (Iterator<ArrayList<Integer>> iter_line = adjacencyTable.iterator(); iter_line
				.hasNext();)
		{
			ArrayList<Integer> line = iter_line.next();
			m += (line.size() - 1);
		}
		m = m / 2;
		return m;
	}

	/* Calculate similarity */
	public double calculate_similarity(TreeSet<Integer> community_1,
			TreeSet<Integer> community_2)
	{
		double similarity = 0;
		/* Get possable edges between the two communities */
		ArrayList<Edge> edges = get_between_edges(community_1, community_2);
		for (Iterator<Edge> iter_edge = edges.iterator(); iter_edge.hasNext();)
		{
			Edge edge = iter_edge.next();
			int avw = edge.Avw;
			int kv = adjacencyTable.get(edge.id1).size() - 1;
			int kw = adjacencyTable.get(edge.id2).size() - 1;
			double x = kv * kw / (double) (2 * m);
			similarity += avw - x;
		}
		similarity /= (2 * m);
		return similarity;
	}

	/*
	 * Get (the new community) the two communities with the highest similarity
	 * increase
	 */
	public ArrayList<TreeSet<Integer>> get_two_communities(
			ArrayList<TreeSet<Integer>> communities)
	{
		ArrayList<TreeSet<Integer>> two_community = new ArrayList<TreeSet<Integer>>();
		TreeSet<Integer> max_c1 = new TreeSet<Integer>();
		TreeSet<Integer> max_c2 = new TreeSet<Integer>();
		double max_similarity = -1;
		int k = 0;
		for (int i = 0; i < communities.size(); i++)
		{
			TreeSet<Integer> community_1 = communities.get(i);
			for (int j = i + 1; j < communities.size(); j++)
			{
				TreeSet<Integer> community_2 = communities.get(j);
				double similarity = calculate_similarity(community_1,
						community_2);
				k++;
				if (similarity > max_similarity && similarity > 0)
				{
					max_similarity = similarity;
					max_c1.clear();
					max_c1.addAll(community_1);
					max_c2.clear();
					max_c2.addAll(community_2);
				}
			}
		}
		if (max_similarity > 0)
		{
			two_community.add(max_c1);
			two_community.add(max_c2);
			return two_community;
		}
		return two_community;
	}

	/*
	 * Get number of overlap communities(the number of communities that node
	 * belongs to)
	 */
	public int get_overlap_number(ArrayList<TreeSet<Integer>> communities,
			int node_id)
	{
		int overlap_number = 0;
		for (Iterator<TreeSet<Integer>> iter_community = communities.iterator(); iter_community
				.hasNext();)
		{
			TreeSet<Integer> community = iter_community.next();
			if (community.contains(node_id))
			{
				overlap_number++;
			}
		}
		return overlap_number;
	}

	/* Calculate EQ */
	public double calculate_EQ(ArrayList<TreeSet<Integer>> communities)
	{
		double EQ = 0;
		for (int i = 0; i < communities.size(); i++)
		{
			ArrayList<Integer> community = new ArrayList<Integer>();
			community.addAll(communities.get(i));
			double sum = 0;
			for (int j = 0; j < community.size(); j++)
			{
				int node_1 = community.get(j);
				for (int k = 0; k < community.size(); k++)
				{
					int node_2 = community.get(k);
					int avw;
					if (adjacencyTable.get(node_1).contains(node_2))
					{
						avw = 1;
					} else
					{
						avw = 0;
					}
					// if (adjacencyMatrix[node_1][node_2] != 0)
					// {
					// avw = 1;
					// } else
					// {
					// avw = 0;
					// }
					int kv = adjacencyTable.get(node_1).size() - 1;
					int kw = adjacencyTable.get(node_2).size() - 1;
					double x = kv * kw / (double) (2 * m);
					int o_node_1 = get_overlap_number(communities, node_1);
					int o_node_2 = get_overlap_number(communities, node_2);
					sum += ((avw - x) / (o_node_1 * o_node_2));
				}
			}
			EQ += sum;
		}
		EQ /= (2 * m);
		// System.out.println(EQ);
		return EQ;
	}

	/* Merge all possiable communities and keep the state with the highest EQ */
	public ArrayList<ArrayList<Integer>> run_eagle()
	{
		ArrayList<ArrayList<Integer>> finial_communities = new ArrayList<ArrayList<Integer>>();
		ArrayList<TreeSet<Integer>> initial_communities = get_initial_communities();
		ArrayList<TreeSet<Integer>> community_max_EQ = new ArrayList<TreeSet<Integer>>();
		double max_EQ = calculate_EQ(initial_communities);
		/* Merge all possiable communities */
		ArrayList<TreeSet<Integer>> communities = new ArrayList<TreeSet<Integer>>();
		communities.addAll(initial_communities);
		ArrayList<TreeSet<Integer>> two_community = get_two_communities(communities);
		// System.out.println("All communities: ");
		while (!two_community.isEmpty())
		{
			communities.removeAll(two_community);
			TreeSet<Integer> community_1 = two_community.get(0);
			TreeSet<Integer> community_2 = two_community.get(1);
			TreeSet<Integer> community_new = new TreeSet<Integer>();
			community_new.addAll(community_1);
			community_new.addAll(community_2);
			communities.add(community_new);
			two_community.clear();
			two_community = get_two_communities(communities);
			double EQ = calculate_EQ(communities);
			if (EQ > max_EQ)
			{
				max_EQ = EQ;
				community_max_EQ.clear();
				community_max_EQ.addAll(communities);
			}
			// for (Iterator<TreeSet<Integer>> iter_community = communities
			// .iterator(); iter_community.hasNext();)
			// {
			// TreeSet<Integer> community = iter_community.next();
			// for (Iterator<Integer> iter_member = community.iterator();
			// iter_member
			// .hasNext();)
			// {
			// Integer member = iter_member.next();
			// System.out.print(member + " ");
			// }
			// System.out.println();
			// }
			// System.out.println();
		}
		for (Iterator<TreeSet<Integer>> iter_community = communities.iterator(); iter_community
				.hasNext();)
		{
			TreeSet<Integer> community = iter_community.next();
			ArrayList<Integer> community_new = new ArrayList<Integer>();
			community_new.addAll(community);
			finial_communities.add(community_new);
			// System.out.println(community_new);
		}
		// for (Iterator<ArrayList<Integer>> iter =
		// finial_communities.iterator(); iter
		// .hasNext();)
		// {
		// System.out.println(iter.next());
		// }
		// System.out.println("finial_communities_size: "
		// + finial_communities.size());
		return finial_communities;
	}

	public static void main(String[] args) throws IOException
	{
		String file_path = "D:/real world networks/";
		String file_name = "dolphin";
		// karate;dolphin;football;krebsbook;dblp;amazon;youtube
		String network = "_network.txt";
		// karate_network;dolphin_network;football_network;krebsbook_network
		// dblp_network;amazon_network;youtube_network
		String community = "_community.txt";
		// karate_community;dolphin_community;football_community;krebsbook_community
		// dblp_community;amazon_community;youtube_community
		String table = "_table.txt";
		// karate_table;dolphin_table;football_table;krebsbook_table
		// dblp_table;amazon_table;youtube_table
		String file_path_network = file_path + file_name + network;
		String file_path_community = file_path + file_name + community;
		String file_path_table = file_path + file_name + table;

		DataReaderRealWorldNetwork data_reader = new DataReaderRealWorldNetwork(
				file_path_community, file_path_table);
		data_reader.read_realworld_network();

		// double merage_possiability = 0.75;
		CommunityBasedOnCores3 cbc = new CommunityBasedOnCores3(data_reader.n,
				data_reader.m, data_reader.adjacencyTable);
		int k = 4;

		EAGLEAlgorithm cf = new EAGLEAlgorithm(data_reader.n,
				data_reader.adjacencyTable, k);
		cf.run_eagle();
		// System.out.println("AdjacencyTable:");
		// for (Iterator<ArrayList<Integer>> iter =
		// cf.adjacencyTable.iterator(); iter
		// .hasNext();)
		// {
		// System.out.println(iter.next());
		// }
	}
}
