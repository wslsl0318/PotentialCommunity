package com.dingxiaoyu.EAGLE;

import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

public class Node_ID_Degree implements Comparator<Node_ID_Degree>
{
	int id;
	int degree;

	public Node_ID_Degree()
	{

	}

	public Node_ID_Degree(int id, int degree)
	{
		this.id = id;
		this.degree = degree;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + degree;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Node_ID_Degree other = (Node_ID_Degree) obj;
		if (degree != other.degree)
			return false;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public int compare(Node_ID_Degree o1, Node_ID_Degree o2)
	{
		// TODO Auto-generated method stub
		Node_ID_Degree node1 = o1;
		Node_ID_Degree node2 = o2;
		if (node1.degree > node2.degree)
		{
			return -1;
		} else if (node1.degree == node2.degree)
		{
			if (node1.id < node2.id)
			{
				return -1;
			} else if (node1.id == node2.id)
			{
				if (node1.id < node2.id)
				{
					return -1;
				} else if (node1.id == node2.id)
				{
					return 0;
				} else if (node1.id > node2.id)
				{
					return 1;
				}
			} else if (node1.id > node2.id)
			{
				return 1;
			}
		} else if (node1.degree < node2.degree)
		{
			return 1;
		}
		return 0;
	}

	public static void main(String[] args)
	{
		Node_ID_Degree n1 = new Node_ID_Degree(2, 3);
		Node_ID_Degree n2 = new Node_ID_Degree(1, 4);
		TreeSet<Node_ID_Degree> nl = new TreeSet<Node_ID_Degree>(
				new Node_ID_Degree());
		nl.add(n1);
		nl.add(n2);
		for (Iterator<Node_ID_Degree> iter = nl.iterator(); iter.hasNext();)
		{
			Node_ID_Degree n = iter.next();
			System.out.println(n.degree + "," + n.id);
		}
	}
}
