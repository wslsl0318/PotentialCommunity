package com.dingxiaoyu.EAGLE;

import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

public class K_Clique implements Comparator<K_Clique>
{
	public int k;
	public TreeSet<Integer> clique;

	public K_Clique()
	{
		this.clique = new TreeSet<Integer>();
	}

	public K_Clique(int k, TreeSet<Integer> clique)
	{
		this.k = k;
		this.clique = clique;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((clique == null) ? 0 : clique.hashCode());
		result = prime * result + k;
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		K_Clique other = (K_Clique) obj;
		if (clique == null)
		{
			if (other.clique != null)
				return false;
		} else if (!clique.equals(other.clique))
			return false;
		if (k != other.k)
			return false;
		return true;
	}

	@Override
	public int compare(K_Clique o1, K_Clique o2)
	{
		// TODO Auto-generated method stub
		K_Clique node1 = o1;
		K_Clique node2 = o2;
		if (node1.k > node2.k)
		{
			return -1;
		} else if (node1.k == node2.k)
		{
			if (node1.clique.equals(node2.clique))
			{
				return 0;
			} else
			{
				return 1;
			}
		} else if (node1.k < node2.k)
		{
			return 1;
		}
		return 0;
	}

	public static void main(String[] args)
	{
		int n1 = 1;
		int n2 = 4;
		TreeSet<Integer> nn = new TreeSet<Integer>();
		nn.add(n1);
		nn.add(n2);

		int n3 = 2;
		int n4 = 4;
		TreeSet<Integer> nm = new TreeSet<Integer>();
		nm.add(n3);
		nm.add(n4);
		
		int n5 = 1;
		int n6 = 4;
		TreeSet<Integer> nl = new TreeSet<Integer>();
		nl.add(n3);
		nl.add(n4);

		K_Clique nnn = new K_Clique(1, nn);
		K_Clique nnm = new K_Clique(1, nm);
		K_Clique nnl = new K_Clique(1, nl);

		TreeSet<K_Clique> nx = new TreeSet<K_Clique>(new K_Clique());

		nx.add(nnm);
		nx.add(nnn);
		nx.add(nnl);

		for (Iterator<K_Clique> iter = nx.iterator(); iter.hasNext();)
		{
			K_Clique clique = iter.next();
			System.out.println(clique.k + "," + clique.clique);
		}
	}
}
