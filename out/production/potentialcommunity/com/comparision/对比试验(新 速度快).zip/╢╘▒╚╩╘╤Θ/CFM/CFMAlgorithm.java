package com.dingxiaoyu.CFM;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeSet;

import DataReaderRealWorldNetwork.DataReaderRealWorldNetwork;

public class CFMAlgorithm
{
	public int n;
	public int m;
	public ArrayList<ArrayList<Integer>> adjacencyTable;
	public ArrayList<LinkBackboneDegree> links;
	public ArrayList<TreeSet<Integer>> finial_communities;

	public CFMAlgorithm(int n, int m,
			ArrayList<ArrayList<Integer>> adjacencyTable)
	{
		this.n = n;
		this.m = m;
		this.adjacencyTable = adjacencyTable;
		// System.out.println("adjacency table");
		// for (Iterator<ArrayList<Integer>> iter =
		// this.adjacencyTable.iterator(); iter
		// .hasNext();)
		// {
		// ArrayList<Integer> line = iter.next();
		// System.out.println(line.size() - 1 + "," + line);
		// }
		// System.out.println();
		this.links = new ArrayList<LinkBackboneDegree>();
		this.finial_communities = new ArrayList<TreeSet<Integer>>();
	}

	/* (Tested) Get community insection */
	public TreeSet<Integer> get_insection(ArrayList<Integer> neighboorhood_1,
			ArrayList<Integer> neighboorhood_2)
	{
		TreeSet<Integer> insection = new TreeSet<Integer>();
		for (Iterator<Integer> iter = neighboorhood_1.iterator(); iter
				.hasNext();)
		{
			Integer member = iter.next();
			if (neighboorhood_2.contains(member))
			{
				insection.add(member);
			}
		}
		// System.out.println(insection.size() + "," + insection);
		return insection;
	}

	/* (Tested) Get community union */
	public TreeSet<Integer> get_union(ArrayList<Integer> neighboorhood_1,
			ArrayList<Integer> neighboorhood_2)
	{
		TreeSet<Integer> union = new TreeSet<Integer>();
		union.addAll(neighboorhood_1);
		union.addAll(neighboorhood_2);
		// System.out.println(union.size() + "," + union);
		return union;
	}

	/* (Tested) Calculate backbone degree */
	public double calculate_backbone_degree(ArrayList<Integer> line1,
			ArrayList<Integer> line2)
	{
		TreeSet<Integer> insection = get_insection(line1, line2);
		TreeSet<Integer> union = get_union(line1, line2);
		double no_id1_id2 = (double) insection.size() / (double) union.size();
		double nw_id1 = (double) (line1.size() - 1) / (double) this.m;
		double nw_id2 = (double) (line2.size() - 1) / (double) this.m;
		double bd_id1_id2 = (nw_id1 + nw_id2) * no_id1_id2;
		return bd_id1_id2;
	}

	/* (Tested) Calculate backbone degree */
	public TreeSet<LinkBackboneDegree> calculate_backbone_degree_for_all_links()
	{
		TreeSet<LinkBackboneDegree> links_ordered = new TreeSet<LinkBackboneDegree>(
				new LinkBackboneDegree());
		for (int i = 0; i < this.adjacencyTable.size(); i++)
		{
			int id1 = i;
			ArrayList<Integer> line1 = this.adjacencyTable.get(id1);
			for (int j = 1; j < line1.size(); j++)
			{
				Integer id2 = line1.get(j);
				if (id1 < id2)
				{
					ArrayList<Integer> line2 = this.adjacencyTable.get(id2);
					double bd_id1_id2 = calculate_backbone_degree(line1, line2);
					LinkBackboneDegree lbd = new LinkBackboneDegree(id1, id2,
							bd_id1_id2);
					links_ordered.add(lbd);
				}
			}
		}
		// System.out.println("links: ");
		// for (Iterator<LinkBackboneDegree> iter = links_ordered.iterator();
		// iter
		// .hasNext();)
		// {
		// System.out.println(iter.next());
		// }
		// System.out.println(links_ordered.size());
		return links_ordered;
	}

	/* (Tested) Initial community and community neighbors and community boundary */
	public void initial_community_and_community_neighbors_and_community_boundary(
			LinkBackboneDegree max_bd_link, TreeSet<Integer> community,
			TreeSet<Integer> community_neighbors)
	{
		community.add(max_bd_link.id1);
		community.add(max_bd_link.id2);
		for (Iterator<Integer> iter = community.iterator(); iter.hasNext();)
		{
			Integer member = iter.next();
			community_neighbors.addAll(this.adjacencyTable.get(member));
		}
		community_neighbors.removeAll(community);
		// System.out.println("community: " + community);
		// System.out.println("community_neighbors: " + community_neighbors);
		// System.out.println("community_boundary: " + community_boundary);
	}

	/* (Tested) Calculate SC */
	public double calculate_sc(TreeSet<Integer> community, int neighbor)
	{
		double sc = 0;
		ArrayList<Integer> line1 = this.adjacencyTable.get(neighbor);
		for (Iterator<Integer> iter = line1.iterator(); iter.hasNext();)
		{
			Integer neighbor_neighbor = iter.next();
			if (community.contains(neighbor_neighbor))
			{
				ArrayList<Integer> line2 = this.adjacencyTable
						.get(neighbor_neighbor);
				double bd = calculate_backbone_degree(line1, line2);
				sc += bd;
			}
		}
		return sc;
	}

	/* (Tested) Get max sc_v from community_neighbors minus community_boundary */
	public int get_max_sc_v(TreeSet<Integer> community,
			TreeSet<Integer> community_neighbors_minus_community_boundary)
	{
		int max_sc_v = -1;
		double max_sc = 0;
		for (Iterator<Integer> iter = community_neighbors_minus_community_boundary
				.iterator(); iter.hasNext();)
		{
			Integer neighbor = iter.next();
			double sc = calculate_sc(community, neighbor);
			// System.out.println(neighbor + "," + sc);
			if (sc > max_sc)
			{
				max_sc = sc;
				max_sc_v = neighbor;
			}
		}
		// System.out.println(max_sc_v + "," + max_sc);
		return max_sc_v;
	}

	/* (Tested) Refreash community neighbors */
	public void refreash_community_neighbors(int max_sc_v,
			TreeSet<Integer> community, TreeSet<Integer> community_neighbors)
	{
		ArrayList<Integer> line = this.adjacencyTable.get(max_sc_v);
		for (Iterator<Integer> iter = line.iterator(); iter.hasNext();)
		{
			Integer member = iter.next();
			if (!community.contains(member))
			{
				community_neighbors.add(member);
			}
		}
	}

	/* (Tested) Calculate EX_C */
	public double calculate_ex_c(TreeSet<Integer> community)
	{
		double ex_c = 0;
		int external_line_count = 0;
		for (Iterator<Integer> iter = community.iterator(); iter.hasNext();)
		{
			Integer member = iter.next();
			ArrayList<Integer> line = this.adjacencyTable.get(member);
			for (Iterator<Integer> iter_neighbor = line.iterator(); iter_neighbor
					.hasNext();)
			{
				Integer neighbor = iter_neighbor.next();
				if (!community.contains(neighbor))
				{
					external_line_count++;
				}
			}
		}
		ex_c = (double) external_line_count / (double) (community.size());
		return ex_c;
	}

	/* (Tested) Get link by ids */
	public void remove_link_by_ids(int id1, int id2)
	{
		for (int i = 0; i < this.links.size(); i++)
		{
			LinkBackboneDegree link = this.links.get(i);
			if (link.id1 == id1 && link.id2 == id2)
			{
				// System.out.println(link + "," + id1 + "," + id2);
				this.links.remove(i);
				break;
			}
		}
	}

	public ArrayList<TreeSet<Integer>> run_cfm()
	{
		TreeSet<LinkBackboneDegree> links_ordered = calculate_backbone_degree_for_all_links();
		this.links.addAll(links_ordered);
		while (!this.links.isEmpty())
		{
			LinkBackboneDegree max_bd_link = this.links.get(0);
			this.links.remove(0);
			TreeSet<Integer> community = new TreeSet<Integer>();
			TreeSet<Integer> community_neighbors = new TreeSet<Integer>();
			TreeSet<Integer> community_boundary = new TreeSet<Integer>();
			initial_community_and_community_neighbors_and_community_boundary(
					max_bd_link, community, community_neighbors);
			double ex_c = calculate_ex_c(community);
			while (true)
			{
				TreeSet<Integer> community_neighbors_temp = new TreeSet<Integer>();
				community_neighbors_temp.addAll(community_neighbors);
				TreeSet<Integer> community_boundary_temp = new TreeSet<Integer>();
				community_boundary_temp.addAll(community_boundary);
				community_neighbors_temp.removeAll(community_boundary_temp);
				if (community_neighbors_temp.isEmpty())
				{
					break;
				} else
				{
					int max_sc_v = get_max_sc_v(community,
							community_neighbors_temp);
					TreeSet<Integer> community_temp = new TreeSet<Integer>();
					community_temp.addAll(community);
					community_temp.add(max_sc_v);
					double ex_c_temp = calculate_ex_c(community_temp);
					if (ex_c_temp - ex_c < 0)
					{
						ex_c = ex_c_temp;
						community.add(max_sc_v);
						community_neighbors.remove(max_sc_v);
						refreash_community_neighbors(max_sc_v, community,
								community_neighbors);
					} else
					{
						community_boundary.add(max_sc_v);
					}
				}
			}
			ArrayList<Integer> community_members = new ArrayList<Integer>();
			community_members.addAll(community);
			for (int i = 0; i < community_members.size(); i++)
			{
				Integer id1 = community_members.get(i);
				ArrayList<Integer> line = this.adjacencyTable.get(id1);
				for (Iterator<Integer> iter = line.iterator(); iter.hasNext();)
				{
					Integer id2 = iter.next();
					if (id1 < id2)
					{
						remove_link_by_ids(id1, id2);
					}
					if (id1 > id2)
					{
						remove_link_by_ids(id2, id1);
					}
				}
			}
			this.finial_communities.add(community);
		}

		/* remove same communities */
		ArrayList<TreeSet<Integer>> communities_to_be_removed_1 = new ArrayList<TreeSet<Integer>>();
		for (int i = 0; i < this.finial_communities.size(); i++)
		{
			TreeSet<Integer> community_1 = this.finial_communities.get(i);
			for (int j = i + 1; j < this.finial_communities.size(); j++)
			{
				TreeSet<Integer> community_2 = this.finial_communities.get(j);
				if (community_1.equals(community_2))
				{
					if (!communities_to_be_removed_1.contains(community_1))
					{
						communities_to_be_removed_1.add(community_1);
						break;
					}
				}
			}
		}
		finial_communities.removeAll(communities_to_be_removed_1);
		finial_communities.addAll(communities_to_be_removed_1);

		/* remove sub communities */
		ArrayList<TreeSet<Integer>> communities_to_be_removed_2 = new ArrayList<TreeSet<Integer>>();
		for (int i = 0; i < this.finial_communities.size(); i++)
		{
			TreeSet<Integer> community_1 = this.finial_communities.get(i);
			for (int j = 0; j < this.finial_communities.size(); j++)
			{
				if (i != j)
				{
					TreeSet<Integer> community_2 = this.finial_communities
							.get(j);
					if (community_2.containsAll(community_1))
					{
						communities_to_be_removed_2.add(community_1);
						break;
					}
				}
			}
		}
		this.finial_communities.removeAll(communities_to_be_removed_2);

		// ArrayList<ArrayList<Integer>> communities = new
		// ArrayList<ArrayList<Integer>>();
		// for (Iterator<TreeSet<Integer>> iter = this.finial_communities
		// .iterator(); iter.hasNext();)
		// {
		// ArrayList<Integer> community = new ArrayList<Integer>();
		// community.addAll(iter.next());
		// communities.add(community);
		// }

		// System.out.println("finial communities: ");
		// for (Iterator<ArrayList<Integer>> iter = communities.iterator(); iter
		// .hasNext();)
		// {
		// System.out.println(iter.next());
		// }

		return finial_communities;
	}

	public static void main(String[] args) throws IOException
	{
		String file_path = "D:/real world networks/";
		String file_name = "karate";
		// karate;dolphin;football;krebsbook;dblp;amazon;youtube
		String community = "_community.txt";
		String table = "_table.txt";
		String file_path_community = file_path + file_name + community;
		String file_path_table = file_path + file_name + table;

		DataReaderRealWorldNetwork data_reader = new DataReaderRealWorldNetwork(
				file_path_community, file_path_table);
		data_reader.read_realworld_network();

		CFMAlgorithm cfm = new CFMAlgorithm(data_reader.n, data_reader.m,
				data_reader.adjacencyTable);
		cfm.run_cfm();
	}
}
