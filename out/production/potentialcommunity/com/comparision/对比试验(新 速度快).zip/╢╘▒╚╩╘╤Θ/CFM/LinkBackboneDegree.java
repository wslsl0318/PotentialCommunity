package com.dingxiaoyu.CFM;

import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

public class LinkBackboneDegree implements Comparator<LinkBackboneDegree>
{
	public int id1;
	public int id2;
	public double bd;

	public LinkBackboneDegree()
	{

	}

	public LinkBackboneDegree(int id1, int id2, double bd)
	{
		this.id1 = id1;
		this.id2 = id2;
		this.bd = bd;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(bd);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + id1;
		result = prime * result + id2;
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LinkBackboneDegree other = (LinkBackboneDegree) obj;
		if (Double.doubleToLongBits(bd) != Double.doubleToLongBits(other.bd))
			return false;
		if (id1 != other.id1)
			return false;
		if (id2 != other.id2)
			return false;
		return true;
	}

	@Override
	public int compare(LinkBackboneDegree o1, LinkBackboneDegree o2)
	{
		// TODO Auto-generated method stub
		LinkBackboneDegree node1 = o1;
		LinkBackboneDegree node2 = o2;
		if (node1.bd < node2.bd)
		{
			return 1;
		} else if (node1.bd == node2.bd)
		{
			return 1;
		} else if (node1.bd > node2.bd)
		{
			return -1;
		}
		return 0;
	}

	@Override
	public String toString()
	{
		return "LinkBackboneDegree [id1=" + id1 + ", id2=" + id2 + ", bd=" + bd
				+ "]";
	}

	public static void main(String[] args)
	{
		LinkBackboneDegree l1 = new LinkBackboneDegree(1, 2, 2);
		LinkBackboneDegree l2 = new LinkBackboneDegree(2, 2, 3);
		LinkBackboneDegree l3 = new LinkBackboneDegree(4, 3, 1);
		LinkBackboneDegree l4 = new LinkBackboneDegree(3, 1, 2);
		TreeSet<LinkBackboneDegree> ls = new TreeSet<LinkBackboneDegree>(
				new LinkBackboneDegree());
		ls.add(l1);
		ls.add(l2);
		ls.add(l3);
		ls.add(l4);
		for (Iterator<LinkBackboneDegree> iter = ls.iterator(); iter.hasNext();)
		{
			System.out.println(iter.next());
		}
	}
}
